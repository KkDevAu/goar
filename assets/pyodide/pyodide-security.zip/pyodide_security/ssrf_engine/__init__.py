
from .scan import list_targets, list_targets_pat, scan

list_payloads = list_targets

__all__ = ["scan", "list_targets", "list_targets_pat", "list_payloads"]
