"""MD4 (RFC 1320) — required for NTLM. Pure Python for Pyodide."""

from __future__ import annotations

import struct


def _f(x: int, y: int, z: int) -> int:
    return (x & y) | (~x & z)


def _g(x: int, y: int, z: int) -> int:
    return (x & y) | (x & z) | (y & z)


def _h(x: int, y: int, z: int) -> int:
    return x ^ y ^ z


def _lrot(x: int, n: int) -> int:
    return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF


def md4(data: bytes) -> bytes:
    msg = bytearray(data)
    orig_len_bits = (8 * len(msg)) & 0xFFFFFFFFFFFFFFFF
    msg.append(0x80)
    while (len(msg) % 64) != 56:
        msg.append(0)
    msg += struct.pack("<Q", orig_len_bits)

    a0, b0, c0, d0 = 0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476

    for offset in range(0, len(msg), 64):
        x = list(struct.unpack("<16I", msg[offset : offset + 64]))
        a, b, c, d = a0, b0, c0, d0

        # round 1
        for i, s in zip(range(16), (3, 7, 11, 19) * 4):
            k = i
            a = _lrot((a + _f(b, c, d) + x[k]) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c

        # round 2
        order2 = (0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15)
        for k, s in zip(order2, (3, 5, 9, 13) * 4):
            a = _lrot((a + _g(b, c, d) + x[k] + 0x5A827999) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c

        # round 3
        order3 = (0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15)
        for k, s in zip(order3, (3, 9, 11, 15) * 4):
            a = _lrot((a + _h(b, c, d) + x[k] + 0x6ED9EBA1) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c

        a0 = (a0 + a) & 0xFFFFFFFF
        b0 = (b0 + b) & 0xFFFFFFFF
        c0 = (c0 + c) & 0xFFFFFFFF
        d0 = (d0 + d) & 0xFFFFFFFF

    return struct.pack("<4I", a0, b0, c0, d0)


def ntlm_hash(password: str) -> bytes:
    """Windows NTLM: MD4(UTF-16LE password)."""
    return md4(password.encode("utf-16-le"))
