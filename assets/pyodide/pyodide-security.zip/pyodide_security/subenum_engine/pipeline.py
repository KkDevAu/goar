"""Full subfinder-class enumeration pipeline."""

from __future__ import annotations

from typing import Any

from .resolve import brute, doh_resolve, mutate
from .sources import SOURCES, clean_domain, list_sources


async def enumerate(
    domain: str,
    sources: str = "all",
    wordlist: str = "",
    use_brute: bool = True,
    resolve: bool = True,
    max_words: int = 50,
    provider: str = "cloudflare",
    mutate_found: bool = False,
) -> dict[str, Any]:
    domain = clean_domain(domain)
    if sources.strip().lower() in ("all", "*", ""):
        source_names = list(SOURCES.keys())
    else:
        source_names = [s.strip() for s in sources.split(",") if s.strip() in SOURCES]

    source_results = {}
    names: set[str] = set([domain])

    for name in source_names:
        try:
            res = await SOURCES[name](domain)
            source_results[name] = {
                "count": res.get("count", 0),
                "error": res.get("error"),
                "status": res.get("status"),
                "elapsed_ms": res.get("elapsed_ms"),
            }
            names.update(res.get("subdomains") or [])
        except Exception as e:  # noqa: BLE001
            source_results[name] = {"count": 0, "error": str(e)}

    brute_result = None
    if use_brute:
        brute_result = await brute(domain, wordlist=wordlist, provider=provider, max_words=max_words)
        for f in brute_result.get("found") or []:
            names.add(f["host"])
        source_results["doh-brute"] = {
            "count": brute_result.get("count"),
            "tried": brute_result.get("tried"),
        }

    if mutate_found:
        mut = mutate("\n".join(sorted(names)), domain=domain)
        # resolve only a sample of mutations to avoid explosion
        for host in (mut.get("permutations") or [])[:30]:
            res = await doh_resolve(host, provider=provider)
            if res.get("ok"):
                names.add(host)

    resolved = []
    unresolved = []
    if resolve:
        for host in sorted(names)[:200]:
            res = await doh_resolve(host, "A", provider=provider)
            if res.get("ok"):
                a_records = [a.get("data") for a in res.get("answers") or []]
                resolved.append({"host": host, "a": a_records, "records": res.get("answers")})
            else:
                # try CNAME
                res_c = await doh_resolve(host, "CNAME", provider=provider)
                if res_c.get("ok"):
                    resolved.append({"host": host, "cname": [a.get("data") for a in res_c.get("answers") or []], "records": res_c.get("answers")})
                else:
                    unresolved.append(host)
    else:
        unresolved = sorted(names)

    return {
        "domain": domain,
        "subdomains": sorted(names),
        "count": len(names),
        "resolved": resolved,
        "resolved_count": len(resolved),
        "unresolved": unresolved[:200],
        "unresolved_count": len(unresolved),
        "sources": source_results,
        "sources_used": source_names + (["doh-brute"] if use_brute else []),
        "provider": provider,
        "engine": "subfinder-class",
        "available_sources": list_sources()["sources"],
    }
