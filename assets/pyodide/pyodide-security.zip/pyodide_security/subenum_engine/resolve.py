"""DNS over HTTPS multi-provider resolution + wordlist brute + mutations."""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import quote

from .._http import http_request
from .sources import clean_domain, is_sub

DEFAULT_WORDLIST = """
www mail mx smtp pop imap webmail api app apps dev development staging stage
test testing beta alpha admin administrator portal dashboard vpn remote git
gitlab github ci cd jenkins cdn static assets img images media files upload
uploads shop store cart blog news docs documentation wiki status monitor
monitoring metrics grafana prometheus auth login sso oauth id identity accounts
account ns ns1 ns2 dns dns1 ftp sftp ssh bastion jump db database mysql postgres
redis mongo elastic kibana dev1 dev2 qa uat preprod prod production internal
intranet m mobile app1 app2 api1 api2 v1 v2 graphql rest support help desk
crm erp office owa exchange autodiscover sip cloud aws azure gcp s3 storage
secure client clients partner partners old legacy backup bak demo sandbox
edge gateway proxy cache wss ws mqtt chat push notify webhook webhooks
payment payments billing invoice invoices report reports analytics tracking
""".split()

PREFIXES = ["dev", "staging", "test", "prod", "qa", "uat", "api", "internal", "old", "new", "backup", "stage", "demo"]
SUFFIXES = ["1", "2", "3", "dev", "test", "old", "bak", "prod", "staging", "new", "api"]


async def doh_resolve(
    name: str,
    record_type: str = "A",
    provider: str = "cloudflare",
) -> dict[str, Any]:
    name = name.strip().lower().rstrip(".")
    rtype = (record_type or "A").upper()
    providers = {
        "cloudflare": f"https://cloudflare-dns.com/dns-query?name={quote(name)}&type={quote(rtype)}",
        "google": f"https://dns.google/resolve?name={quote(name)}&type={quote(rtype)}",
        "quad9": f"https://dns.quad9.net:5053/dns-query?name={quote(name)}&type={quote(rtype)}",
    }
    url = providers.get(provider, providers["cloudflare"])
    resp = await http_request(url, headers={"Accept": "application/dns-json"})
    answers: list[dict[str, Any]] = []
    status = None
    if resp.get("body"):
        try:
            data = json.loads(resp["body"])
            status = data.get("Status")
            for ans in data.get("Answer") or []:
                answers.append(
                    {
                        "name": ans.get("name"),
                        "type": ans.get("type"),
                        "ttl": ans.get("TTL"),
                        "data": ans.get("data"),
                    }
                )
        except json.JSONDecodeError:
            pass
    return {
        "name": name,
        "type": rtype,
        "status": status,
        "answers": answers,
        "ok": status == 0 and len(answers) > 0,
        "provider": provider,
        "error": resp.get("error"),
        "elapsed_ms": resp.get("elapsed_ms"),
    }


async def brute(
    domain: str,
    wordlist: str = "",
    provider: str = "cloudflare",
    max_words: int = 100,
    record_type: str = "A",
) -> dict[str, Any]:
    domain = clean_domain(domain)
    words = [
        w.strip().lower()
        for w in (wordlist or "").replace(",", "\n").splitlines()
        if w.strip() and not w.startswith("#")
    ]
    if not words:
        words = list(DEFAULT_WORDLIST)
    words = words[: max(1, min(int(max_words), 300))]

    found = []
    tried = 0
    for w in words:
        w = re.sub(r"[^a-z0-9-]", "", w)
        if not w:
            continue
        fqdn = f"{w}.{domain}"
        tried += 1
        res = await doh_resolve(fqdn, record_type, provider=provider)
        if res.get("ok"):
            found.append({"host": fqdn, "records": res.get("answers")})
    return {
        "source": "doh-brute",
        "domain": domain,
        "tried": tried,
        "found": found,
        "count": len(found),
        "provider": provider,
    }


def mutate(subdomains: str, domain: str = "") -> dict[str, Any]:
    root = clean_domain(domain) if domain else ""
    seeds: list[str] = []
    for line in subdomains.replace(",", "\n").splitlines():
        s = line.strip().lower().rstrip(".")
        if not s:
            continue
        if root and is_sub(s, root):
            label = s[: -(len(root) + 1)] if s != root else ""
            if label:
                seeds.append(label)
        elif "." not in s:
            seeds.append(s)
        else:
            seeds.append(s.split(".")[0])

    out: set[str] = set()
    for s in seeds[:100]:
        base = s.split(".")[0]
        out.add(base)
        for p in PREFIXES:
            out.add(f"{p}-{base}")
            out.add(f"{p}{base}")
            out.add(f"{base}-{p}")
        for suf in SUFFIXES:
            out.add(f"{base}-{suf}")
            out.add(f"{base}{suf}")
        if "-" in base:
            out.add(base.replace("-", ""))
            parts = base.split("-")
            if len(parts) == 2:
                out.add(f"{parts[1]}-{parts[0]}")

    if root:
        fqdns = sorted({f"{label}.{root}" for label in out if label})
    else:
        fqdns = sorted(out)
    return {"seeds": seeds[:100], "permutations": fqdns[:1000], "count": min(len(fqdns), 1000), "domain": root or None}
