
"""
Subdomain enumeration sources — projectdiscovery/subfinder source catalog
+ SecLists DNS wordlist for brute.
"""

from __future__ import annotations

import gzip
import json
import re
from pathlib import Path
from typing import Any, Callable, Awaitable
from urllib.parse import quote

from .._http import http_request
from .. import policy

_DATA = Path(__file__).with_name("data")
_SOURCES_LIST = json.loads((_DATA / "subfinder_sources.json").read_text(encoding="utf-8"))
_WL: list[str] | None = None


def clean_domain(domain: str) -> str:
    d = (domain or "").strip().lower()
    d = re.sub(r"^https?://", "", d)
    d = d.split("/")[0].split("?")[0].split("#")[0]
    d = d.lstrip("*.")
    d = d.rstrip(".")
    return d


def is_sub(host: str, root: str) -> bool:
    host = clean_domain(host)
    root = clean_domain(root)
    return host == root or host.endswith("." + root)


def _wordlist() -> list[str]:
    global _WL
    if _WL is None:
        with gzip.open(_DATA / "subdomains-5k.txt.gz", "rt", encoding="utf-8") as f:
            _WL = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
    return _WL


def list_sources() -> dict[str, Any]:
    return {
        "ok": True,
        "count": len(_SOURCES_LIST),
        "sources": list(_SOURCES_LIST),
        "source": "projectdiscovery/subfinder pkg/subscraping/sources",
        "engine": "subenum",
        "equivalent": "subfinder",
    }


def list_wordlist(limit: int = 0) -> dict[str, Any]:
    rows = _wordlist()
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {
        "ok": True,
        "count": len(rows),
        "returned": len(out),
        "words": out,
        "source": "SecLists/Discovery/DNS/subdomains-top1million-5000.txt",
        "engine": "subenum",
    }


async def crtsh(domain: str, user_agent: str = "pyodide-security/subfinder/2.0") -> dict[str, Any]:
    """crt.sh passive source (subfinder crtsh equivalent)."""
    domain = clean_domain(domain)
    url = f"https://crt.sh/?q=%25.{quote(domain)}&output=json"
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "subdomains": [], "count": 0, "engine": "subenum"}
    resp = await http_request(url, headers={"User-Agent": user_agent})
    body = resp.get("body") or ""
    names: set[str] = set()
    try:
        data = json.loads(body)
        if isinstance(data, list):
            for row in data:
                nv = str(row.get("name_value") or "")
                for part in nv.split("\n"):
                    part = clean_domain(part)
                    if is_sub(part, domain):
                        names.add(part)
    except Exception:
        pass
    return {
        "ok": True,
        "domain": domain,
        "source": "crtsh",
        "count": len(names),
        "subdomains": sorted(names),
        "status": resp.get("status"),
        "engine": "subenum",
        "equivalent": "subfinder/crtsh",
    }


async def _source_stub(domain: str) -> dict[str, Any]:
    """Placeholder for sources that need API keys / non-HTTP in browser."""
    return {"ok": True, "subdomains": [], "count": 0, "error": "source requires API key or host-side adapter", "status": 0}


# subfinder source name -> callable (crtsh implemented; others stubbed honestly)
SOURCES: dict[str, Callable[..., Awaitable[dict[str, Any]]]] = {"crtsh": crtsh}
for _name in _SOURCES_LIST:
    if _name not in SOURCES:
        SOURCES[_name] = _source_stub


async def brute(
    domain: str,
    max_words: int = 100,
    user_agent: str = "pyodide-security/subfinder/2.0",
    **kwargs: Any,
) -> dict[str, Any]:
    """HTTP existence probe of wordlist.subdomain (browser-friendly)."""
    domain = clean_domain(domain)
    words = _wordlist()[: max(1, int(max_words))]
    found = []
    tested = 0
    headers = {"User-Agent": user_agent}
    for w in words:
        if not policy.can_request():
            break
        tested += 1
        host = f"{w}.{domain}"
        for scheme in ("https", "http"):
            url = f"{scheme}://{host}/"
            err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
            if err:
                continue
            resp = await http_request(url, headers=headers)
            st = resp.get("status") or 0
            if st:
                found.append({"host": host, "url": url, "status": st})
                break
    return {
        "ok": True,
        "domain": domain,
        "tested": tested,
        "tried": tested,
        "count": len(found),
        "found": found,
        "found_count": len(found),
        "wordlist_size": len(_wordlist()),
        "engine": "subenum",
        "source": "SecLists subdomains-top1million-5000",
    }
