"""
Cloud storage enumeration — cloud_enum-class conversion (initstring/cloud_enum).

Checks public cloud object-storage naming patterns:
  AWS S3, Azure Blob/File/Queue/Table/App Service, GCP buckets/appspots
Uses cloud_enum fuzz.txt mutations against a base name.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .._http import http_request
from .. import policy

_FUZZ = Path(__file__).with_name("fuzz.txt")

# Formats adapted from cloud_enum aws_checks / azure_checks / gcp_checks
AWS_FORMATS = [
    "https://{name}.s3.amazonaws.com",
    "https://{name}.s3-us-east-1.amazonaws.com",
    "https://{name}.s3.amazonaws.com/?list-type=2",
]
AZURE_FORMATS = [
    "https://{name}.blob.core.windows.net",
    "https://{name}.blob.core.windows.net/{name}",
    "https://{name}.file.core.windows.net",
    "https://{name}.queue.core.windows.net",
    "https://{name}.table.core.windows.net",
    "https://{name}.azurewebsites.net",
    "https://{name}.cloudapp.net",
    "https://{name}.database.windows.net",
]
GCP_FORMATS = [
    "https://storage.googleapis.com/{name}",
    "https://{name}.storage.googleapis.com",
    "https://{name}.appspot.com",
]


def _mutations(base: str, limit: int = 50) -> list[str]:
    base = (base or "").strip().lower().replace(" ", "")
    words = []
    if _FUZZ.exists():
        words = [w.strip() for w in _FUZZ.read_text(encoding="utf-8", errors="replace").splitlines() if w.strip()]
    out = [base]
    for w in words:
        if len(out) >= limit:
            break
        for cand in (f"{base}-{w}", f"{base}{w}", f"{w}-{base}", f"{w}{base}"):
            if cand not in out:
                out.append(cand)
            if len(out) >= limit:
                break
    return out[:limit]


def list_formats() -> dict[str, Any]:
    return {
        "ok": True,
        "aws": AWS_FORMATS,
        "azure": AZURE_FORMATS,
        "gcp": GCP_FORMATS,
        "fuzz_words": sum(1 for _ in _FUZZ.open()) if _FUZZ.exists() else 0,
        "source": "initstring/cloud_enum",
        "engine": "cloud",
        "equivalent": "cloud_enum",
    }


async def enumerate(
    name: str,
    providers: str = "aws,azure,gcp",
    max_mutations: int = 20,
    max_checks: int = 40,
    user_agent: str = "pyodide-security/cloud-enum/1.0",
) -> dict[str, Any]:
    """Enumerate cloud storage endpoints for a base name."""
    if not name or len(name) < 2:
        return {"ok": False, "error": "name required", "engine": "cloud"}

    prov = {p.strip().lower() for p in providers.split(",") if p.strip()}
    formats = []
    if "aws" in prov:
        formats.extend(("aws", f) for f in AWS_FORMATS)
    if "azure" in prov:
        formats.extend(("azure", f) for f in AZURE_FORMATS)
    if "gcp" in prov:
        formats.extend(("gcp", f) for f in GCP_FORMATS)

    muts = _mutations(name, limit=max(1, int(max_mutations)))
    headers = {"User-Agent": user_agent}
    found = []
    tested = 0
    for mut in muts:
        for provider, fmt in formats:
            if tested >= int(max_checks):
                break
            if not policy.can_request():
                break
            url = fmt.format(name=mut)
            # policy host check
            err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
            if err:
                continue
            tested += 1
            resp = await http_request(url, headers=headers)
            st = resp.get("status") or 0
            body = resp.get("body") or ""
            # Open / interesting signals
            interesting = False
            reason = []
            if st in (200, 204, 301, 302, 403):
                interesting = True
                reason.append(f"status={st}")
            if "ListBucketResult" in body or "<Contents>" in body:
                interesting = True
                reason.append("s3-list")
            if "BlobNotFound" not in body and st == 200 and provider == "azure":
                reason.append("azure-200")
            if interesting:
                found.append({
                    "url": url,
                    "name": mut,
                    "provider": provider,
                    "status": st,
                    "reasons": reason,
                    "length": len(body),
                })
        if tested >= int(max_checks):
            break
    return {
        "ok": True,
        "base_name": name,
        "mutations": len(muts),
        "tested": tested,
        "found": found,
        "found_count": len(found),
        "engine": "cloud",
        "equivalent": "cloud_enum",
        "source": "initstring/cloud_enum",
    }


# alias
scan = enumerate


async def check_bucket(url: str = "", name: str = "", user_agent: str = "pyodide-security/cloud-enum/1.0") -> dict:
    """Single-bucket check (legacy registry alias)."""
    if name and not url:
        return await enumerate(name=name, max_mutations=1, max_checks=12, user_agent=user_agent)
    if url:
        from .._http import http_request
        from .. import policy
        err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
        if err:
            return {"ok": False, "error": err, "engine": "cloud"}
        resp = await http_request(url, headers={"User-Agent": user_agent})
        body = resp.get("body") or ""
        st = resp.get("status") or 0
        open_ = st == 200 and ("ListBucketResult" in body or "<Contents>" in body or len(body) > 0)
        return {"ok": True, "url": url, "status": st, "open": open_, "length": len(body), "engine": "cloud"}
    return {"ok": False, "error": "url or name required", "engine": "cloud"}


def permute_buckets(name: str, max_mutations: int = 50) -> dict:
    """Legacy registry: return name mutations only (no network)."""
    muts = _mutations(name, limit=max_mutations)
    return {"ok": True, "base": name, "mutations": muts, "count": len(muts), "engine": "cloud", "source": "cloud_enum fuzz.txt"}
