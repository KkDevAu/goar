"""
Cloud storage exposure checks — S3Scanner / cloud_enum / BucketFinder class.

Providers: AWS S3, Google Cloud Storage, Azure Blob.
Features: existence, listability, public-read heuristics, name permutation.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from .._http import http_request
from .. import policy

_PERMUTE_SUFFIXES = [
    "", "-", "-dev", "-prod", "-production", "-staging", "-stage", "-test",
    "-qa", "-uat", "-backup", "-bak", "-assets", "-static", "-media", "-uploads",
    "-data", "-files", "-public", "-private", "-logs", "-log", "-cdn", "-img",
    "-images", "-docs", "-documents", "-web", "-www", "-s3", "-bucket",
]
_PERMUTE_PREFIXES = ["", "dev-", "prod-", "staging-", "test-", "backup-", "cdn-"]


def _analyze_s3(body: str, status: int) -> dict[str, Any]:
    body = body or ""
    open_list = "ListBucketResult" in body or "<Contents>" in body or "<Key>" in body
    no_such = "NoSuchBucket" in body or "NoSuchBucket" in body
    denied = "AccessDenied" in body or "AccessDenied" in body or status == 403
    exists = (not no_such) and (status not in (0, 404) or open_list)
    public_read = open_list or (status == 200 and not denied and len(body) > 40)
    return {
        "exists": bool(exists),
        "listable": bool(open_list),
        "public_read": bool(public_read),
        "access_denied": bool(denied),
        "not_found": bool(no_such) or status == 404,
    }


def _analyze_gcs(body: str, status: int) -> dict[str, Any]:
    body = body or ""
    open_list = '"items"' in body or "ListBucketResult" in body or '"name"' in body and status == 200
    denied = status == 403 or "AccessDenied" in body or "PermissionDenied" in body
    exists = status not in (0, 404)
    return {
        "exists": exists,
        "listable": bool(open_list),
        "public_read": bool(open_list) or (status == 200 and not denied),
        "access_denied": bool(denied),
        "not_found": status == 404,
    }


def _analyze_azure(body: str, status: int) -> dict[str, Any]:
    body = body or ""
    open_list = "<EnumerationResults" in body or "<Blob>" in body or "<Name>" in body
    denied = status == 403 or "AuthorizationFailure" in body or "PublicAccessNotPermitted" in body
    exists = status not in (0, 404) or open_list
    return {
        "exists": bool(exists),
        "listable": bool(open_list),
        "public_read": bool(open_list),
        "access_denied": bool(denied),
        "not_found": status == 404 and not open_list,
    }


async def check_bucket(
    name: str,
    providers: str = "s3,gcs,azure",
    user_agent: str = "pyodide-security/cloud-engine/2.0",
) -> dict[str, Any]:
    name = name.strip().lower().replace(" ", "-")
    if not name or not re_match_bucket(name):
        return {"ok": False, "error": f"invalid bucket name: {name}", "engine": "cloud"}

    want = {p.strip().lower() for p in providers.split(",") if p.strip()}
    headers = {"User-Agent": user_agent}
    results = []

    if "s3" in want or "aws" in want:
        urls = [
            f"https://{name}.s3.amazonaws.com/",
            f"https://{name}.s3.amazonaws.com/?list-type=2",
            f"https://s3.amazonaws.com/{quote(name)}/",
            f"https://{name}.s3.us-east-1.amazonaws.com/",
            f"https://{name}.s3.amazonaws.com/?max-keys=5",
        ]
        for url in urls:
            if not policy.can_request():
                break
            # cloud endpoints are public internet — still count budget
            resp = await http_request(url, headers=headers)
            body = resp.get("body") or ""
            st = int(resp.get("status") or 0)
            analysis = _analyze_s3(body, st)
            results.append({
                "provider": "aws-s3",
                "url": url,
                "status": st,
                **analysis,
                "evidence": body[:180].replace("\n", " "),
                "error": resp.get("error"),
            })
            if analysis["listable"] or analysis["public_read"]:
                break

    if "gcs" in want or "google" in want:
        urls = [
            f"https://storage.googleapis.com/{quote(name)}",
            f"https://storage.googleapis.com/{quote(name)}/",
            f"https://storage.googleapis.com/{quote(name)}?maxResults=5",
            f"https://www.googleapis.com/storage/v1/b/{quote(name)}/o",
        ]
        for url in urls:
            if not policy.can_request():
                break
            resp = await http_request(url, headers=headers)
            body = resp.get("body") or ""
            st = int(resp.get("status") or 0)
            analysis = _analyze_gcs(body, st)
            results.append({
                "provider": "gcs",
                "url": url,
                "status": st,
                **analysis,
                "evidence": body[:180].replace("\n", " "),
                "error": resp.get("error"),
            })
            if analysis["listable"] or analysis["public_read"]:
                break

    if "azure" in want:
        urls = [
            f"https://{name}.blob.core.windows.net/?comp=list",
            f"https://{name}.blob.core.windows.net/$web?restype=container&comp=list",
            f"https://{name}.blob.core.windows.net/{name}?restype=container&comp=list",
        ]
        for url in urls:
            if not policy.can_request():
                break
            resp = await http_request(url, headers=headers)
            body = resp.get("body") or ""
            st = int(resp.get("status") or 0)
            analysis = _analyze_azure(body, st)
            results.append({
                "provider": "azure-blob",
                "url": url,
                "status": st,
                **analysis,
                "evidence": body[:180].replace("\n", " "),
                "error": resp.get("error"),
            })
            if analysis["listable"] or analysis["public_read"]:
                break

    exposed = [r for r in results if r.get("listable") or r.get("public_read")]
    exists = [r for r in results if r.get("exists") and not r.get("not_found")]
    return {
        "ok": True,
        "name": name,
        "exposed": bool(exposed),
        "exists": bool(exists),
        "exposed_results": exposed,
        "results": results,
        "engine": "cloud",
        "version": "2.0",
        "equivalent": "S3Scanner / cloud_enum",
        "policy": policy.status(),
    }


def re_match_bucket(name: str) -> bool:
    import re
    # S3-ish: 3-63 chars, lowercase, digits, dots, hyphens
    return bool(re.match(r"^[a-z0-9][a-z0-9.\-]{1,61}[a-z0-9]$", name))


async def permute_buckets(
    company: str,
    providers: str = "s3,gcs",
    max_names: int = 20,
    user_agent: str = "pyodide-security/cloud-engine/2.0",
) -> dict[str, Any]:
    """
    Generate common bucket name permutations for a company/keyword and probe them.
    """
    base = company.strip().lower().replace(" ", "").replace("_", "-")
    base = "".join(c for c in base if c.isalnum() or c in "-.")
    if not base:
        return {"ok": False, "error": "company/keyword required", "engine": "cloud"}

    names: list[str] = []
    for pre in _PERMUTE_PREFIXES:
        for suf in _PERMUTE_SUFFIXES:
            candidate = f"{pre}{base}{suf}".strip("-.")
            if re_match_bucket(candidate) and candidate not in names:
                names.append(candidate)
            if len(names) >= max(1, min(int(max_names), 40)):
                break
        if len(names) >= max(1, min(int(max_names), 40)):
            break

    findings = []
    checked = []
    for name in names:
        if not policy.can_request():
            break
        res = await check_bucket(name, providers=providers, user_agent=user_agent)
        checked.append({"name": name, "exists": res.get("exists"), "exposed": res.get("exposed")})
        if res.get("exposed") or res.get("exists"):
            findings.append(res)

    return {
        "ok": True,
        "company": company,
        "generated": len(names),
        "checked": len(checked),
        "findings": findings,
        "summary": checked,
        "engine": "cloud",
        "version": "2.0",
        "equivalent": "cloud_enum",
        "policy": policy.status(),
    }
