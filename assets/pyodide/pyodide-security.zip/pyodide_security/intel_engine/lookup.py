"""Passive intel aggregator — CT + InternetDB + RDAP pointers."""
from __future__ import annotations
from typing import Any

async def lookup(target: str)->dict[str,Any]:
    from ..ct_engine import search as ct_search
    from ..rdap_engine import domain_rdap
    from ..internetdb_engine import lookup as idb
    out={"ok":True,"target":target,"engine":"intel"}
    # heuristic ip vs domain
    parts=target.strip().split(".")
    is_ip=len(parts)==4 and all(p.isdigit() and 0<=int(p)<=255 for p in parts if p.isdigit())
    try:
        if is_ip:
            out["internetdb"]=await idb(target)
        else:
            out["ct"]=await ct_search(target)
            out["rdap"]=await domain_rdap(target)
    except Exception as e:
        out["error"]=str(e)
    return out


async def urlhaus_url(url: str = "", query: str = ""):
    url = url or query
    if not url:
        return {"ok": False, "error": "url required", "engine": "intel", "source": "urlhaus"}
    from .._http import http_request
    from urllib.parse import quote
    endpoint=f"https://urlhaus-api.abuse.ch/v1/url/"
    resp=await http_request(endpoint, method="POST", headers={"Content-Type":"application/x-www-form-urlencoded"}, body=f"url={quote(url)}")
    return {"ok":True,"url":url,"status":resp.get("status"),"body":(resp.get("body") or "")[:2000],"engine":"intel","source":"urlhaus"}

async def threatfox_search(query: str):
    from .._http import http_request
    import json as _json
    resp=await http_request("https://threatfox-api.abuse.ch/api/v1/", method="POST", headers={"Content-Type":"application/json"}, body=_json.dumps({"query":"search_ioc","search_term":query}))
    return {"ok":True,"query":query,"status":resp.get("status"),"body":(resp.get("body") or "")[:2000],"engine":"intel","source":"threatfox"}

async def otx_domain(domain: str):
    from .._http import http_request
    from urllib.parse import quote
    resp=await http_request(f"https://otx.alienvault.com/api/v1/indicators/domain/{quote(domain)}/general", headers={"Accept":"application/json"})
    return {"ok":True,"domain":domain,"status":resp.get("status"),"body":(resp.get("body") or "")[:2000],"engine":"intel","source":"otx"}
