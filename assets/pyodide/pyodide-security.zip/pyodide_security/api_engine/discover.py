"""
API discovery — SecLists api-endpoints.txt conversion.
"""

from __future__ import annotations

import gzip
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .._http import http_request
from .. import policy

_PATH = Path(__file__).with_name("data") / "api-endpoints.txt.gz"
_EPS: list[str] | None = None


def _eps() -> list[str]:
    global _EPS
    if _EPS is None:
        with gzip.open(_PATH, "rt", encoding="utf-8") as f:
            _EPS = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
    return _EPS


def list_endpoints(limit: int = 0) -> dict[str, Any]:
    rows = _eps()
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {
        "ok": True,
        "count": len(rows),
        "returned": len(out),
        "endpoints": out,
        "source": "SecLists/Discovery/Web-Content/api/api-endpoints.txt",
        "engine": "api",
        "equivalent": "SecLists API endpoints",
    }


async def discover(
    url: str,
    max_endpoints: int = 40,
    user_agent: str = "pyodide-security/api-discover/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "api"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if not url.endswith("/"):
        url += "/"

    eps = _eps()[: max(1, int(max_endpoints))]
    headers = {"User-Agent": user_agent, "Accept": "application/json, */*"}
    found = []
    tested = 0
    for ep in eps:
        if not policy.can_request():
            break
        tested += 1
        target = urljoin(url, ep.lstrip("/"))
        resp = await http_request(target, headers=headers)
        st = resp.get("status") or 0
        if st in (200, 201, 301, 302, 401, 403, 405, 500):
            body = resp.get("body") or ""
            ct = (resp.get("headers") or {}).get("content-type") or (resp.get("headers") or {}).get("Content-Type") or ""
            found.append({
                "endpoint": ep,
                "url": target,
                "status": st,
                "content_type": ct,
                "length": len(body),
                "json_like": body.strip()[:1] in ("{", "["),
            })
    return {
        "ok": True,
        "url": url,
        "tested": tested,
        "found": found,
        "found_count": len(found),
        "endpoint_db": len(_eps()),
        "engine": "api",
        "source": "SecLists api-endpoints.txt",
    }
