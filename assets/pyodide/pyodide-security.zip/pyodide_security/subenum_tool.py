"""Back-compat shim → subenum_engine."""

from .subenum_engine import (
    brute,
    crtsh,
    doh_resolve,
    enumerate,
    list_sources,
    mutate,
)

__all__ = ["crtsh", "doh_resolve", "brute", "mutate", "enumerate", "list_sources"]
