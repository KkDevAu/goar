"""HTTP repeater — send arbitrary method/headers/body via shared transport."""
from __future__ import annotations
from typing import Any
from .._http import http_request
from .. import policy

async def send(url: str, method: str="GET", headers: str="", body: str="",
               user_agent: str="pyodide-security/repeater/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"repeater"}
    if not url.startswith(("http://","https://")): url="https://"+url
    hdrs={"User-Agent":user_agent}
    if headers:
        for line in headers.splitlines():
            if ":" in line:
                k,_,v=line.partition(":")
                hdrs[k.strip()]=v.strip()
    resp=await http_request(url, method=method or "GET", headers=hdrs, body=body or None)
    return {"ok":True,"request":{"url":url,"method":method,"headers":hdrs},"response":{
        "status":resp.get("status"),"headers":resp.get("headers"),"body":(resp.get("body") or "")[:20000],
        "elapsed_ms":resp.get("elapsed_ms"),"transport":resp.get("transport"),
        "via_libcurl":resp.get("via_libcurl"),"via_proxy":resp.get("via_proxy"),
    },"engine":"repeater","equivalent":"Burp Repeater"}

async def compare(url: str, method: str="GET", headers_a: str="", headers_b: str="", body: str="")->dict[str,Any]:
    a=await send(url, method, headers_a, body)
    b=await send(url, method, headers_b, body)
    ra=a.get("response") or {}; rb=b.get("response") or {}
    return {"ok":True,"a":ra,"b":rb,"status_diff":ra.get("status")!=rb.get("status"),
            "len_diff":len(ra.get("body") or "")-len(rb.get("body") or ""),"engine":"repeater"}
