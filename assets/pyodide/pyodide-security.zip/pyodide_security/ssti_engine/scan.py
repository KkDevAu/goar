"""
SSTI engine — tplmap-class conversion.

Engines ported from epinna/tplmap plugins/engines:
  dot, dust, ejs, erb, freemarker, jinja2, mako, marko,
  nunjucks, pug, slim, smarty, tornado, twig, velocity

Probe strategy matches tplmap render detection: inject arithmetic
expressions in engine-specific delimiters and check for evaluated results.
"""

from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request
from .. import policy

_ENG_PATH = Path(__file__).with_name("tplmap_engines.json")
_ENGINES: list[dict[str, Any]] | None = None

# Probe pairs: (payload_template with {a} {b}, expected a*b or a+b)
# Built per engine from tplmap render syntax
def _build_probes() -> list[dict[str, Any]]:
    probes = []
    a, b = 7, 9
    expected = str(a * b)  # 63
    templates = [
        ("jinja2", "{{" + f"{a}*{b}" + "}}", expected, ["jinja2", "twig"]),
        ("jinja2-sp", "${" + f"{a}*{b}" + "}", expected, ["jinja2", "freemarker"]),
        ("twig", "{{" + f"{a}*{b}" + "}}", expected, ["twig", "jinja2"]),
        ("freemarker", "${" + f"{a}*{b}" + "}", expected, ["freemarker"]),
        ("freemarker2", "#{" + f"{a}*{b}" + "}", expected, ["freemarker"]),
        ("smarty", "{" + f"{a}*{b}" + "}", expected, ["smarty"]),
        ("smarty2", "{$smarty.version}", "Smarty", ["smarty"]),
        ("mako", "${" + f"{a}*{b}" + "}", expected, ["mako"]),
        ("tornado", "{{" + f"{a}*{b}" + "}}", expected, ["tornado", "jinja2"]),
        ("erb", "<%= " + f"{a}*{b}" + " %>", expected, ["erb"]),
        ("erb2", "#{" + f"{a}*{b}" + "}", expected, ["erb"]),
        ("velocity", "#set($x=" + f"{a}*{b}" + ")$x", expected, ["velocity"]),
        ("ejs", "<%= " + f"{a}*{b}" + " %>", expected, ["ejs"]),
        ("pug", "#{" + f"{a}*{b}" + "}", expected, ["pug"]),
        ("nunjucks", "{{" + f"{a}*{b}" + "}}", expected, ["nunjucks", "jinja2"]),
        ("dust", "{" + f"{a}*{b}" + "}", expected, ["dust"]),
        ("marko", "${" + f"{a}*{b}" + "}", expected, ["marko"]),
        ("dot", "{{=" + f"{a}*{b}" + "}}", expected, ["dot"]),
        ("slim", "#{" + f"{a}*{b}" + "}", expected, ["slim"]),
        ("jinja-err", "{{7*'7'}}", "7777777", ["jinja2"]),
        ("twig-err", "{{7*'7'}}", "49", ["twig"]),
    ]
    for eng, payload, expect, tags in templates:
        probes.append({
            "id": eng,
            "payload": payload,
            "expect": expect,
            "engines": tags,
            "a": a,
            "b": b,
        })
    return probes



_PROBES = _build_probes()


def _engines() -> list[dict[str, Any]]:
    global _ENGINES
    if _ENGINES is None:
        _ENGINES = json.loads(_ENG_PATH.read_text(encoding="utf-8"))
    return _ENGINES


def list_engines() -> dict[str, Any]:
    eng = _engines()
    return {
        "ok": True,
        "count": len(eng),
        "engines": [{"id": e["id"], "render": e.get("render"), "levels": e.get("levels")} for e in eng],
        "source": "epinna/tplmap plugins/engines",
        "engine": "ssti",
        "equivalent": "tplmap",
    }


def list_payloads() -> dict[str, Any]:
    return {
        "ok": True,
        "count": len(_PROBES),
        "payloads": _PROBES,
        "source": "tplmap render probes",
        "engine": "ssti",
    }


def list_payloads_pat() -> dict[str, Any]:
    try:
        from .. import pat_data
        rows = pat_data.get("ssti")
        return {"ok": True, "payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/SSTI"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


async def scan(
    url: str,
    parameter: str = "",
    max_payloads: int = 0,
    user_agent: str = "pyodide-security/tplmap/1.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "ssti"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    param = parameter
    if not param:
        for c in ("q", "s", "search", "name", "template", "page", "id", "lang", "msg"):
            if c in params:
                param = c
                break
        if not param and params:
            param = next(iter(params))
        if not param:
            return {"ok": False, "error": "no parameter to inject", "engine": "ssti"}

    probes = _PROBES
    if max_payloads and max_payloads > 0:
        probes = probes[: int(max_payloads)]

    base = await http_request(url, headers={"User-Agent": user_agent})
    base_body = base.get("body") or ""
    findings = []
    tested = 0
    for pr in probes:
        if not policy.can_request():
            break
        tested += 1
        inj = dict(params)
        inj[param] = pr["payload"]
        new_q = urlencode(inj)
        test_url = urlunparse((p.scheme, p.netloc, p.path, p.params, new_q, p.fragment))
        resp = await http_request(test_url, headers={"User-Agent": user_agent})
        body = resp.get("body") or ""
        expect = str(pr["expect"])
        if expect and expect in body and expect not in base_body:
            findings.append({
                "parameter": param,
                "payload": pr["payload"],
                "probe": pr["id"],
                "engines": pr["engines"],
                "evidence": expect,
                "status": resp.get("status"),
            })
    return {
        "ok": True,
        "url": url,
        "parameter": param,
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "vulnerable": bool(findings),
        "engine": "ssti",
        "equivalent": "tplmap",
        "tplmap_engines": len(_engines()),
    }
