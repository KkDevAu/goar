"""Email security — SPF / DMARC / DKIM discovery via DoH TXT."""
from __future__ import annotations
import json
from typing import Any
from urllib.parse import quote
from .._http import http_request
from ..subenum_engine.sources import clean_domain

async def _txt(name: str, provider: str="cloudflare")->list[str]:
    url=f"https://cloudflare-dns.com/dns-query?name={quote(name)}&type=TXT"
    if provider=="google":
        url=f"https://dns.google/resolve?name={quote(name)}&type=TXT"
    resp=await http_request(url, headers={"Accept":"application/dns-json"})
    out=[]
    try:
        data=json.loads(resp.get("body") or "{}")
        for ans in data.get("Answer") or []:
            if ans.get("type") in (16,"TXT") or ans.get("data"):
                d=str(ans.get("data") or "").strip().strip('"')
                out.append(d)
    except Exception:
        pass
    return out

async def check(domain: str, provider: str="cloudflare")->dict[str,Any]:
    domain=clean_domain(domain)
    spf=await _txt(domain, provider)
    dmarc=await _txt(f"_dmarc.{domain}", provider)
    # common DKIM selectors
    dkim={}
    for sel in ("default","google","selector1","selector2","k1","s1","s2","dkim","mail","smtp"):
        recs=await _txt(f"{sel}._domainkey.{domain}", provider)
        if recs:
            dkim[sel]=recs
    spf_rec=[r for r in spf if "v=spf1" in r.lower()]
    dmarc_rec=[r for r in dmarc if "v=dmarc1" in r.lower()]
    issues=[]
    if not spf_rec: issues.append({"issue":"missing SPF","severity":"medium"})
    else:
        if "+all" in spf_rec[0].lower(): issues.append({"issue":"SPF +all (permissive)","severity":"high"})
        if "~all" in spf_rec[0].lower(): issues.append({"issue":"SPF softfail ~all","severity":"low"})
    if not dmarc_rec: issues.append({"issue":"missing DMARC","severity":"medium"})
    else:
        pol=dmarc_rec[0].lower()
        if "p=none" in pol: issues.append({"issue":"DMARC p=none","severity":"low"})
        if "p=reject" not in pol and "p=quarantine" not in pol:
            issues.append({"issue":"DMARC weak policy","severity":"medium"})
    if not dkim: issues.append({"issue":"no common DKIM selectors found","severity":"info"})
    return {"ok":True,"domain":domain,"spf":spf_rec,"dmarc":dmarc_rec,"dkim":dkim,
            "issues":issues,"issue_count":len(issues),"engine":"emailsec","equivalent":"SPF/DMARC/DKIM check"}
