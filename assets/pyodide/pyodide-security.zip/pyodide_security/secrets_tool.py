"""gitleaks / trufflehog-class secret detection — regex rules + Shannon entropy."""

from __future__ import annotations

import math
import re
from typing import Any

# Production-style rules (id, description, severity, regex, entropy_gate optional)
_RULES: list[tuple[str, str, str, re.Pattern[str], float | None]] = [
    ("aws-access-key", "AWS Access Key ID", "critical", re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"), None),
    ("aws-secret-key", "AWS Secret Access Key (context)", "critical", re.compile(r"(?i)(aws_secret_access_key|aws_secret_key|secret_access_key)\s*[:=]\s*['\"]?([A-Za-z0-9/+=]{40})['\"]?"), None),
    ("aws-mws", "AWS MWS Auth Token", "high", re.compile(r"amzn\.mws\.[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"), None),
    ("github-pat", "GitHub personal access token", "critical", re.compile(r"\bghp_[A-Za-z0-9]{36,}\b"), None),
    ("github-oauth", "GitHub OAuth token", "critical", re.compile(r"\bgho_[A-Za-z0-9]{36,}\b"), None),
    ("github-fine-grained", "GitHub fine-grained PAT", "critical", re.compile(r"\bgithub_pat_[A-Za-z0-9_]{20,}\b"), None),
    ("github-app", "GitHub App token", "critical", re.compile(r"\b(ghu|ghs)_[A-Za-z0-9]{36,}\b"), None),
    ("gitlab-pat", "GitLab PAT", "critical", re.compile(r"\bglpat-[A-Za-z0-9\-_]{20,}\b"), None),
    ("gitlab-runner", "GitLab runner token", "high", re.compile(r"\bGR1348941[A-Za-z0-9\-_]{20,}\b"), None),
    ("slack-token", "Slack token", "critical", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"), None),
    ("slack-webhook", "Slack webhook", "high", re.compile(r"https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]+"), None),
    ("discord-webhook", "Discord webhook", "high", re.compile(r"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_-]+"), None),
    ("discord-token", "Discord bot token", "critical", re.compile(r"\b[MN][A-Za-z0-9]{23,}\.[\w-]{6}\.[\w-]{27,}\b"), None),
    ("google-api", "Google API key", "high", re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"), None),
    ("google-oauth", "Google OAuth", "high", re.compile(r"\bya29\.[0-9A-Za-z\-_]{20,}\b"), None),
    ("firebase", "Firebase URL", "medium", re.compile(r"https://[a-z0-9-]+\.firebaseio\.com", re.I), None),
    ("stripe-key", "Stripe secret key", "critical", re.compile(r"\b(sk|rk)_(live|test)_[0-9a-zA-Z]{20,}\b"), None),
    ("stripe-pub", "Stripe publishable key", "medium", re.compile(r"\bpk_(live|test)_[0-9a-zA-Z]{20,}\b"), None),
    ("twilio", "Twilio API key", "high", re.compile(r"\bSK[0-9a-fA-F]{32}\b"), None),
    ("sendgrid", "SendGrid API key", "critical", re.compile(r"\bSG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}\b"), None),
    ("mailgun", "Mailgun API key", "high", re.compile(r"\bkey-[0-9a-zA-Z]{32}\b"), None),
    ("mailchimp", "Mailchimp API key", "high", re.compile(r"\b[0-9a-f]{32}-us[0-9]{1,2}\b"), None),
    ("private-key", "PEM private key header", "critical", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"), None),
    ("pgp-private", "PGP private key block", "critical", re.compile(r"-----BEGIN PGP PRIVATE KEY BLOCK-----"), None),
    ("jwt", "JWT token", "medium", re.compile(r"\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"), None),
    ("heroku-key", "Heroku API key", "critical", re.compile(r"(?i)heroku.*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"), None),
    ("npm-token", "NPM access token", "critical", re.compile(r"\bnpm_[A-Za-z0-9]{36,}\b"), None),
    ("pypi-token", "PyPI token", "critical", re.compile(r"\bpypi-[A-Za-z0-9_\-]{20,}\b"), None),
    ("digitalocean", "DigitalOcean token", "critical", re.compile(r"\bdop_v1_[a-f0-9]{64}\b"), None),
    ("shopify-token", "Shopify access token", "critical", re.compile(r"\bshpat_[a-fA-F0-9]{32}\b"), None),
    ("shopify-shared", "Shopify shared secret", "high", re.compile(r"\bshpss_[a-fA-F0-9]{32}\b"), None),
    ("facebook-token", "Facebook access token", "high", re.compile(r"\bEAA[A-Za-z0-9]{20,}\b"), None),
    ("twitter-bearer", "Twitter bearer token", "high", re.compile(r"(?i)(twitter|x\.com).*bearer\s+[A-Za-z0-9%]{20,}"), None),
    ("azure-storage", "Azure storage key context", "critical", re.compile(r"(?i)AccountKey\s*=\s*[A-Za-z0-9+/=]{40,}"), None),
    ("azure-client-secret", "Azure client secret context", "high", re.compile(r"(?i)(client_secret|azure_client_secret)\s*[:=]\s*['\"]?([A-Za-z0-9_.~-]{16,})['\"]?"), None),
    ("generic-api-key", "Generic API key assignment", "medium", re.compile(r"(?i)(api[_\-]?key|apikey|api_secret)\s*[:=]\s*['\"]([A-Za-z0-9_\-]{16,})['\"]"), 3.5),
    ("generic-secret", "Generic secret assignment", "medium", re.compile(r"(?i)(secret|passwd|password|token)\s*[:=]\s*['\"]([^'\"]{8,})['\"]"), 3.5),
    ("basic-auth-url", "Basic auth embedded in URL", "high", re.compile(r"://[A-Za-z0-9_\-]+:[^@\s]{3,}@"), None),
    ("password-in-url", "password= in query", "high", re.compile(r"(?i)[?&](password|passwd|pwd|secret)=([^&\s]{3,})"), None),
    ("openai-key", "OpenAI API key", "critical", re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"), None),
    ("anthropic-key", "Anthropic API key", "critical", re.compile(r"\bsk-ant-[A-Za-z0-9\-_]{20,}\b"), None),
    ("huggingface", "HuggingFace token", "high", re.compile(r"\bhf_[A-Za-z0-9]{20,}\b"), None),
    ("databricks", "Databricks token", "high", re.compile(r"\bdapi[a-f0-9]{32}\b"), None),
    ("square-token", "Square access token", "critical", re.compile(r"\bsq0atp-[0-9A-Za-z\-_]{22,}\b"), None),
    ("square-secret", "Square secret", "critical", re.compile(r"\bsq0csp-[0-9A-Za-z\-_]{22,}\b"), None),
    ("paypal-braintree", "PayPal Braintree token", "high", re.compile(r"access_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}"), None),
    ("rsa-key-assignment", "Private key assignment", "critical", re.compile(r"(?i)(private_key|rsa_private)\s*[:=]\s*['\"]?-----BEGIN"), None),
]



def _shannon(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def _mask(s: str) -> str:
    if len(s) <= 8:
        return "*" * len(s)
    return f"{s[:4]}…{s[-4:]}"


def scan(text: str, min_entropy: float = 3.5) -> dict[str, Any]:
    if text is None:
        raise ValueError("text is required")
    findings: list[dict[str, Any]] = []
    lines = text.splitlines() or [text]

    for line_no, line in enumerate(lines, 1):
        for rid, desc, sev, rx, ent_gate in _RULES:
            for m in rx.finditer(line):
                match = m.group(0)
                # prefer last group if assignment-style
                secret = m.group(m.lastindex) if m.lastindex else match
                ent = round(_shannon(secret), 3)
                if ent_gate is not None and ent < ent_gate:
                    continue
                findings.append(
                    {
                        "rule_id": rid,
                        "description": desc,
                        "severity": sev,
                        "line": line_no,
                        "column": m.start() + 1,
                        "match_masked": _mask(secret),
                        "match_length": len(secret),
                        "entropy": ent,
                        "context": line.strip()[:160],
                    }
                )

        # high-entropy token hunt (base64/hex-like)
        for m in re.finditer(r"\b[A-Za-z0-9+/=_\-]{32,}\b", line):
            token = m.group(0)
            if any(f["line"] == line_no and f["column"] == m.start() + 1 for f in findings):
                continue
            ent = _shannon(token)
            if ent >= max(min_entropy, 4.5) and len(token) >= 32:
                findings.append(
                    {
                        "rule_id": "high-entropy",
                        "description": "High-entropy string (possible secret)",
                        "severity": "low",
                        "line": line_no,
                        "column": m.start() + 1,
                        "match_masked": _mask(token),
                        "match_length": len(token),
                        "entropy": round(ent, 3),
                        "context": line.strip()[:160],
                    }
                )

    sev_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    findings.sort(key=lambda f: (sev_rank.get(f["severity"], 9), f["line"]))
    summary = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in findings:
        summary[f["severity"]] = summary.get(f["severity"], 0) + 1

    return {
        "findings": findings,
        "count": len(findings),
        "summary": summary,
        "lines_scanned": len(lines),
    }
