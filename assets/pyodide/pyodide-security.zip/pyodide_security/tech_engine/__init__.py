from .fingerprint_compat import fingerprint_headers_body
try:
    from .detect import detect, list_technologies
except Exception:
    detect = None
    list_technologies = None

# keep older rules if present
try:
    from .rules import *  # noqa
except Exception:
    pass
try:
    from .scan import *  # noqa
except Exception:
    pass

__all__ = ["detect", "list_technologies"]
