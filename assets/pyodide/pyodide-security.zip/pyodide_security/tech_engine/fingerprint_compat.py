
"""Registry-compatible fingerprint helper."""
from __future__ import annotations
from typing import Any

def fingerprint_headers_body(headers: str | dict = "", body: str = "", url: str = "") -> dict[str, Any]:
    """Offline Wappalyzer-style match against header/body text (no network)."""
    from .detect import _fps, _match_tech
    hdrs: dict[str, str] = {}
    if isinstance(headers, dict):
        hdrs = {str(k): str(v) for k, v in headers.items()}
    elif isinstance(headers, str) and headers.strip():
        for line in headers.splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                hdrs[k.strip()] = v.strip()
    matches = []
    for tech in _fps():
        m = _match_tech(tech, body or "", hdrs, url or "")
        if m:
            matches.append(m)
    matches.sort(key=lambda x: -x.get("confidence", 0))
    return {
        "ok": True,
        "technologies": matches,
        "count": len(matches),
        "fingerprint_db": len(_fps()),
        "engine": "tech",
        "source": "dochne/wappalyzer",
    }
