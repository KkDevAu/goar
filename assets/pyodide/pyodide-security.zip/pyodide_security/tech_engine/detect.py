"""
Technology detection — Wappalyzer fingerprints from dochne/wappalyzer.

Source: https://github.com/dochne/wappalyzer (technologies/*.json)
~3900 technology fingerprints: headers, html, scripts, cookies, meta, url.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

from .._http import http_request
from .. import policy

_DATA = Path(__file__).resolve().parent / "data" / "wappalyzer.json"


@lru_cache(maxsize=1)
def _fps() -> list[dict]:
    return json.loads(_DATA.read_text(encoding="utf-8"))


def list_technologies(limit: int = 20) -> dict[str, Any]:
    rows = _fps()
    return {
        "total": len(rows),
        "sample": [r["name"] for r in rows[: max(1, min(int(limit), 50))]],
        "source": "dochne/wappalyzer src/technologies",
    }


def _compile_patterns(val) -> list[tuple[re.Pattern, str | None]]:
    """Wappalyzer patterns may be str or list; optional \\;version:"""
    if val is None:
        return []
    if isinstance(val, dict):
        # headers: {Server: nginx\\;version:\1}
        out = []
        for k, v in val.items():
            out.append((k, v))
        return out  # special-cased by caller
    items = val if isinstance(val, list) else [val]
    compiled = []
    for item in items:
        if not isinstance(item, str):
            continue
        # strip version hint
        pat = item.split("\\;")[0]
        ver = None
        if "version:" in item:
            m = re.search(r"version:(.+)$", item)
            ver = m.group(1) if m else None
        try:
            compiled.append((re.compile(pat, re.I | re.S), ver))
        except re.error:
            compiled.append((re.compile(re.escape(pat), re.I), ver))
    return compiled


def _match_tech(tech: dict, body: str, headers: dict, url: str) -> dict | None:
    hits = []
    # headers
    hdrs = tech.get("headers")
    if isinstance(hdrs, dict):
        for hname, pattern in hdrs.items():
            hval = ""
            for k, v in headers.items():
                if k.lower() == hname.lower():
                    hval = str(v)
                    break
            if not hval:
                continue
            pat = str(pattern).split("\\;")[0]
            try:
                if re.search(pat, hval, re.I):
                    hits.append(f"header:{hname}")
            except re.error:
                if pat.lower() in hval.lower():
                    hits.append(f"header:{hname}")
    # html
    for rx, _ in _compile_patterns(tech.get("html")):
        if rx.search(body or ""):
            hits.append("html")
            break
    # scripts
    for rx, _ in _compile_patterns(tech.get("scripts")):
        if rx.search(body or ""):
            hits.append("script")
            break
    # cookies
    cookies = headers.get("set-cookie") or headers.get("Set-Cookie") or ""
    ck = tech.get("cookies")
    if isinstance(ck, dict):
        for cname, pattern in ck.items():
            if cname.lower() in cookies.lower():
                hits.append(f"cookie:{cname}")
    elif ck:
        for rx, _ in _compile_patterns(ck):
            if rx.search(cookies):
                hits.append("cookie")
                break
    # meta
    meta = tech.get("meta")
    if isinstance(meta, dict):
        for name, pattern in meta.items():
            m = re.search(rf'<meta[^>]+(?:name|property)=["\']{re.escape(name)}["\'][^>]+content=["\']([^"\']+)', body or "", re.I)
            if not m:
                m = re.search(rf'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:name|property)=["\']{re.escape(name)}["\']', body or "", re.I)
            if m:
                pat = str(pattern).split("\\;")[0]
                try:
                    if re.search(pat, m.group(1), re.I):
                        hits.append(f"meta:{name}")
                except re.error:
                    if pat.lower() in m.group(1).lower():
                        hits.append(f"meta:{name}")
    # url
    for rx, _ in _compile_patterns(tech.get("url")):
        if rx.search(url or ""):
            hits.append("url")
            break
    if not hits:
        return None
    return {
        "technology": tech.get("name"),
        "evidence": hits,
        "confidence": min(100, 40 + 15 * len(hits)),
        "implies": tech.get("implies") or [],
        "cats": tech.get("cats") or [],
    }


async def detect(url: str, user_agent: str = "pyodide-security/wappalyzer/1.0") -> dict[str, Any]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    headers = {"User-Agent": user_agent}
    resp = await http_request(url, headers=headers)
    body = resp.get("body") or ""
    rh = {str(k): str(v) for k, v in (resp.get("headers") or {}).items()}
    matches = []
    for tech in _fps():
        m = _match_tech(tech, body, rh, url)
        if m:
            matches.append(m)
    matches.sort(key=lambda x: -x["confidence"])
    return {
        "ok": True,
        "url": url,
        "status": resp.get("status"),
        "technologies": matches,
        "count": len(matches),
        "fingerprint_db": len(_fps()),
        "engine": "tech",
        "version": "3.0-wappalyzer",
        "equivalent": "Wappalyzer",
        "source": "https://github.com/dochne/wappalyzer",
        "policy": policy.status(),
    }
