"""
Payload agent — port of sqlmap lib/core/agent.py substitution logic.

Placeholders handled (from settings.py / agent.cleanupPayload):
  [RANDNUM], [RANDNUM1], ...  → random int
  [RANDSTR], [RANDSTR1], ...  → random alpha
  [SLEEPTIME]                 → sleep seconds
  [ORIGINAL] / [ORIGVALUE]    → original parameter value
  [GENERIC_SQL_COMMENT]       → comment terminator
  [DELIMITER]                 → ,
  [COLSTART] / [COLSTOP]      → union markers
  [INFERENCE]                 → left as-is for inference vectors (detection only)
"""
from __future__ import annotations

import random
import re
import string


def random_int(length: int = 4) -> int:
    return random.randint(10 ** (length - 1), 10 ** length - 1)


def random_str(length: int = 4) -> str:
    return "".join(random.choice(string.ascii_lowercase) for _ in range(length))


def cleanup_payload(
    payload: str,
    original: str = "1",
    sleeptime: int = 3,
) -> str:
    """Port of agent.cleanupPayload / adjustLateValues essentials."""
    if not payload:
        return payload

    def _randnum(m: re.Match) -> str:
        return str(random_int(4))

    def _randstr(m: re.Match) -> str:
        return random_str(4)

    payload = re.sub(r"\[RANDNUM\d*\]", _randnum, payload, flags=re.I)
    payload = re.sub(r"\[RANDSTR\d*\]", _randstr, payload, flags=re.I)
    payload = payload.replace("[SLEEPTIME]", str(int(sleeptime)))
    payload = payload.replace("[ORIGINAL]", original)
    payload = payload.replace("[ORIGVALUE]", original)
    payload = payload.replace("[GENERIC_SQL_COMMENT]", "-- ")
    payload = payload.replace("[DELIMITER]", ",")
    payload = payload.replace("[COLSTART]", "")
    payload = payload.replace("[COLSTOP]", "")
    # Inference left for extraction phase — for detection use true condition
    payload = payload.replace("[INFERENCE]", "1=1")
    return payload


def apply_boundary(payload: str, prefix: str, suffix: str, original: str = "1") -> str:
    """Combine boundary prefix + payload + suffix around original value style."""
    prefix = cleanup_payload(prefix or "", original=original)
    suffix = cleanup_payload(suffix or "", original=original)
    payload = cleanup_payload(payload, original=original)
    # where=1 style: original + prefix + payload + suffix
    return f"{original}{prefix}{payload}{suffix}"
