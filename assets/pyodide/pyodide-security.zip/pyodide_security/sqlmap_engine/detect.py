"""Response comparison + technique confirmation (sqlmap detection logic)."""

from __future__ import annotations

import re
from typing import Any

from .fingerprint import fingerprint


def _jaccard_lines(a: str, b: str, limit: int = 400) -> float:
    sa = set((a or "").splitlines()[:limit])
    sb = set((b or "").splitlines()[:limit])
    if not sa and not sb:
        return 1.0
    return len(sa & sb) / (len(sa | sb) or 1)


def _ratio(a: int, b: int) -> float:
    if a == 0 and b == 0:
        return 1.0
    return min(a, b) / max(a, b) if max(a, b) else 1.0


def analyze_pair(
    baseline: dict[str, Any],
    test: dict[str, Any],
    payload: str = "",
    technique_hint: str = "",
    expected_sleep_ms: float = 0,
) -> dict[str, Any]:
    """
    Compare baseline request vs injected request.
    baseline/test: {status, body, headers, elapsed_ms}
    """
    b_body = baseline.get("body") or ""
    t_body = test.get("body") or ""
    b_status = int(baseline.get("status") or 0)
    t_status = int(test.get("status") or 0)
    b_ms = float(baseline.get("elapsed_ms") or 0)
    t_ms = float(test.get("elapsed_ms") or 0)
    t_headers = test.get("headers") or {}

    signals: list[dict[str, Any]] = []
    fp = fingerprint(body=t_body, headers=t_headers, status=t_status)

    # Error-based
    if fp["sqli_error_based"]:
        signals.append(
            {
                "technique": "E",
                "confidence": min(98, 70 + 5 * len(fp["dbms_candidates"][0]["evidence"])),
                "message": f"DBMS error signature matched ({fp['likely_dbms']})",
                "dbms": fp["likely_dbms"],
                "version_hint": fp.get("likely_version"),
            }
        )
        # try extract ~data~ from extractvalue/updatexml style
        m = re.search(r"~([^~]{1,200})~", t_body)
        if m:
            signals.append(
                {
                    "technique": "E",
                    "confidence": 95,
                    "message": "Error-based data reflection",
                    "extracted": m.group(1),
                }
            )

    # Boolean / content
    len_b, len_t = len(b_body), len(t_body)
    jac = _jaccard_lines(b_body, t_body)
    if b_status != t_status and t_status != 0:
        signals.append(
            {
                "technique": "B",
                "confidence": 65,
                "message": f"HTTP status {b_status} → {t_status}",
            }
        )
    if abs(len_t - len_b) > max(40, int(len_b * 0.04)):
        signals.append(
            {
                "technique": "B",
                "confidence": 60,
                "message": f"Body length delta {len_t - len_b} ({len_b}→{len_t})",
            }
        )
    if jac < 0.90:
        signals.append(
            {
                "technique": "B",
                "confidence": int(45 + (1 - jac) * 45),
                "message": f"Line Jaccard similarity {jac:.3f}",
            }
        )

    # Time-based
    sleep_threshold = expected_sleep_ms * 0.75 if expected_sleep_ms else 2500
    if t_ms - b_ms >= sleep_threshold:
        conf = 85 if expected_sleep_ms else 75
        signals.append(
            {
                "technique": "T",
                "confidence": conf,
                "message": f"Latency +{t_ms - b_ms:.0f}ms (base {b_ms:.0f} → {t_ms:.0f})",
            }
        )

    # Union hints
    if payload and re.search(r"(?i)UNION\s+(ALL\s+)?SELECT", payload):
        if t_status == 200 and (jac < 0.95 or abs(len_t - len_b) > 10):
            signals.append(
                {
                    "technique": "U",
                    "confidence": 50,
                    "message": "UNION payload accepted with content change — verify column count/types",
                }
            )
        if t_status >= 500 and not fp["sqli_error_based"]:
            signals.append(
                {
                    "technique": "U",
                    "confidence": 35,
                    "message": "UNION payload caused server error (wrong column count?)",
                }
            )

    # ORDER BY column count hint
    if payload and re.search(r"(?i)ORDER\s+BY\s+(\d+)", payload):
        m = re.search(r"(?i)ORDER\s+BY\s+(\d+)", payload)
        n = int(m.group(1)) if m else 0
        if t_status >= 500 or (jac < 0.8 and b_status == 200):
            signals.append(
                {
                    "technique": "U",
                    "confidence": 55,
                    "message": f"ORDER BY {n} appears to fail — column count may be < {n}",
                    "order_by": n,
                    "failed": True,
                }
            )
        elif t_status == 200 and jac > 0.9:
            signals.append(
                {
                    "technique": "U",
                    "confidence": 45,
                    "message": f"ORDER BY {n} appears to succeed — column count >= {n}",
                    "order_by": n,
                    "failed": False,
                }
            )

    # WAF
    if fp.get("possible_waf_block"):
        signals.append(
            {
                "technique": "WAF",
                "confidence": 80,
                "message": f"Possible WAF block ({fp.get('likely_waf')})",
                "waf": fp.get("likely_waf"),
            }
        )

    # filter by technique hint if provided
    if technique_hint:
        th = set(technique_hint.upper())
        signals = [s for s in signals if s["technique"] in th or s["technique"] == "WAF"]

    conf = max((s["confidence"] for s in signals if s["technique"] != "WAF"), default=0)
    injectable = conf >= 55 or any(s["technique"] == "E" and s["confidence"] >= 70 for s in signals)

    return {
        "injectable": injectable,
        "confidence": conf,
        "signals": signals,
        "fingerprint": fp,
        "similarity": round(jac, 4),
        "baseline": {"status": b_status, "length": len_b, "ms": b_ms},
        "test": {"status": t_status, "length": len_t, "ms": t_ms},
    }


def confirm_boolean(
    baseline: dict[str, Any],
    true_resp: dict[str, Any],
    false_resp: dict[str, Any],
) -> dict[str, Any]:
    """
    True/false pair confirmation — sqlmap boolean validation.
    True should match baseline; false should differ (or vice versa for OR).
    """
    bt = analyze_pair(baseline, true_resp, technique_hint="B")
    bf = analyze_pair(baseline, false_resp, technique_hint="B")
    tf = analyze_pair(true_resp, false_resp, technique_hint="B")

    # Ideal: true ≈ baseline, false ≠ baseline, true ≠ false
    true_like_base = bt["similarity"] >= 0.92 and bt["baseline"]["status"] == bt["test"]["status"]
    false_diff_base = bf["similarity"] < 0.90 or bf["baseline"]["status"] != bf["test"]["status"]
    pair_diff = tf["similarity"] < 0.90 or true_resp.get("status") != false_resp.get("status")

    confirmed = pair_diff and (false_diff_base or not true_like_base)
    confidence = 0
    if pair_diff:
        confidence += 40
    if false_diff_base:
        confidence += 30
    if true_like_base:
        confidence += 25
    if abs(len(true_resp.get("body") or "") - len(false_resp.get("body") or "")) > 20:
        confidence += 5

    return {
        "confirmed": confirmed and confidence >= 55,
        "confidence": min(100, confidence),
        "true_like_baseline": true_like_base,
        "false_differs_baseline": false_diff_base,
        "true_false_differ": pair_diff,
        "true_vs_base": bt,
        "false_vs_base": bf,
        "true_vs_false": tf,
    }
