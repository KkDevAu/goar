
"""
sqlmap-compatible tampers — full scripts from sqlmapproject/sqlmap/tamper.
"""
from __future__ import annotations

import gzip
import json
import random
import re
import string
import binascii
from pathlib import Path
from typing import Any, Callable

try:
    xrange  # type: ignore
except NameError:
    xrange = range

class PRIORITY:
    LOWEST = -100
    LOWER = -50
    LOW = -10
    NORMAL = 0
    HIGH = 10
    HIGHER = 50
    HIGHEST = 100

class _Kb(dict):
    def __getattr__(self, k):
        return self.get(k)
    def __setattr__(self, k, v):
        self[k] = v

kb = _Kb()
kb.keywords = set()
conf = type("conf", (), {})()

def randomInt(n=4):
    return int("".join(str(random.randint(0 if i else 1, 9)) for i in range(max(1, int(n)))))

def randomStr(n=4, alphabet=string.ascii_letters):
    return "".join(random.choice(alphabet) for _ in range(max(1, int(n))))

_SOURCES: dict[str, str] | None = None
_TAMPERS: dict[str, Callable[..., str]] = {}
_LOAD_ERRORS: dict[str, str] = {}
_PATH = Path(__file__).with_name("data") / "tamper_sources.json.gz"


def _sources() -> dict[str, str]:
    global _SOURCES
    if _SOURCES is None:
        with gzip.open(_PATH, "rt", encoding="utf-8") as f:
            _SOURCES = json.load(f)
    return _SOURCES


def _prepare_source(src: str) -> str:
    lines = []
    for line in src.splitlines():
        if line.startswith("from lib.") or line.startswith("import lib."):
            continue
        lines.append(line)
    return "\n".join(lines)


def _load_all() -> None:
    if _TAMPERS:
        return
    g_base = {
        "random": random,
        "re": re,
        "string": string,
        "binascii": binascii,
        "kb": kb,
        "conf": conf,
        "randomInt": randomInt,
        "randomStr": randomStr,
        "xrange": xrange,
        "PRIORITY": PRIORITY,
        "True": True,
        "False": False,
        "None": None,
        "__builtins__": __builtins__,
    }
    for name, src in _sources().items():
        g = dict(g_base)
        try:
            code = _prepare_source(src)
            exec(compile(code, f"tamper/{name}.py", "exec"), g, g)
            fn = g.get("tamper")
            if callable(fn):
                _TAMPERS[name] = fn
            else:
                _LOAD_ERRORS[name] = "no tamper()"
        except Exception as e:
            _LOAD_ERRORS[name] = f"{type(e).__name__}: {e}"


def list_tampers() -> dict[str, Any]:
    _load_all()
    names = sorted(_TAMPERS.keys())
    return {
        "ok": True,
        "count": len(names),
        "tampers": names,
        "load_errors": len(_LOAD_ERRORS),
        "error_sample": dict(list(_LOAD_ERRORS.items())[:8]),
        "source": "sqlmapproject/sqlmap/tamper",
        "engine": "sqlmap",
        "equivalent": "sqlmap tampers",
    }


def apply_tamper(payload: str, name: str) -> str:
    _load_all()
    fn = _TAMPERS.get(name)
    if not fn:
        return payload
    try:
        out = fn(payload)
        return out if isinstance(out, str) else str(out)
    except TypeError:
        try:
            out = fn(payload, **{})
            return out if isinstance(out, str) else str(out)
        except Exception:
            return payload
    except Exception:
        return payload


def tamper(payload: str, scripts: str = "space2comment") -> dict[str, Any]:
    _load_all()
    names = [s.strip() for s in (scripts or "").split(",") if s.strip()] or ["space2comment"]
    out = payload
    applied = []
    for n in names:
        if n not in _TAMPERS:
            applied.append({"name": n, "error": "unknown tamper"})
            continue
        prev = out
        out = apply_tamper(out, n)
        applied.append({"name": n, "changed": out != prev})
    return {
        "ok": True,
        "original": payload,
        "tampered": out,
        "scripts": applied,
        "available": len(_TAMPERS),
        "engine": "sqlmap",
    }


def apply_tampers(payload: str, scripts: str = "space2comment") -> dict[str, Any]:
    return tamper(payload, scripts)
