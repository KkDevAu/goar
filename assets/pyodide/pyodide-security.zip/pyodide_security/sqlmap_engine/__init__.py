"""sqlmap-class engine — real corpus from sqlmapproject/sqlmap + full tamper scripts."""

from .scan import scan, list_payloads
from .loader import stats, tests, errors, boundaries
from .agent import cleanup_payload, apply_boundary

from .fingerprint import fingerprint
from .tampers import list_tampers, tamper, apply_tampers, apply_tamper
from .inject import discover_points, build_request
from .queries import list_dbms, get_query, enum_plan
from .extract import (
    extract_length_boolean,
    extract_string_boolean,
    build_union_payload,
    find_column_count,
)
from .detect import analyze_pair, confirm_boolean


def fingerprint_errors(text: str = "", headers: str = ""):
    return fingerprint(text, headers)


def analyze_response(baseline: str = "", response: str = ""):
    return analyze_pair({"body": baseline}, {"body": response})


def extract_params(url: str = "", data: str = ""):
    from urllib.parse import parse_qsl, urlparse
    params = dict(parse_qsl(urlparse(url).query, keep_blank_values=True))
    if data:
        params.update(dict(parse_qsl(data, keep_blank_values=True)))
    return {"params": list(params.keys()), "values": params}


def probe_point(url: str = "", parameter: str = ""):
    return {"url": url, "parameter": parameter, "note": "use sqlmap.scan for live probe"}


def offline_toolkit():
    return {"stats": stats(), "tampers": list_tampers(), "note": "sqlmap detection corpus + 84 tampers loaded"}


__all__ = [
    "scan", "list_payloads", "stats", "tests", "errors", "boundaries",
    "cleanup_payload", "apply_boundary",
    "fingerprint", "fingerprint_errors",
    "list_tampers", "tamper", "apply_tampers", "apply_tamper",
    "discover_points", "build_request",
    "list_dbms", "get_query", "enum_plan",
    "extract_length_boolean", "extract_string_boolean",
    "build_union_payload", "find_column_count",
    "analyze_pair", "confirm_boolean", "analyze_response",
    "extract_params", "probe_point", "offline_toolkit",
]
