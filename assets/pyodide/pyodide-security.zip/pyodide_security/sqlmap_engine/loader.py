"""Load sqlmap XML-derived payload/error/boundary data."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

_DATA = Path(__file__).resolve().parent / "data" / "sqlmap_payloads.json"


@lru_cache(maxsize=1)
def load() -> dict[str, Any]:
    return json.loads(_DATA.read_text(encoding="utf-8"))


def tests(
    techniques: str = "boolean_blind,error_based,time_blind,union_query,stacked_queries",
    level: int = 1,
    risk: int = 1,
    dbms: str = "",
) -> list[dict[str, Any]]:
    want = {t.strip().lower() for t in techniques.split(",") if t.strip()}
    out = []
    for t in load()["tests"]:
        if t["technique"] not in want:
            continue
        if int(t.get("level") or 1) > int(level):
            continue
        if int(t.get("risk") or 1) > int(risk):
            continue
        if dbms:
            dlist = [d.lower() for d in (t.get("dbms") or [])]
            if dlist and dbms.lower() not in " ".join(dlist):
                # allow tests with no dbms constraint
                if dlist:
                    continue
        out.append(t)
    return out


def errors() -> list[dict[str, Any]]:
    return list(load()["errors"])


def boundaries(level: int = 1) -> list[dict[str, Any]]:
    out = []
    for b in load()["boundaries"]:
        try:
            bl = int(b.get("level") or 1)
        except ValueError:
            bl = 1
        if bl <= int(level):
            out.append(b)
    return out


def stats() -> dict[str, Any]:
    data = load()
    by = {}
    for t in data["tests"]:
        by[t["technique"]] = by.get(t["technique"], 0) + 1
    return {
        "tests": len(data["tests"]),
        "by_technique": by,
        "errors": len(data["errors"]),
        "boundaries": len(data["boundaries"]),
        "source": "sqlmapproject/sqlmap data/xml/",
    }
