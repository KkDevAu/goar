"""
SQL injection detection — converted from sqlmapproject/sqlmap.

Source: https://github.com/sqlmapproject/sqlmap

Ports:
  - data/xml/payloads/*.xml  → 363 tests (boolean, error, time, union, stacked, inline)
  - data/xml/errors.xml      → 174 DBMS error signatures
  - data/xml/boundaries.xml  → 53 prefix/suffix boundaries
  - lib/core/agent.py        → placeholder cleanup + boundary application

Technique detection:
  - error-based: errors.xml regexp match on response body
  - boolean-blind: true vs false payload response comparison (len/status/content)
  - time-based: response time delta vs sleeptime (best-effort in browser)
  - union: order-by / column-count heuristics

Full extraction (DB dump, file read, OS shell) is out of scope for WASM —
this engine focuses on detection parity with sqlmap's test payload corpus.
"""
from __future__ import annotations

import re
import time
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request
from .. import policy
from .agent import apply_boundary, cleanup_payload
from .loader import boundaries, errors, stats, tests


# stype mapping from sqlmap
STYPE = {
    1: "boolean_blind",
    2: "error_based",
    3: "union_query",
    4: "stacked_queries",
    5: "time_blind",
    6: "inline_query",
}


def _inject_param(url: str, param: str, value: str, method: str, data: str) -> tuple[str, str]:
    """Return (url, body) with param set to value."""
    if method.upper() == "POST":
        q = dict(parse_qsl(data or "", keep_blank_values=True))
        if param not in q and data:
            q = dict(parse_qsl(data, keep_blank_values=True))
        q[param] = value
        return url, urlencode(q, doseq=True)
    p = urlparse(url)
    q = dict(parse_qsl(p.query, keep_blank_values=True))
    q[param] = value
    return urlunparse(p._replace(query=urlencode(q, doseq=True))), data or ""


def _match_errors(body: str) -> list[dict[str, str]]:
    hits = []
    for err in errors():
        try:
            if re.search(err["regexp"], body or "", re.I | re.S):
                hits.append({"dbms": err["dbms"], "fork": err.get("fork") or "", "regexp": err["regexp"]})
        except re.error:
            continue
    return hits


def _content_ratio(a: str, b: str) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    # quick similarity: length + shared prefix
    la, lb = len(a), len(b)
    if la == 0 or lb == 0:
        return 0.0
    ratio_len = min(la, lb) / max(la, lb)
    n = min(200, la, lb)
    shared = sum(1 for i in range(n) if a[i] == b[i]) / max(n, 1)
    return 0.5 * ratio_len + 0.5 * shared


async def scan(
    url: str,
    parameter: str = "",
    method: str = "GET",
    data: str = "",
    techniques: str = "BEUSTQ",
    level: int = 1,
    risk: int = 1,
    dbms: str = "",
    sleeptime: int = 3,
    max_tests: int = 40,
    user_agent: str = "pyodide-security/sqlmap/1.0",
) -> dict[str, Any]:
    """
    Detect SQLi using real sqlmap payload corpus.

    techniques: sqlmap-style letter codes
      B = boolean_blind, E = error_based, U = union_query,
      S = stacked_queries, T = time_blind, Q = inline_query
    level / risk: sqlmap level (1-5) and risk (1-3)
    """
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "sqlmap"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    # map letter codes → technique names
    tech_map = {
        "B": "boolean_blind",
        "E": "error_based",
        "U": "union_query",
        "S": "stacked_queries",
        "T": "time_blind",
        "Q": "inline_query",
    }
    codes = (techniques or "BEUSTQ").upper()
    tech_names = [tech_map[c] for c in codes if c in tech_map]
    if not tech_names:
        tech_names = ["boolean_blind", "error_based", "time_blind"]

    headers = {"User-Agent": user_agent}
    method = (method or "GET").upper()

    # resolve parameter
    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    if method == "POST":
        params = dict(parse_qsl(data or "", keep_blank_values=True)) or params
    param = parameter or (next(iter(params)) if params else "id")
    original = params.get(param, "1")

    # baseline
    base_url, base_body = _inject_param(url, param, original, method, data)
    t0 = time.time()
    if method == "POST":
        base = await http_request(
            base_url,
            method="POST",
            headers={**headers, "Content-Type": "application/x-www-form-urlencoded"},
            body=base_body,
        )
    else:
        base = await http_request(base_url, headers=headers)
    base_elapsed = time.time() - t0
    base_text = base.get("body") or ""
    base_status = int(base.get("status") or 0)
    base_len = len(base_text)

    corpus = tests(
        techniques=",".join(tech_names),
        level=int(level),
        risk=int(risk),
        dbms=dbms,
    )
    # prioritize lower level/risk
    corpus.sort(key=lambda t: (t.get("level", 1), t.get("risk", 1)))
    corpus = corpus[: max(1, min(int(max_tests), 120))]

    bnds = boundaries(level=int(level))
    # always include empty boundary
    if not any(not (b.get("prefix") or b.get("suffix")) for b in bnds):
        bnds = [{"prefix": "", "suffix": "", "level": "1"}] + bnds
    bnds = bnds[: max(1, min(6, int(level) + 2))]

    findings: list[dict[str, Any]] = []
    tested = 0
    dbms_hits: dict[str, int] = {}

    for test in corpus:
        if not policy.can_request():
            break
        tech = test["technique"]
        payload_templates = test.get("payloads") or []
        if not payload_templates and test.get("vector"):
            payload_templates = [test["vector"]]
        if not payload_templates:
            continue

        for boundary in bnds:
            if not policy.can_request():
                break
            if tested >= int(max_tests):
                break

            prefix = boundary.get("prefix") or ""
            suffix = boundary.get("suffix") or ""
            raw = payload_templates[0]
            injected = apply_boundary(raw, prefix, suffix, original=str(original))

            test_url, test_body = _inject_param(url, param, injected, method, data)
            t1 = time.time()
            if method == "POST":
                resp = await http_request(
                    test_url,
                    method="POST",
                    headers={**headers, "Content-Type": "application/x-www-form-urlencoded"},
                    body=test_body,
                )
            else:
                resp = await http_request(test_url, headers=headers)
            elapsed = time.time() - t1
            body = resp.get("body") or ""
            status = int(resp.get("status") or 0)
            tested += 1

            evidence: list[str] = []
            confidence = 0
            dbms_found = None

            # --- error-based ---
            if tech == "error_based" or True:
                err_hits = _match_errors(body)
                # only count new errors not in baseline
                base_errs = {e["regexp"] for e in _match_errors(base_text)}
                new_errs = [e for e in err_hits if e["regexp"] not in base_errs]
                if new_errs:
                    evidence.append(f"error_signature:{new_errs[0]['dbms']}")
                    confidence = max(confidence, 90)
                    dbms_found = new_errs[0]["dbms"]
                    dbms_hits[dbms_found] = dbms_hits.get(dbms_found, 0) + 1

            # --- boolean-blind ---
            if tech == "boolean_blind":
                # true payload already sent; craft false counterpart
                false_raw = raw
                for a, b in (("1=1", "1=2"), ("1=1", "0=1"), ("AND", "AND NOT")):
                    if a in false_raw:
                        false_raw = false_raw.replace(a, b, 1)
                        break
                else:
                    false_raw = raw + " AND 1=2"
                false_inj = apply_boundary(false_raw, prefix, suffix, original=str(original))
                false_url, false_body = _inject_param(url, param, false_inj, method, data)
                if policy.can_request():
                    if method == "POST":
                        fresp = await http_request(
                            false_url,
                            method="POST",
                            headers={**headers, "Content-Type": "application/x-www-form-urlencoded"},
                            body=false_body,
                        )
                    else:
                        fresp = await http_request(false_url, headers=headers)
                    tested += 1
                    fbody = fresp.get("body") or ""
                    # true response should differ from false
                    ratio_tf = _content_ratio(body, fbody)
                    ratio_base_true = _content_ratio(base_text, body)
                    ratio_base_false = _content_ratio(base_text, fbody)
                    if ratio_tf < 0.92 and abs(len(body) - len(fbody)) > max(10, int(0.02 * base_len)):
                        evidence.append(f"boolean_diff:true_false_ratio={ratio_tf:.2f}")
                        confidence = max(confidence, 75)
                    elif ratio_base_true > 0.95 and ratio_base_false < 0.90:
                        evidence.append("boolean_diff:true≈baseline,false≠baseline")
                        confidence = max(confidence, 70)

            # --- time-based ---
            if tech == "time_blind":
                # response time significantly above baseline + sleeptime*0.6
                threshold = base_elapsed + max(1.0, float(sleeptime) * 0.6)
                if elapsed >= threshold:
                    evidence.append(f"time_delay:{elapsed:.2f}s>=threshold:{threshold:.2f}s")
                    confidence = max(confidence, 65)
                    # retest once for confirmation
                    if policy.can_request() and confidence >= 65:
                        t2 = time.time()
                        if method == "POST":
                            r2 = await http_request(
                                test_url,
                                method="POST",
                                headers={**headers, "Content-Type": "application/x-www-form-urlencoded"},
                                body=test_body,
                            )
                        else:
                            r2 = await http_request(test_url, headers=headers)
                        e2 = time.time() - t2
                        tested += 1
                        if e2 >= threshold:
                            evidence.append(f"time_confirm:{e2:.2f}s")
                            confidence = max(confidence, 85)

            # --- union / stacked: look for status/length anomalies + errors ---
            if tech in ("union_query", "stacked_queries", "inline_query"):
                if status != base_status and status not in (0,):
                    evidence.append(f"status:{base_status}->{status}")
                    confidence = max(confidence, 40)
                if abs(len(body) - base_len) > max(80, int(base_len * 0.1)):
                    evidence.append(f"length:{base_len}->{len(body)}")
                    confidence = max(confidence, 45)

            if confidence >= 60 and evidence:
                findings.append({
                    "title": test.get("title"),
                    "technique": tech,
                    "stype": test.get("stype"),
                    "level": test.get("level"),
                    "risk": test.get("risk"),
                    "payload": injected[:200],
                    "boundary": {"prefix": prefix, "suffix": suffix},
                    "evidence": evidence,
                    "confidence": confidence,
                    "dbms": dbms_found,
                    "status": status,
                    "elapsed": round(elapsed, 3),
                })
                # for level 1, one solid finding per technique is enough to report
                if int(level) <= 1 and confidence >= 75:
                    break
        if tested >= int(max_tests):
            break

    findings.sort(key=lambda x: -x["confidence"])
    # primary dbms guess
    primary_dbms = None
    if dbms_hits:
        primary_dbms = max(dbms_hits, key=dbms_hits.get)

    return {
        "ok": True,
        "url": url,
        "parameter": param,
        "method": method,
        "original": original,
        "level": int(level),
        "risk": int(risk),
        "techniques": tech_names,
        "baseline_status": base_status,
        "baseline_length": base_len,
        "baseline_elapsed": round(base_elapsed, 3),
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "injectable": bool(findings),
        "dbms": primary_dbms,
        "dbms_hits": dbms_hits,
        "corpus_stats": stats(),
        "engine": "sqlmap",
        "version": "3.0-sqlmap",
        "equivalent": "sqlmapproject/sqlmap",
        "source": "https://github.com/sqlmapproject/sqlmap",
        "note": (
            "Detection uses real sqlmap payload/error/boundary XML. "
            "Data extraction, file R/W, and OS takeover are not ported (native sqlmap)."
        ),
        "policy": policy.status(),
    }


def list_payloads(
    techniques: str = "error_based,boolean_blind",
    level: int = 1,
    risk: int = 1,
    limit: int = 30,
) -> dict[str, Any]:
    rows = tests(techniques=techniques, level=level, risk=risk)[: max(1, min(int(limit), 100))]
    return {
        "count": len(rows),
        "payloads": [
            {
                "title": r["title"],
                "technique": r["technique"],
                "level": r["level"],
                "risk": r["risk"],
                "payloads": r["payloads"][:2],
                "dbms": r["dbms"],
            }
            for r in rows
        ],
        "stats": stats(),
        "source": "sqlmap data/xml/payloads/",
    }
