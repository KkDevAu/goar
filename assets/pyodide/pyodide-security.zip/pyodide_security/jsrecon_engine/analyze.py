"""JS/secret recon — gitleaks rule conversion (221 rules)."""
from __future__ import annotations
import gzip, json, re
from pathlib import Path
from typing import Any
from .._http import http_request
from .. import policy

_RULES=None
def _rules():
    global _RULES
    if _RULES is None:
        with gzip.open(Path(__file__).with_name("gitleaks_rules.json.gz"),"rt",encoding="utf-8") as f:
            _RULES=json.load(f)
    return _RULES

def list_rules(limit: int=0)->dict[str,Any]:
    rows=_rules()
    out=rows[:int(limit)] if limit and limit>0 else rows
    return {"ok":True,"count":len(rows),"returned":len(out),"rules":[{"id":r["id"],"description":r.get("description")} for r in out],
            "source":"gitleaks/gitleaks config/gitleaks.toml","engine":"jsrecon","equivalent":"gitleaks"}

def scan_text(text: str, max_hits: int=50)->dict[str,Any]:
    hits=[]
    for r in _rules():
        if len(hits)>=max_hits: break
        try:
            rx=re.compile(r["regex"], re.I|re.M)
        except re.error:
            continue
        for m in rx.finditer(text or ""):
            hits.append({"id":r["id"],"description":r.get("description"),"match":m.group(0)[:120],"offset":m.start()})
            if len(hits)>=max_hits: break
    return {"ok":True,"hit_count":len(hits),"hits":hits,"rule_db":len(_rules()),"engine":"jsrecon"}

async def analyze(url: str="", text: str="", user_agent: str="pyodide-security/gitleaks/1.0")->dict[str,Any]:
    if text:
        return {**scan_text(text), "mode":"text"}
    if not url:
        return {"ok":False,"error":"url or text required","engine":"jsrecon"}
    if not url.startswith(("http://","https://")): url="https://"+url
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"jsrecon"}
    resp=await http_request(url, headers={"User-Agent":user_agent})
    body=resp.get("body") or ""
    r=scan_text(body)
    r.update({"url":url,"status":resp.get("status"),"mode":"url","length":len(body)})
    return r
