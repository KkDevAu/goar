"""openssl x509 -text equivalent for PEM certificates (parse, not full path validate)."""

from __future__ import annotations

import base64
import hashlib
import re
from typing import Any

from ._der import (
    OID_NAMES,
    as_int,
    as_oid,
    as_time,
    parse_all,
    parse_extensions,
    parse_name,
    parse_tlv,
    DERError,
)


def _pem_to_der(pem: str) -> bytes:
    text = pem.strip()
    m = re.search(
        r"-----BEGIN ([A-Z0-9 ]+)-----\s*([A-Za-z0-9+/=\s]+)-----END \1-----",
        text,
        re.MULTILINE,
    )
    if not m:
        # maybe raw base64 DER
        cleaned = re.sub(r"\s+", "", text)
        try:
            return base64.b64decode(cleaned)
        except Exception as e:
            raise ValueError("expected PEM certificate or base64 DER") from e
    label = m.group(1)
    if "CERTIFICATE" not in label and "PUBLIC KEY" not in label:
        # still try
        pass
    body = re.sub(r"\s+", "", m.group(2))
    return base64.b64decode(body)


def parse(pem: str) -> dict[str, Any]:
    der = _pem_to_der(pem)
    fingerprints = {
        "sha256": hashlib.sha256(der).hexdigest(),
        "sha1": hashlib.sha1(der).hexdigest(),
        "md5": hashlib.md5(der).hexdigest(),
    }
    try:
        tag, cert_content, _ = parse_tlv(der, 0)
        if tag != 0x30:
            raise DERError("certificate is not a SEQUENCE")
        # Certificate ::= SEQUENCE { tbsCertificate, signatureAlgorithm, signature }
        parts = parse_all(cert_content)
        if len(parts) < 3:
            raise DERError("truncated certificate")
        tbs_tag, tbs, _ = parts[0][0], parts[0][1], None
        if parts[0][0] != 0x30:
            raise DERError("tbsCertificate missing")
        sig_alg = _parse_algorithm(parts[1][1]) if parts[1][0] == 0x30 else {}
        sig_bit = parts[2][1] if parts[2][0] == 0x03 else b""
        # skip unused bits byte
        sig_bytes = sig_bit[1:] if sig_bit else b""

        tbs_fields = parse_all(tbs)
        idx = 0
        version = 1
        if tbs_fields and tbs_fields[0][0] == 0xA0:  # [0] EXPLICIT version
            _, ver_body, _ = parse_tlv(tbs_fields[0][1], 0) if False else (0, b"", 0)
            # content of context is INTEGER
            inner = parse_all(tbs_fields[0][1])
            if inner and inner[0][0] == 0x02:
                version = as_int(inner[0][1]) + 1  # v1=0
            idx = 1

        serial = ""
        if idx < len(tbs_fields) and tbs_fields[idx][0] == 0x02:
            serial_int = as_int(tbs_fields[idx][1])
            serial = format(serial_int if serial_int >= 0 else int.from_bytes(tbs_fields[idx][1], "big"), "x")
            idx += 1

        if idx < len(tbs_fields) and tbs_fields[idx][0] == 0x30:
            # signature algorithm inside TBS
            idx += 1

        issuer = {}
        if idx < len(tbs_fields) and tbs_fields[idx][0] == 0x30:
            issuer = parse_name(tbs_fields[idx][1])
            idx += 1

        validity = {}
        if idx < len(tbs_fields) and tbs_fields[idx][0] == 0x30:
            times = parse_all(tbs_fields[idx][1])
            if len(times) >= 2:
                validity = {
                    "not_before": as_time(times[0][1]),
                    "not_after": as_time(times[1][1]),
                }
            idx += 1

        subject = {}
        if idx < len(tbs_fields) and tbs_fields[idx][0] == 0x30:
            subject = parse_name(tbs_fields[idx][1])
            idx += 1

        spki: dict[str, Any] = {}
        if idx < len(tbs_fields) and tbs_fields[idx][0] == 0x30:
            spki_parts = parse_all(tbs_fields[idx][1])
            if spki_parts and spki_parts[0][0] == 0x30:
                spki["algorithm"] = _parse_algorithm(spki_parts[0][1])
            if len(spki_parts) > 1 and spki_parts[1][0] == 0x03:
                key_bits = spki_parts[1][1]
                key_bytes = key_bits[1:] if key_bits else b""
                spki["public_key_bits"] = max(0, len(key_bytes) * 8 - (key_bits[0] if key_bits else 0))
                spki["public_key_sha256"] = hashlib.sha256(key_bytes).hexdigest()
            idx += 1

        extensions: list[dict[str, Any]] = []
        # remaining context-specific [3]
        for tag_i, body in tbs_fields[idx:]:
            if tag_i == 0xA3:
                # EXPLICIT extensions SEQUENCE
                inner = parse_all(body)
                if inner and inner[0][0] == 0x30:
                    extensions = parse_extensions(inner[0][1])
                else:
                    extensions = parse_extensions(body)

        return {
            "ok": True,
            "version": version,
            "serial_hex": serial,
            "issuer": issuer.get("_dn", ""),
            "issuer_fields": {k: v for k, v in issuer.items() if k != "_dn"},
            "subject": subject.get("_dn", ""),
            "subject_fields": {k: v for k, v in subject.items() if k != "_dn"},
            "validity": validity,
            "signature_algorithm": sig_alg,
            "subject_public_key": spki,
            "extensions": extensions,
            "fingerprint": fingerprints,
            "der_bytes": len(der),
            "signature_len_bytes": len(sig_bytes),
        }
    except DERError as e:
        return {
            "ok": False,
            "error": str(e),
            "fingerprint": fingerprints,
            "der_bytes": len(der),
        }


def _parse_algorithm(content: bytes) -> dict[str, str]:
    parts = parse_all(content)
    oid = ""
    if parts and parts[0][0] == 0x06:
        oid = as_oid(parts[0][1])
    return {"oid": oid, "name": OID_NAMES.get(oid, oid)}
