"""CyberChef-class encode/decode/detect chain — pure stdlib."""

from __future__ import annotations

import base64
import binascii
import html
import json
import re
import urllib.parse
from typing import Any

ENCODE_FORMATS = [
    "base64",
    "base64url",
    "base32",
    "hex",
    "url",
    "html",
    "unicode_escape",
    "ascii85",
    "jwt_segment",
]
DECODE_FORMATS = ENCODE_FORMATS[:]


def encode(data: str, format: str = "base64") -> dict[str, Any]:
    fmt = (format or "base64").lower()
    raw = data.encode("utf-8")
    if fmt == "base64":
        out = base64.b64encode(raw).decode("ascii")
    elif fmt == "base64url":
        out = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    elif fmt == "base32":
        out = base64.b32encode(raw).decode("ascii")
    elif fmt == "hex":
        out = raw.hex()
    elif fmt == "url":
        out = urllib.parse.quote(data, safe="")
    elif fmt == "html":
        out = html.escape(data, quote=True)
    elif fmt == "unicode_escape":
        out = data.encode("unicode_escape").decode("ascii")
    elif fmt == "ascii85":
        out = base64.a85encode(raw).decode("ascii")
    elif fmt == "jwt_segment":
        out = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    else:
        raise ValueError(f"unsupported format: {format}")
    return {"format": fmt, "output": out, "input_bytes": len(raw)}


def decode(data: str, format: str = "base64") -> dict[str, Any]:
    fmt = (format or "base64").lower()
    s = data.strip()
    if fmt == "base64":
        pad = (-len(s)) % 4
        raw = base64.b64decode(s + "=" * pad)
    elif fmt == "base64url":
        pad = (-len(s)) % 4
        raw = base64.urlsafe_b64decode(s + "=" * pad)
    elif fmt == "base32":
        pad = (-len(s)) % 8
        raw = base64.b32decode(s.upper() + "=" * pad, casefold=True)
    elif fmt == "hex":
        cleaned = re.sub(r"\s+", "", s)
        if cleaned.startswith(("0x", "0X")):
            cleaned = cleaned[2:]
        raw = bytes.fromhex(cleaned)
    elif fmt == "url":
        return {
            "format": fmt,
            "output": urllib.parse.unquote(s),
            "output_hex": urllib.parse.unquote_to_bytes(s).hex(),
        }
    elif fmt == "html":
        return {"format": fmt, "output": html.unescape(s)}
    elif fmt == "unicode_escape":
        return {"format": fmt, "output": s.encode("utf-8").decode("unicode_escape")}
    elif fmt == "ascii85":
        raw = base64.a85decode(s)
    elif fmt == "jwt_segment":
        pad = (-len(s)) % 4
        raw = base64.urlsafe_b64decode(s + "=" * pad)
    else:
        raise ValueError(f"unsupported format: {format}")

    try:
        text = raw.decode("utf-8")
        return {"format": fmt, "output": text, "output_hex": raw.hex(), "bytes": len(raw)}
    except UnicodeDecodeError:
        return {
            "format": fmt,
            "output": None,
            "output_hex": raw.hex(),
            "bytes": len(raw),
            "note": "binary result; see output_hex",
        }


def detect_chain(data: str, max_depth: int = 6) -> dict[str, Any]:
    """Peel stacked encodings heuristically (base64/hex/url)."""
    max_depth = max(1, min(int(max_depth), 12))
    layers: list[dict[str, Any]] = []
    current = data.strip()

    for depth in range(max_depth):
        kind = _guess(current)
        if kind == "plain":
            break
        try:
            result = decode(current, kind)
            nxt = result.get("output")
            if nxt is None or nxt == current:
                break
            layers.append({"depth": depth, "encoding": kind, "output_preview": str(nxt)[:200]})
            current = str(nxt)
        except Exception:
            break

    # try JSON parse final
    final_json = None
    try:
        final_json = json.loads(current)
    except Exception:
        pass

    return {
        "layers": layers,
        "final": current[:2000],
        "final_json": final_json,
        "depth": len(layers),
    }


def _guess(s: str) -> str:
    t = s.strip()
    if not t:
        return "plain"
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", t) and len(t) >= 8 and len(t) % 4 == 0:
        try:
            base64.b64decode(t, validate=True)
            return "base64"
        except Exception:
            pass
    if re.fullmatch(r"[A-Za-z0-9_-]+", t) and len(t) >= 8 and "." not in t:
        # maybe base64url
        try:
            pad = (-len(t)) % 4
            base64.urlsafe_b64decode(t + "=" * pad)
            if any(c in t for c in "-_"):
                return "base64url"
        except Exception:
            pass
    if re.fullmatch(r"(?:0x)?[a-fA-F0-9]+", t) and len(t.replace("0x", "")) % 2 == 0 and len(t) >= 8:
        return "hex"
    if "%" in t and re.search(r"%[0-9A-Fa-f]{2}", t):
        return "url"
    if "<" in t or ">" in t or "&" in t or "&#" in t:
        return "html"
    return "plain"
