"""Certificate Transparency search via crt.sh."""
from __future__ import annotations
import json
from typing import Any
from urllib.parse import quote
from .._http import http_request
from .. import policy
from ..subenum_engine.sources import clean_domain, is_sub

async def search(domain: str, user_agent: str="pyodide-security/ct/2.0")->dict[str,Any]:
    domain=clean_domain(domain)
    url=f"https://crt.sh/?q=%25.{quote(domain)}&output=json"
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"ct"}
    resp=await http_request(url, headers={"User-Agent":user_agent})
    names=set(); certs=[]
    try:
        data=json.loads(resp.get("body") or "[]")
        if isinstance(data, list):
            for row in data[:500]:
                nv=str(row.get("name_value") or "")
                for part in nv.split("\n"):
                    part=clean_domain(part)
                    if is_sub(part, domain):
                        names.add(part)
                certs.append({"id":row.get("id"),"issuer":row.get("issuer_name"),"not_before":row.get("not_before"),
                              "not_after":row.get("not_after"),"name_value":nv[:200]})
    except Exception as e:
        return {"ok":False,"error":str(e),"status":resp.get("status"),"engine":"ct"}
    return {"ok":True,"domain":domain,"subdomains":sorted(names),"subdomain_count":len(names),
            "certs_sample":certs[:20],"cert_count":len(certs),"engine":"ct","equivalent":"crt.sh CT"}
