"""robots.txt parser — Google/Bing robots exclusion standard."""
from __future__ import annotations
from typing import Any
from urllib.parse import urljoin
from .._http import http_request
from .. import policy

def parse_robots(text: str)->dict[str,Any]:
    agents={}; current=["*"]; sitemaps=[]; disallow=[]; allow=[]
    for raw in (text or "").splitlines():
        line=raw.split("#",1)[0].strip()
        if not line or ":" not in line: continue
        k,_,v=line.partition(":"); k=k.strip().lower(); v=v.strip()
        if k=="user-agent":
            current=[a.strip() for a in v.split(",") if a.strip()] or ["*"]
            for a in current:
                agents.setdefault(a,{"allow":[],"disallow":[]})
        elif k=="disallow":
            for a in current:
                agents.setdefault(a,{"allow":[],"disallow":[]})["disallow"].append(v)
            if v: disallow.append(v)
        elif k=="allow":
            for a in current:
                agents.setdefault(a,{"allow":[],"disallow":[]})["allow"].append(v)
            if v: allow.append(v)
        elif k=="sitemap":
            sitemaps.append(v)
    interesting=[p for p in disallow if any(x in p.lower() for x in ("admin","login","api","private","secret","backup","config","internal"))]
    return {"agents":agents,"sitemaps":sitemaps,"disallow_all":disallow,"allow_all":allow,"interesting_disallow":interesting}

async def scan(url: str, user_agent: str="pyodide-security/robots/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"robots"}
    if not url.startswith(("http://","https://")): url="https://"+url
    target=urljoin(url if url.endswith("/") else url+"/","robots.txt")
    resp=await http_request(target, headers={"User-Agent":user_agent})
    body=resp.get("body") or ""
    parsed=parse_robots(body) if resp.get("status")==200 else {}
    return {"ok":True,"url":target,"status":resp.get("status"),"exists":resp.get("status")==200,
            **parsed,"raw_length":len(body),"engine":"robots","equivalent":"robots.txt RFC"}
