"""Subdomain takeover fingerprints — subjack / nuclei-takeover class."""

from __future__ import annotations

from typing import Any

# service, cname_markers, body_fingerprints, status_optional
FINGERPRINTS: list[dict[str, Any]] = [
    {"service": "GitHub Pages", "cname": ["github.io", "github.map.fastly.net"], "body": ["There isn't a GitHub Pages site here", "For root URLs (like http://example.com/)"]},
    {"service": "Heroku", "cname": ["herokuapp.com", "herokudns.com"], "body": ["No such app", "herokucdn.com/error-pages", "no-such-app"]},
    {"service": "AWS S3", "cname": ["s3.amazonaws.com", "s3-website", "s3-website-"], "body": ["NoSuchBucket", "The specified bucket does not exist", "Code: NoSuchBucket"]},
    {"service": "AWS CloudFront", "cname": ["cloudfront.net"], "body": ["The request could not be satisfied", "Bad request", "ERROR: The request could not be satisfied"]},
    {"service": "Azure", "cname": ["azurewebsites.net", "cloudapp.azure.com", "trafficmanager.net", "blob.core.windows.net"], "body": ["404 Web Site not found", "Error 404 - Web app not found"]},
    {"service": "Shopify", "cname": ["myshopify.com"], "body": ["Sorry, this shop is currently unavailable", "Only one step left"]},
    {"service": "Fastly", "cname": ["fastly.net", "fastlylb.net"], "body": ["Fastly error: unknown domain", "Please check that this domain has been added to a service"]},
    {"service": "Pantheon", "cname": ["pantheonsite.io"], "body": ["404 error unknown site", "The gods are wise"]},
    {"service": "Tumblr", "cname": ["domains.tumblr.com"], "body": ["There's nothing here.", "Whatever you were looking for doesn't currently exist at this address"]},
    {"service": "WordPress.com", "cname": ["wordpress.com"], "body": ["Do you want to register", "doesn't exist"]},
    {"service": "Ghost", "cname": ["ghost.io"], "body": ["The thing you were looking for is no longer here", "errorcode\":\"domain_not_found"]},
    {"service": "Cargo Collective", "cname": ["cargocollective.com"], "body": ["If you're moving your domain away from Cargo", "404 Not Found"]},
    {"service": "Netlify", "cname": ["netlify.com", "netlify.app"], "body": ["Not Found - Request ID", "netlify"]},
    {"service": "Surge.sh", "cname": ["surge.sh"], "body": ["project not found", "project not found"]},
    {"service": "Bitbucket", "cname": ["bitbucket.io"], "body": ["Repository not found"]},
    {"service": "Unbounce", "cname": ["unbouncepages.com"], "body": ["The requested URL was not found on this server"]},
    {"service": "SmugMug", "cname": ["domains.smugmug.com"], "body": ["Page Not Found", "smugmug"]},
    {"service": "Zendesk", "cname": ["zendesk.com"], "body": ["Help Center Closed", "Oops, this help center no longer exists"]},
    {"service": "Teamwork", "cname": ["teamwork.com"], "body": ["Oops - We didn't find your site"]},
    {"service": "Help Scout", "cname": ["helpscoutdocs.com"], "body": ["No settings were found for this company"]},
    {"service": "Cargo", "cname": ["cargocollective.com"], "body": ["If you're moving your domain away from Cargo"]},
    {"service": "Statuspage", "cname": ["statuspage.io"], "body": ["Status page managed by Atlassian Statuspage", "You are being redirected"]},
    {"service": "Intercom", "cname": ["custom.intercom.help"], "body": ["This page is reserved for a Intercom"]},
    {"service": "Webflow", "cname": ["webflow.io", "proxy.webflow.com"], "body": ["The page you are looking for doesn't exist or has been moved", "webflow"]},
    {"service": "Kajabi", "cname": ["kajabi.com"], "body": ["The page you were looking for doesn't exist"]},
    {"service": "Thinkific", "cname": ["thinkific.com"], "body": ["You may have mistyped the address"]},
    {"service": "Tilda", "cname": ["tilda.ws"], "body": ["Please renew your subscription", "Domain has been assigned"]},
    {"service": "SmartJobBoard", "cname": ["jobs", "smartjobboard.com"], "body": ["This job board website is either expired"]},
    {"service": "Ngrok", "cname": ["ngrok.io"], "body": ["ngrok.io not found", "Tunnel .* not found"]},
    {"service": "Fly.io", "cname": ["fly.dev"], "body": ["404 Not Found", "fly.io"]},

    {"service": "DigitalOcean App", "cname": ["ondigitalocean.app"], "body": ["This App is currently unavailable", "digitalocean"]},
    {"service": "Pantheon", "cname": ["pantheonsite.io"], "body": ["404 error unknown site", "The gods are wise"]},
    {"service": "Ghost", "cname": ["ghost.io"], "body": ["The thing you were looking for is no longer here"]},
    {"service": "Cargo Collective", "cname": ["cargocollective.com"], "body": ["If you're moving your domain away from Cargo"]},
    {"service": "Feedpress", "cname": ["redirect.feedpress.me"], "body": ["The feed has not been found"]},
    {"service": "Surge.sh", "cname": ["surge.sh"], "body": ["project not found", "project does not exist"]},
    
    {"service": "Azure CloudApp", "cname": ["cloudapp.azure.com", "azurewebsites.net", "cloudapp.net"], "body": ["404 Web Site not found", "Error 404"]},
    {"service": "AWS ELB", "cname": ["elb.amazonaws.com"], "body": []},
    {"service": "AWS Global Accelerator", "cname": ["awsglobalaccelerator.com"], "body": []},
    {"service": "Google Cloud Run", "cname": ["run.app"], "body": ["404", "The requested URL was not found"]},
    {"service": "Firebase", "cname": ["firebaseapp.com", "web.app"], "body": ["Firebase Hosting Setup Complete", "doesn't exist"]},
    {"service": "Netlify", "cname": ["netlify.app", "netlify.com"], "body": ["Not Found - Request ID", "not found"]},
    {"service": "Vercel", "cname": ["vercel.app", "now.sh"], "body": ["The deployment could not be found", "DEPLOYMENT_NOT_FOUND"]},
    {"service": "Render", "cname": ["onrender.com"], "body": ["Not Found", "no service"]},
    {"service": "Railway", "cname": ["railway.app", "up.railway.app"], "body": ["Not Found", "railway"]},
    {"service": "Fly.io", "cname": ["fly.dev", "fly.io"], "body": ["404 Not Found"]},
    {"service": "Notion", "cname": ["notion.site"], "body": ["This site is currently unavailable", "notion"]},
    {"service": "Canny", "cname": ["canny.io"], "body": ["There is no such company", "Company Not Found"]},
    {"service": "Launchrock", "cname": ["launchrock.com"], "body": ["It looks like you may have taken a wrong turn"]},

]


def list_fingerprints() -> dict[str, Any]:
    return {
        "count": len(FINGERPRINTS),
        "services": [f["service"] for f in FINGERPRINTS],
        "fingerprints": [
            {"service": f["service"], "cname": f["cname"], "body_count": len(f["body"])}
            for f in FINGERPRINTS
        ],
    }


def match_body(body: str, headers: dict | None = None) -> list[dict[str, Any]]:
    body = body or ""
    hits = []
    for fp in FINGERPRINTS:
        for sig in fp["body"]:
            if sig.lower() in body.lower() or (sig.startswith("errorcode") and sig in body):
                hits.append({"service": fp["service"], "evidence": sig, "cname_hints": fp["cname"]})
                break
    return hits


def match_cname(cname: str) -> list[dict[str, Any]]:
    cname = (cname or "").lower().rstrip(".")
    hits = []
    for fp in FINGERPRINTS:
        for marker in fp["cname"]:
            if marker in cname:
                hits.append({"service": fp["service"], "cname": cname, "marker": marker, "vulnerable_if": fp["body"]})
                break
    return hits
