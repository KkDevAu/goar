"""
Subdomain takeover checker — subjack / nuclei / can-i-take-over-xyz class.

Flow:
  1. HTTP(S) fetch of candidate host
  2. Match body fingerprints against known dangling services
  3. Optional CNAME hint matching (when provided by caller)
"""

from __future__ import annotations

from typing import Any

from .._http import http_request
from .. import policy
from .fingerprints import list_fingerprints, match_body, match_cname


async def check(
    host: str = "",
    url: str = "",
    cname: str = "",
    user_agent: str = "pyodide-security/takeover-engine/2.0",
    schemes: str = "https,http",
) -> dict[str, Any]:
    err = None
    if not host and url:
        host = url
    host = (host or "").strip()
    host = host.replace("https://", "").replace("http://", "").split("/")[0]
    if not host:
        return {"ok": False, "error": "host required", "engine": "takeover"}

    # policy on first URL
    headers = {"User-Agent": user_agent}
    results = []
    body_hits_all = []

    for scheme in [s.strip() for s in schemes.split(",") if s.strip()]:
        url = f"{scheme}://{host}/"
        e = policy.check_url_for_active(url)
        if e:
            err = e
            continue
        if not policy.can_request():
            break
        resp = await http_request(url, headers=headers)
        body = resp.get("body") or ""
        hdrs = resp.get("headers") or {}
        hits = match_body(body, hdrs)
        body_hits_all.extend(hits)
        results.append({
            "url": url,
            "status": resp.get("status"),
            "error": resp.get("error"),
            "body_len": len(body),
            "server": hdrs.get("server") or hdrs.get("Server"),
            "hits": hits,
            "final_url": resp.get("final_url"),
        })
        if hits:
            break  # strong signal enough

    cname_hits = match_cname(cname) if cname else []
    # vulnerable if body fingerprint matched known dangling service
    vulnerable = bool(body_hits_all)
    # cname-only match is informational without body confirmation
    suspected = vulnerable or bool(cname_hits)

    return {
        "ok": True,
        "host": host,
        "cname": cname or None,
        "vulnerable": vulnerable,
        "suspected": suspected,
        "body_matches": body_hits_all,
        "cname_matches": cname_hits,
        "probes": results,
        "fingerprint_db": list_fingerprints()["count"],
        "engine": "takeover",
        "version": "2.0",
        "equivalent": "subjack / can-i-take-over-xyz / nuclei takeovers",
        "policy": policy.status(),
        "error_policy": err,
    }


async def check_many(
    hosts: str,
    user_agent: str = "pyodide-security/takeover-engine/2.0",
    max_hosts: int = 20,
) -> dict[str, Any]:
    """hosts: newline or comma separated."""
    items = []
    for line in hosts.replace(",", "\n").splitlines():
        h = line.strip()
        if h:
            items.append(h)
    items = items[: max(1, min(int(max_hosts), 50))]
    out = []
    for h in items:
        if not policy.can_request():
            break
        out.append(await check(h, user_agent=user_agent))
    vulns = [r for r in out if r.get("vulnerable")]
    return {
        "ok": True,
        "total": len(out),
        "vulnerable_count": len(vulns),
        "results": out,
        "engine": "takeover",
    }
