"""
Subdomain takeover fingerprints — from EdOverflow/can-i-take-over-yet research.

Each entry: service, fingerprint (body/cname indicators), status guidance.
"""
FINGERPRINTS = [
    {"service": "AWS/S3", "cname": ["s3.amazonaws.com", "s3-"], "body": ["NoSuchBucket", "The specified bucket does not exist"], "vulnerable": True},
    {"service": "GitHub Pages", "cname": ["github.io"], "body": ["There isn't a GitHub Pages site here", "For root URLs (like http://example.com/)"], "vulnerable": True},
    {"service": "Heroku", "cname": ["herokuapp.com", "herokudns.com"], "body": ["No such app", "no-such-app"], "vulnerable": True},
    {"service": "Shopify", "cname": ["myshopify.com"], "body": ["Sorry, this shop is currently unavailable"], "vulnerable": True},
    {"service": "Tumblr", "cname": ["tumblr.com"], "body": ["There's nothing here.", "Whatever you were looking for doesn't currently exist at this address"], "vulnerable": True},
    {"service": "WordPress.com", "cname": ["wordpress.com"], "body": ["Do you want to register"], "vulnerable": True},
    {"service": "Ghost", "cname": ["ghost.io"], "body": ["The thing you were looking for is no longer here"], "vulnerable": True},
    {"service": "Surge.sh", "cname": ["surge.sh"], "body": ["project not found"], "vulnerable": True},
    {"service": "Bitbucket", "cname": ["bitbucket.io"], "body": ["Repository not found"], "vulnerable": True},
    {"service": "Pantheon", "cname": ["pantheonsite.io"], "body": ["404 error unknown site"], "vulnerable": True},
    {"service": "Azure", "cname": ["azurewebsites.net", "cloudapp.azure.com", "trafficmanager.net", "blob.core.windows.net"], "body": ["404 Web Site not found"], "vulnerable": True},
    {"service": "Cargo Collective", "cname": ["cargocollective.com"], "body": ["404 Not Found"], "vulnerable": True},
    {"service": "Feedpress", "cname": ["redirect.feedpress.me"], "body": ["The feed has not been found"], "vulnerable": True},
    {"service": "Readme.io", "cname": ["readme.io"], "body": ["Project doesnt exist", "We're experiencing an unexpected server problem"], "vulnerable": True},
    {"service": "Statuspage", "cname": ["statuspage.io"], "body": ["Status page is locked", "You are being redirected"], "vulnerable": True},
    {"service": "Zendesk", "cname": ["zendesk.com"], "body": ["Help Center Closed"], "vulnerable": True},
    {"service": "Ngrok", "cname": ["ngrok.io"], "body": ["ngrok.io not found"], "vulnerable": True},
    {"service": "Netlify", "cname": ["netlify.app", "netlify.com"], "body": ["Not Found - Request ID"], "vulnerable": True},
    {"service": "Fly.io", "cname": ["fly.dev"], "body": ["404 Not Found"], "vulnerable": True},
    {"service": "Webflow", "cname": ["webflow.io"], "body": ["The page you are looking for doesn't exist or has been moved"], "vulnerable": True},
    {"service": "Help Scout", "cname": ["helpscoutdocs.com"], "body": ["No settings were found for this company"], "vulnerable": True},
    {"service": "JetBrains", "cname": ["youtrack.cloud"], "body": ["is not a registered InCloud YouTrack"], "vulnerable": True},
    {"service": "UserVoice", "cname": ["uservoice.com"], "body": ["This UserVoice subdomain is currently available"], "vulnerable": True},
    {"service": "Ghost (alt)", "cname": ["ghost.io"], "body": ["The thing you were looking for is no longer here", "The domain has not been configured"], "vulnerable": True},
    {"service": "Amazon CloudFront", "cname": ["cloudfront.net"], "body": ["Bad request", "ERROR: The request could not be satisfied"], "vulnerable": False},
    {"service": "Fastly", "cname": ["fastly.net"], "body": ["Fastly error: unknown domain"], "vulnerable": True},
    {"service": "Google Firebase", "cname": ["firebaseapp.com", "web.app"], "body": ["Firebase Hosting Setup Complete", "doesn't currently exist"], "vulnerable": True},
    {"service": "Intercom", "cname": ["custom.intercom.help"], "body": ["This page is reserved for a Intercom"], "vulnerable": True},
    {"service": "Campaign Monitor", "cname": ["createsend.com"], "body": ["Double check the URL"], "vulnerable": True},
    {"service": "DigitalOcean", "cname": ["digitalocean.com"], "body": ["Domain uses DO name servers with no records"], "vulnerable": True},
]
