"""bandit-class Python SAST — static security pattern scanner for source text."""

from __future__ import annotations

import ast
import re
from typing import Any


# AST-based checks
class _Visitor(ast.NodeVisitor):
    def __init__(self) -> None:
        self.findings: list[dict[str, Any]] = []

    def _add(self, node: ast.AST, rule: str, severity: str, message: str) -> None:
        self.findings.append(
            {
                "rule_id": rule,
                "severity": severity,
                "message": message,
                "line": getattr(node, "lineno", 0),
                "col": getattr(node, "col_offset", 0) + 1,
            }
        )

    def visit_Call(self, node: ast.Call) -> None:
        name = _call_name(node)
        dangerous = {
            "eval": ("B307", "critical", "Use of eval()"),
            "exec": ("B102", "critical", "Use of exec()"),
            "compile": ("B301", "high", "Use of compile() on dynamic code"),
            "pickle.loads": ("B301", "critical", "pickle.loads on untrusted data"),
            "pickle.load": ("B301", "critical", "pickle.load on untrusted data"),
            "yaml.load": ("B506", "critical", "yaml.load without Loader=SafeLoader"),
            "yaml.unsafe_load": ("B506", "critical", "yaml.unsafe_load"),
            "subprocess.call": ("B404", "high", "subprocess call — check shell=True"),
            "subprocess.run": ("B404", "high", "subprocess run — check shell=True"),
            "subprocess.Popen": ("B404", "high", "subprocess.Popen — check shell=True"),
            "os.system": ("B605", "critical", "os.system with potential shell injection"),
            "os.popen": ("B605", "critical", "os.popen"),
            "marshal.loads": ("B302", "high", "marshal.loads"),
            "hashlib.md5": ("B303", "medium", "Use of weak MD5 hash"),
            "hashlib.sha1": ("B303", "medium", "Use of weak SHA1 hash"),
            "random.random": ("B311", "medium", "Standard random for security-sensitive use"),
            "random.randint": ("B311", "medium", "Standard random for security-sensitive use"),
            "tempfile.mktemp": ("B306", "high", "Insecure mktemp"),
            "input": ("B322", "low", "input() in Python 2 was eval — ensure Py3"),
        }
        if name in dangerous:
            rid, sev, msg = dangerous[name]
            # refine subprocess shell=True
            if name.startswith("subprocess"):
                for kw in node.keywords:
                    if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                        self._add(node, "B602", "critical", f"{name} with shell=True")
                        break
                else:
                    self._add(node, rid, sev, msg)
            else:
                self._add(node, rid, sev, msg)
        if name in ("assert",):
            pass
        self.generic_visit(node)

    def visit_Assert(self, node: ast.Assert) -> None:
        self._add(node, "B101", "medium", "assert used for security checks (stripped with -O)")
        self.generic_visit(node)

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            if alias.name in ("telnetlib", "ftplib", "pickle", "cPickle", "marshall"):
                self._add(node, "B413", "medium", f"Import of potentially dangerous module {alias.name}")
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        # requests with verify=False handled in Call
        self.generic_visit(node)

    def visit_Call_extra(self) -> None:
        pass


def _call_name(node: ast.Call) -> str:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        parts: list[str] = []
        cur: ast.AST = func
        while isinstance(cur, ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        if isinstance(cur, ast.Name):
            parts.append(cur.id)
        parts.reverse()
        return ".".join(parts)
    return ""


# Also flag verify=False on any call
class _VerifyFalse(ast.NodeVisitor):
    def __init__(self, findings: list[dict[str, Any]]) -> None:
        self.findings = findings

    def visit_Call(self, node: ast.Call) -> None:
        for kw in node.keywords:
            if kw.arg == "verify" and isinstance(kw.value, ast.Constant) and kw.value.value is False:
                self.findings.append(
                    {
                        "rule_id": "B501",
                        "severity": "high",
                        "message": "TLS verification disabled (verify=False)",
                        "line": getattr(node, "lineno", 0),
                        "col": getattr(node, "col_offset", 0) + 1,
                    }
                )
        self.generic_visit(node)


_LINE_RULES: list[tuple[str, str, str, re.Pattern[str]]] = [
    ("B108", "medium", "Hardcoded /tmp path", re.compile(r"[\"']/tmp/")),
    ("B105", "high", "Possible hardcoded password string", re.compile(r"""(?i)password\s*=\s*['\"][^'\"]+['\"]""")),
    ("B106", "high", "Possible hardcoded password in function arg", re.compile(r"""(?i)password\s*=\s*['\"][^'\"]+['\"]""")),
    ("SQL001", "high", "Possible SQL string formatting", re.compile(r"""(?i)(execute|executemany)\s*\(\s*[f\"'].*%|f[\"'].*select\s+.*\{""")),
]


def scan(code: str) -> dict[str, Any]:
    if not code or not code.strip():
        raise ValueError("code is required")
    findings: list[dict[str, Any]] = []

    try:
        tree = ast.parse(code)
        v = _Visitor()
        v.visit(tree)
        findings.extend(v.findings)
        _VerifyFalse(findings).visit(tree)
        parse_ok = True
        parse_error = None
    except SyntaxError as e:
        parse_ok = False
        parse_error = f"SyntaxError: {e.msg} at line {e.lineno}"
        findings.append(
            {
                "rule_id": "parse-error",
                "severity": "info",
                "message": parse_error,
                "line": e.lineno or 0,
                "col": e.offset or 0,
            }
        )

    for i, line in enumerate(code.splitlines(), 1):
        for rid, sev, msg, rx in _LINE_RULES:
            if rx.search(line):
                # avoid exact duplicates
                if not any(f["line"] == i and f["rule_id"] == rid for f in findings):
                    findings.append(
                        {
                            "rule_id": rid,
                            "severity": sev,
                            "message": msg,
                            "line": i,
                            "col": 1,
                        }
                    )

    rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    findings.sort(key=lambda f: (rank.get(f["severity"], 9), f["line"]))
    summary: dict[str, int] = {}
    for f in findings:
        summary[f["severity"]] = summary.get(f["severity"], 0) + 1

    return {
        "parse_ok": parse_ok,
        "parse_error": parse_error,
        "findings": findings,
        "count": len(findings),
        "summary": summary,
        "engine": "ast+regex (bandit-class)",
    }
