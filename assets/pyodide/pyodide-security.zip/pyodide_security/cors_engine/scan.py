"""CORS scanner — converted from chenjj/CORScanner (common/corscheck.py)."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from .._http import http_request
from .. import policy
from .. import libcurl_bridge

_ORIGINS_PATH = Path(__file__).resolve().parent / "origins.json"

def _load_third_party_origins() -> list[str]:
    try:
        data = json.loads(_ORIGINS_PATH.read_text(encoding="utf-8"))
        return list(data.get("origins") or [])
    except Exception:
        return ["https://evil.com", "https://attacker.com"]

def _registered_domain(host: str) -> str:
    host = (host or "").lower().split(":")[0]
    parts = host.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else host

async def _check_cors_policy(url: str, test_origin: str, test_name: str, user_agent: str):
    headers = {"Origin": test_origin, "Cache-Control": "no-cache", "User-Agent": user_agent}
    resp = await http_request(url, headers=headers)
    if resp.get("error") and not resp.get("status"):
        return None
    hdrs = {str(k).lower(): str(v) for k, v in (resp.get("headers") or {}).items()}
    acao = hdrs.get("access-control-allow-origin", "")
    acac = hdrs.get("access-control-allow-credentials", "")
    if test_origin != "null":
        try:
            parsed = urlparse(acao)
            resp_origin = (parsed.scheme + "://" + parsed.netloc.split(":")[0]) if parsed.scheme else acao
        except Exception:
            resp_origin = acao
    else:
        resp_origin = acao
    if test_origin.lower() == resp_origin.lower() or acao.strip() == test_origin:
        credentials = "true" if acac.lower() == "true" else "false"
        return {"url": url, "type": test_name, "credentials": credentials, "origin": test_origin,
                "acao": acao, "status_code": resp.get("status"),
                "severity": "critical" if credentials == "true" else "high"}
    if acao.strip() == "*":
        return {"url": url, "type": test_name + "_wildcard", "credentials": "true" if acac.lower()=="true" else "false",
                "origin": test_origin, "acao": "*", "status_code": resp.get("status"),
                "severity": "critical" if acac.lower()=="true" else "medium"}
    return None

async def scan(url: str, user_agent: str = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36", stop_on_first: bool = False):
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "cors"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    parsed = urlparse(url)
    host = parsed.hostname or ""
    scheme = parsed.scheme or "https"
    reg = _registered_domain(host)
    transport = {"libcurl_ready": libcurl_bridge.is_ready(),
                 "note": "libcurl ready" if libcurl_bridge.is_ready() else "libcurl not ready — Origin may be incomplete"}
    findings, tests_run = [], []

    async def run_test(name, origin):
        if not policy.can_request():
            return False
        tests_run.append(name)
        result = await _check_cors_policy(url, origin, name, user_agent)
        if result:
            findings.append(result)
            return True
        return False

    # CORScanner test suite names
    await run_test("reflect_origin", "https://evil.com")
    if not (stop_on_first and findings):
        await run_test("prefix_match", f"https://{host}.evil.com")
        await run_test("suffix_match", f"https://evil{host}")
        await run_test("trust_null", "null")
        await run_test("include_match", f"https://evil{reg}")
        await run_test("trust_any_subdomain", f"https://any.{host}")
        if scheme == "https":
            await run_test("https_trust_http", f"http://{host}")
        for origin in _load_third_party_origins()[:12]:
            if not policy.can_request():
                break
            await run_test("custom_third_parties", origin)
        for char in ['_', '-', '"', '{', '}', '+', '^', '%60', '!', '~'][:8]:
            if not policy.can_request():
                break
            await run_test("special_characters_bypass", f"{scheme}://{host.split(':')[0]}{char}.evil.com")

    return {"ok": True, "url": url, "host": host, "vulnerable": bool(findings),
            "findings": findings, "finding_count": len(findings), "tests_run": tests_run,
            "transport": transport, "engine": "cors", "version": "3.0-corscanner",
            "equivalent": "chenjj/CORScanner", "source": "https://github.com/chenjj/CORScanner",
            "policy": policy.status()}

def list_probes(host: str = "example.com"):
    reg = _registered_domain(host)
    probes = [
        {"id": "reflect_origin", "origin": "https://evil.com"},
        {"id": "prefix_match", "origin": f"https://{host}.evil.com"},
        {"id": "suffix_match", "origin": f"https://evil{host}"},
        {"id": "trust_null", "origin": "null"},
        {"id": "include_match", "origin": f"https://evil{reg}"},
        {"id": "trust_any_subdomain", "origin": f"https://any.{host}"},
        {"id": "https_trust_http", "origin": f"http://{host}"},
    ]
    for o in _load_third_party_origins()[:5]:
        probes.append({"id": "custom_third_parties", "origin": o})
    return {"count": len(probes), "probes": probes, "source": "CORScanner"}
