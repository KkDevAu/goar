"""Well-known URI discovery — IANA + common security paths."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from urllib.parse import urljoin
from .._http import http_request
from .. import policy

_PATHS=json.loads(Path(__file__).with_name("paths.json").read_text())

def list_paths()->dict[str,Any]:
    return {"ok":True,"count":len(_PATHS),"paths":_PATHS,"source":"IANA well-known + common","engine":"wellknown"}

async def scan(url: str, max_paths: int=0, user_agent: str="pyodide-security/wellknown/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"wellknown"}
    if not url.startswith(("http://","https://")): url="https://"+url
    if not url.endswith("/"): url+="/"
    paths=_PATHS if not max_paths else _PATHS[:int(max_paths)]
    found=[]; tested=0
    for path in paths:
        if not policy.can_request(): break
        tested+=1
        target=urljoin(url, path.lstrip("/"))
        resp=await http_request(target, headers={"User-Agent":user_agent})
        st=resp.get("status") or 0
        if st in (200,301,302,401,403):
            found.append({"path":path,"url":target,"status":st,"length":len(resp.get("body") or "")})
    return {"ok":True,"url":url,"tested":tested,"found":found,"found_count":len(found),"path_db":len(_PATHS),"engine":"wellknown"}
