from .scan import capability_matrix, list_mutations, scan

detect = scan
list_payloads = list_mutations

__all__ = ["scan", "detect", "list_mutations", "list_payloads", "capability_matrix"]
