"""
Nuclei-class scanner — uses packed templates corpus (paths/words/status/regex).
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .._http import http_request
from .. import policy

_TEMPLATES: list[dict[str, Any]] | None = None
_PATH = Path(__file__).with_name("data") / "templates.json"


def _templates() -> list[dict[str, Any]]:
    global _TEMPLATES
    if _TEMPLATES is None:
        _TEMPLATES = json.loads(_PATH.read_text(encoding="utf-8"))
    return _TEMPLATES


def list_templates(
    severity: str = "",
    category: str = "",
    limit: int = 0,
    q: str = "",
) -> dict[str, Any]:
    rows = _templates()
    if severity:
        sev = {s.strip().lower() for s in severity.split(",")}
        rows = [t for t in rows if (t.get("severity") or "").lower() in sev]
    if category:
        rows = [t for t in rows if category.lower() in (t.get("category") or "").lower()]
    if q:
        ql = q.lower()
        rows = [t for t in rows if ql in (t.get("id") or "").lower() or ql in (t.get("name") or "").lower()]
    total = len(rows)
    if limit and limit > 0:
        rows = rows[: int(limit)]
    return {
        "ok": True,
        "count": total,
        "returned": len(rows),
        "templates": [{"id": t.get("id"), "name": t.get("name"), "severity": t.get("severity"),
                       "category": t.get("category"), "method": t.get("method"), "paths": len(t.get("paths") or [])}
                      for t in rows],
        "template_db": len(_templates()),
        "source": "projectdiscovery/nuclei-templates (packed)",
        "engine": "nuclei",
    }


def stats() -> dict[str, Any]:
    rows = _templates()
    sev: dict[str, int] = {}
    cat: dict[str, int] = {}
    for t in rows:
        s = (t.get("severity") or "unknown").lower()
        sev[s] = sev.get(s, 0) + 1
        c = (t.get("category") or "other").lower()
        cat[c] = cat.get(c, 0) + 1
    return {"ok": True, "total": len(rows), "by_severity": sev, "by_category": dict(list(cat.items())[:30]), "engine": "nuclei"}


async def scan(
    url: str,
    severity: str = "info,low,medium,high,critical",
    max_templates: int = 50,
    category: str = "",
    user_agent: str = "pyodide-security/nuclei/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "nuclei"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    base = url.rstrip("/")

    sev_set = {s.strip().lower() for s in severity.split(",") if s.strip()}
    templates = [t for t in _templates() if (t.get("severity") or "info").lower() in sev_set]
    if category:
        templates = [t for t in templates if category.lower() in (t.get("category") or "").lower()]
    if max_templates and max_templates > 0:
        templates = templates[: int(max_templates)]

    headers = {"User-Agent": user_agent}
    findings = []
    tested = 0
    # cache path -> response to avoid duplicate fetches
    cache: dict[str, dict] = {}

    for t in templates:
        if not policy.can_request():
            break
        method = (t.get("method") or "GET").upper()
        paths = t.get("paths") or [base]
        words = [w for w in (t.get("words") or []) if w]
        regexes = []
        for rx in (t.get("regex") or []):
            try:
                regexes.append(re.compile(rx, re.I))
            except re.error:
                pass
        status_ok = set(t.get("status") or [200])

        matched = False
        evidence = []
        for raw_path in paths:
            path = raw_path.replace("{{BaseURL}}", base).replace("{{Hostname}}", base.split("//", 1)[-1].split("/")[0])
            if path.startswith("http"):
                target = path
            else:
                target = urljoin(base + "/", path.lstrip("/"))
            if target in cache:
                resp = cache[target]
            else:
                if not policy.can_request():
                    break
                tested += 1
                resp = await http_request(target, method=method if method in ("GET", "POST", "HEAD") else "GET", headers=headers)
                cache[target] = resp
            st = resp.get("status") or 0
            body = resp.get("body") or ""
            if st not in status_ok and status_ok:
                continue
            hit = False
            if words:
                if any(w in body for w in words):
                    hit = True
                    evidence.append({"type": "word", "value": next(w for w in words if w in body)})
            if regexes:
                for rx in regexes:
                    m = rx.search(body)
                    if m:
                        hit = True
                        evidence.append({"type": "regex", "value": m.group(0)[:120]})
                        break
            if not words and not regexes and st in status_ok:
                hit = True
                evidence.append({"type": "status", "value": st})
            if hit:
                matched = True
                findings.append({
                    "id": t.get("id"),
                    "name": t.get("name"),
                    "severity": t.get("severity"),
                    "category": t.get("category"),
                    "url": target,
                    "status": st,
                    "evidence": evidence[:3],
                })
                break
        if matched:
            continue

    return {
        "ok": True,
        "url": url,
        "tested": tested,
        "templates_run": len(templates),
        "findings": findings,
        "finding_count": len(findings),
        "template_db": len(_templates()),
        "engine": "nuclei",
        "equivalent": "projectdiscovery/nuclei",
        "source": "nuclei-templates packed",
    }
