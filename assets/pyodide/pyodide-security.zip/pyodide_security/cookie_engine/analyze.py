"""Cookie security analyzer — flags, SameSite, Secure, HttpOnly."""
from __future__ import annotations
from typing import Any
from .._http import http_request
from .. import policy

def parse_set_cookie(raw: str)->dict[str,Any]:
    parts=[p.strip() for p in raw.split(";")]
    if not parts: return {}
    name,_,value=parts[0].partition("=")
    flags={p.lower().split("=")[0].strip(): (p.split("=",1)[1].strip() if "=" in p else True) for p in parts[1:]}
    return {"name":name.strip(),"value_preview":(value or "")[:40],"flags":flags,
            "httponly":"httponly" in flags,"secure":"secure" in flags,
            "samesite":str(flags.get("samesite","")).lower() or None,
            "path":flags.get("path"),"domain":flags.get("domain"),"max-age":flags.get("max-age")}

def analyze_cookies(set_cookie_headers: list[str])->dict[str,Any]:
    cookies=[parse_set_cookie(h) for h in set_cookie_headers if h]
    issues=[]
    for c in cookies:
        if not c.get("httponly"): issues.append({"cookie":c["name"],"issue":"missing HttpOnly","severity":"medium"})
        if not c.get("secure"): issues.append({"cookie":c["name"],"issue":"missing Secure","severity":"medium"})
        if not c.get("samesite"): issues.append({"cookie":c["name"],"issue":"missing SameSite","severity":"low"})
        elif c.get("samesite")=="none" and not c.get("secure"):
            issues.append({"cookie":c["name"],"issue":"SameSite=None without Secure","severity":"high"})
    return {"cookies":cookies,"count":len(cookies),"issues":issues,"issue_count":len(issues)}

async def analyze(url: str, user_agent: str="pyodide-security/cookie/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"cookie"}
    if not url.startswith(("http://","https://")): url="https://"+url
    resp=await http_request(url, headers={"User-Agent":user_agent})
    hdrs=resp.get("headers") or {}
    # collect set-cookie (may be combined)
    sc=[]
    for k,v in hdrs.items():
        if k.lower()=="set-cookie":
            sc.extend(str(v).split("\n") if "\n" in str(v) else [str(v)])
    result=analyze_cookies(sc)
    result.update({"ok":True,"url":url,"status":resp.get("status"),"engine":"cookie","equivalent":"cookie flag audit"})
    return result


async def scan_url(url: str, **kw):
    return await analyze(url, **kw)

def analyze_header_block(headers: str="")->dict:
    lines=[]
    for line in (headers or "").splitlines():
        if ":" in line and line.split(":",1)[0].strip().lower()=="set-cookie":
            lines.append(line.split(":",1)[1].strip())
        elif line.strip() and "set-cookie" not in line.lower():
            lines.append(line.strip())
    r=analyze_cookies(lines); r["ok"]=True; r["engine"]="cookie"; return r
