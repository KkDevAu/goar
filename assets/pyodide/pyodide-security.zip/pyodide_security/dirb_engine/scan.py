"""
Directory / path brute-force — wordlist from maurosoria/dirsearch.

Source: https://github.com/maurosoria/dirsearch
Wordlist: db/dicc.txt (9681 entries)
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .._http import http_request
from .. import policy

_WL = Path(__file__).resolve().parent / "data" / "dicc.txt"


@lru_cache(maxsize=1)
def _wordlist() -> list[str]:
    if not _WL.exists():
        return []
    return [ln.strip() for ln in _WL.read_text(errors="replace").splitlines() if ln.strip() and not ln.startswith("#")]


def list_wordlist(limit: int = 20) -> dict[str, Any]:
    words = _wordlist()
    return {
        "total": len(words),
        "sample": words[: max(1, min(int(limit), 50))],
        "source": "maurosoria/dirsearch db/dicc.txt",
    }


async def scan(
    url: str,
    extensions: str = "php,html,txt,bak,zip,json",
    max_paths: int = 80,
    follow_codes: str = "200,201,204,301,302,307,401,403",
    user_agent: str = "pyodide-security/dirsearch/1.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "dirb"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    base = url.rstrip("/") + "/"
    headers = {"User-Agent": user_agent}
    codes = {int(c) for c in follow_codes.split(",") if c.strip().isdigit()}
    exts = [e.strip().lstrip(".") for e in extensions.split(",") if e.strip()]

    words = _wordlist()[: max(1, min(int(max_paths), 2000))]
    found = []
    tested = 0
    for w in words:
        if not policy.can_request():
            break
        candidates = [w]
        if "." not in w.split("/")[-1] and exts:
            candidates += [f"{w}.{e}" for e in exts[:3]]
        for path in candidates[:4]:
            if not policy.can_request():
                break
            target = urljoin(base, path.lstrip("/"))
            resp = await http_request(target, headers=headers)
            tested += 1
            status = int(resp.get("status") or 0)
            if status in codes:
                found.append({
                    "path": path,
                    "url": target,
                    "status": status,
                    "length": len(resp.get("body") or ""),
                })
                break

    return {
        "ok": True,
        "url": url,
        "tested": tested,
        "found": found,
        "found_count": len(found),
        "wordlist_size": len(_wordlist()),
        "engine": "dirb",
        "version": "3.0-dirsearch",
        "equivalent": "maurosoria/dirsearch",
        "source": "https://github.com/maurosoria/dirsearch",
        "policy": policy.status(),
    }
