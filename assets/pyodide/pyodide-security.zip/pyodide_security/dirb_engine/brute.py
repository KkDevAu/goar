"""ffuf / gobuster / dirsearch-class path brute via HTTP."""

from __future__ import annotations

from typing import Any
from urllib.parse import urljoin, urlparse

from .. import policy
from .._http import http_request
from .wordlists import get_wordlist, list_wordlists


async def brute(
    url: str,
    wordlist: str = "common",
    custom_wordlist: str = "",
    extensions: str = "",
    threads_note: str = "",
    max_words: int = 120,
    follow_codes: str = "200,201,204,301,302,307,401,403",
    user_agent: str = "pyodide-security/dirb-engine",
) -> dict[str, Any]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    base = url if url.endswith("/") else url + "/"
    origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}"

    pack = get_wordlist(wordlist, 0)
    words = list(pack.get("words") or [])
    extra = [w.strip() for w in (custom_wordlist or "").splitlines() if w.strip()]
    if extra:
        words = extra + words
    words = words[: max(1, min(int(max_words), 400))]
    exts = [e.strip() for e in extensions.split(",") if e.strip()]
    if exts:
        expanded = []
        for w in words:
            expanded.append(w)
            if "." not in w.rsplit("/", 1)[-1]:
                for e in exts:
                    e = e if e.startswith(".") else f".{e}"
                    expanded.append(w + e)
        words = expanded[: max(1, min(int(max_words) * max(1, len(exts)), 500))]

    want = {int(x) for x in follow_codes.split(",") if x.strip().isdigit()}
    headers = {"User-Agent": user_agent}

    # baseline 404 signature
    import random
    import string

    rand = "".join(random.choice(string.ascii_lowercase) for _ in range(12))
    base404 = await http_request(urljoin(base, rand), headers=headers)
    base404_len = len(base404.get("body") or "")
    base404_status = int(base404.get("status") or 0)

    hits = []
    errors = 0
    for w in words:
        target = urljoin(base, w)
        resp = await http_request(target, headers=headers)
        status = int(resp.get("status") or 0)
        if status == 0:
            errors += 1
            continue
        body_len = len(resp.get("body") or "")
        # soft 404 filter
        soft404 = status == base404_status and abs(body_len - base404_len) < 20 and status in (200, 404)
        if status in want and not soft404:
            hits.append(
                {
                    "path": "/" + w.lstrip("/"),
                    "url": target,
                    "status": status,
                    "length": body_len,
                    "redirect": resp.get("final_url") if resp.get("redirected") else None,
                    "content_type": (resp.get("headers") or {}).get("content-type"),
                }
            )

    hits.sort(key=lambda h: (h["status"], h["path"]))
    return {
        "base": base,
        "origin": origin,
        "wordlist": wordlist,
        "tried": len(words),
        "hits": hits,
        "hit_count": len(hits),
        "errors": errors,
        "baseline_404": {"status": base404_status, "length": base404_len},
        "engine": "ffuf/gobuster-class",
        "wordlists": list_wordlists()["wordlists"],
    }
