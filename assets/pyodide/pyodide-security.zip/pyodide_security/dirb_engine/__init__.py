from .scan import list_wordlist, scan
from .brute import brute

list_wordlists = list_wordlist

__all__ = ["scan", "brute", "list_wordlist", "list_wordlists"]
