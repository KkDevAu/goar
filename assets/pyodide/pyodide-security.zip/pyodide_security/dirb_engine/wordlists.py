"""Directory / path wordlists — dirb / feroxbuster / SecLists class subsets."""

from __future__ import annotations

from typing import Any

# Core discovery paths (always useful)
_COMMON = [
    "admin", "administrator", "login", "logout", "signin", "signup", "register",
    "dashboard", "panel", "console", "portal", "manage", "manager", "management",
    "api", "api/v1", "api/v2", "api/v3", "v1", "v2", "v3", "graphql", "graphiql",
    "swagger", "swagger-ui", "swagger.json", "swagger.yaml", "openapi.json", "openapi.yaml",
    "docs", "documentation", "redoc", "api-docs", "api/docs",
    "robots.txt", "sitemap.xml", "sitemap_index.xml", "security.txt", ".well-known/security.txt",
    ".well-known/openid-configuration", ".well-known/change-password",
    ".env", ".env.local", ".env.production", ".env.backup", ".env.old",
    ".git", ".git/HEAD", ".git/config", ".gitignore", ".svn", ".svn/entries",
    ".hg", ".DS_Store", "web.config", "Web.config", "crossdomain.xml", "clientaccesspolicy.xml",
    "backup", "backups", "bak", "old", "temp", "tmp", "test", "testing", "dev", "development",
    "staging", "stage", "qa", "uat", "demo", "beta", "alpha",
    "config", "configuration", "settings", "setup", "install", "installer",
    "upload", "uploads", "file", "files", "static", "assets", "public", "media", "images", "img",
    "css", "js", "scripts", "fonts", "vendor", "node_modules",
    "wp-admin", "wp-login.php", "wp-content", "wp-includes", "wordpress", "xmlrpc.php",
    "phpmyadmin", "pma", "adminer", "adminer.php", "mysql", "sql", "db", "database",
    "actuator", "actuator/health", "actuator/info", "actuator/env", "actuator/metrics",
    "actuator/mappings", "actuator/beans", "actuator/configprops",
    "health", "healthz", "ready", "readiness", "live", "liveness", "status", "info", "metrics",
    "trace", "debug", "server-status", "server-info", "nginx_status",
    "phpinfo.php", "info.php", "test.php", "i.php",
    "cgi-bin", "bin", "scripts/setup.php",
    "elmah", "elmah.axd", "trace.axd", "webresource.axd",
    "jmx-console", "invoker", "manager/html", "host-manager",
    "solr", "solr/admin", "jenkins", "jenkins/login", "hudson",
    "grafana", "kibana", "prometheus", "alertmanager",
    "swagger-ui.html", "v2/api-docs", "v3/api-docs",
    "graphql/console", "playground", "altair",
    "oauth", "oauth2", "oauth/authorize", "oauth/token", "sso", "saml", "cas",
    "user", "users", "account", "accounts", "profile", "settings/profile",
    "password", "reset", "forgot", "forgot-password", "reset-password",
    "search", "find", "query", "export", "import", "download", "downloads",
    "report", "reports", "log", "logs", "logging", "audit",
    "internal", "private", "secure", "secret", "hidden",
    "backup.sql", "dump.sql", "database.sql", "db.sql", "data.sql",
    "backup.zip", "backup.tar.gz", "site.zip", "www.zip", "html.zip",
    "1", "2", "123", "admin1", "test1", "old_admin",
    "index.php", "index.html", "index.jsp", "index.asp", "index.aspx", "default.aspx",
    "home", "main", "app", "application", "service", "services",
    "webhook", "webhooks", "callback", "callbacks", "hook", "hooks",
    "admin/login", "admin/index", "admin/dashboard", "admin/config",
    "api/users", "api/auth", "api/login", "api/token", "api/health", "api/status",
    "rest", "rest/api", "rest/v1", "json", "xml",
    "wp-json", "wp-json/wp/v2/users",
    "cgi-bin/test.cgi", "cgi-bin/status",
    "README", "README.md", "CHANGELOG", "LICENSE", "package.json", "composer.json",
    "yarn.lock", "package-lock.json", "Gemfile", "requirements.txt", "Pipfile",
    "Dockerfile", "docker-compose.yml", ".dockerignore",
    "Makefile", "webpack.config.js", "tsconfig.json",
    "error", "errors", "404", "403", "500",
    "monitor", "monitoring", "metrics.json", "stats",
    "telescope", "horizon", "nova", "filament",
    "rails/info", "rails/mailers",
    "_debug", "_profiler", "_wdt", "app_dev.php",
    "storage", "storage/logs", "bootstrap/cache",
    "vendor/phpunit", "phpunit.xml",
    "serverless.yml", ".aws", ".aws/credentials",
    "id_rsa", "id_rsa.pub", ".ssh", "authorized_keys",
    "web.config.bak", "config.php.bak", "config.php.old", "config.yml", "config.yaml",
    "application.properties", "application.yml", "application-dev.yml",
    "localsettings.py", "settings.py", "config/database.yml",
]

_API = [
    "api", "api/", "api/v1", "api/v2", "api/v3", "api/v1/", "api/v2/",
    "api/users", "api/user", "api/auth", "api/login", "api/logout", "api/register",
    "api/token", "api/refresh", "api/me", "api/profile", "api/account",
    "api/admin", "api/internal", "api/private", "api/public",
    "api/health", "api/status", "api/version", "api/info", "api/metrics",
    "api/docs", "api/swagger", "api/openapi", "api/graphql",
    "api/orders", "api/products", "api/items", "api/search",
    "api/upload", "api/files", "api/export", "api/import",
    "v1/users", "v2/users", "v1/auth", "v2/auth",
    "graphql", "graphiql", "playground",
    "rest", "rest/v1", "rest/v2",
    "jsonapi", "hal",
    ".well-known/openid-configuration", ".well-known/oauth-authorization-server",
    "oauth/token", "oauth/authorize", "oauth/introspect", "oauth/revoke",
    "connect/token", "connect/authorize",
    "wp-json", "wp-json/wp/v2", "wp-json/wp/v2/users",
]

_SENSITIVE = [
    ".env", ".env.local", ".env.production", ".env.staging", ".env.development",
    ".env.backup", ".env.old", ".env.bak", ".env.save", ".env.swp",
    ".git/HEAD", ".git/config", ".git/index", ".git/logs/HEAD",
    ".svn/entries", ".svn/wc.db",
    "backup.sql", "dump.sql", "db.sql", "database.sql", "data.sql", "mysql.sql",
    "backup.zip", "backup.tar", "backup.tar.gz", "backup.tgz", "site.zip", "wwwroot.zip",
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", ".ssh/id_rsa",
    "web.config", "web.config.bak", "appsettings.json", "appsettings.Development.json",
    "config.php", "config.php.bak", "configuration.php", "local.xml", "settings.php",
    "application.properties", "application.yml", "application-prod.yml",
    "secrets.yml", "secrets.json", "credentials.json", "service-account.json",
    "phpinfo.php", "info.php", "test.php", "debug.php",
    "server-status", "server-info", "nginx_status",
    "actuator/env", "actuator/heapdump", "actuator/jolokia", "actuator/mappings",
    "trace.axd", "elmah.axd",
    "crossdomain.xml", "clientaccesspolicy.xml",
    "SECURITY.md", "security.txt", ".well-known/security.txt",
]


def get_wordlist(name: str = "common", limit: int = 0) -> dict[str, Any]:
    name = (name or "common").lower().strip()
    mapping = {
        "common": _COMMON,
        "api": _API,
        "sensitive": _SENSITIVE,
        "all": list(dict.fromkeys(_COMMON + _API + _SENSITIVE)),
    }
    words = mapping.get(name) or _COMMON
    if limit and limit > 0:
        words = words[: int(limit)]
    return {"name": name if name in mapping else "common", "count": len(words), "words": words}


def list_wordlists() -> dict[str, Any]:
    return {
        "wordlists": {
            "common": len(_COMMON),
            "api": len(_API),
            "sensitive": len(_SENSITIVE),
            "all": len(list(dict.fromkeys(_COMMON + _API + _SENSITIVE))),
        }
    }
