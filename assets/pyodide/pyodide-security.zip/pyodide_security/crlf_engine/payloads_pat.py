
from .. import pat_data
def list_payloads():
    rows = pat_data.get("crlf")
    return {"payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/crlf"}
