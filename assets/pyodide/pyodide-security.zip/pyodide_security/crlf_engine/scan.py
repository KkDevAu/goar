"""
CRLF injection scanner — PortSwigger / PayloadsAllTheThings class.

Detects header injection via %0d%0a / \\r\\n in query, path, and headers
that causes reflected Set-Cookie, Location, or arbitrary response headers.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse, quote

from .._http import http_request
from .. import policy

# (id, placement, vector_template, look_for)
# {INJECT} replaced with CRLF sequence variants
_VECTORS: list[dict[str, Any]] = [
    {
        "id": "set-cookie-query",
        "placement": "query",
        "param": "q",
        "vector": "psec{INJECT}Set-Cookie:psec_crlf=1",
        "expect_header": "set-cookie",
        "expect_value": "psec_crlf",
        "severity": "high",
    },
    {
        "id": "location-query",
        "placement": "query",
        "param": "q",
        "vector": "psec{INJECT}Location:https://evil.psec.example/",
        "expect_header": "location",
        "expect_value": "evil.psec.example",
        "severity": "high",
    },
    {
        "id": "x-header-query",
        "placement": "query",
        "param": "q",
        "vector": "psec{INJECT}X-Psec-Crlf: injected",
        "expect_header": "x-psec-crlf",
        "expect_value": "injected",
        "severity": "medium",
    },
    {
        "id": "set-cookie-path",
        "placement": "path",
        "vector": "/psec{INJECT}Set-Cookie:psec_crlf=1",
        "expect_header": "set-cookie",
        "expect_value": "psec_crlf",
        "severity": "high",
    },
    {
        "id": "double-encode",
        "placement": "query",
        "param": "q",
        "vector": "psec{INJECT_DBL}Set-Cookie:psec_crlf=1",
        "expect_header": "set-cookie",
        "expect_value": "psec_crlf",
        "severity": "high",
    },
]

_INJECT_VARIANTS = [
    ("%0d%0a", "url-encoded CRLF"),
    ("%0a", "url-encoded LF"),
    ("%0d", "url-encoded CR"),
    ("%0d%0a%00", "CRLF+null"),
    ("%250d%250a", "double-encoded CRLF"),
]


def _hget(headers: dict, name: str) -> str:
    ln = name.lower()
    for k, v in (headers or {}).items():
        if k.lower() == ln:
            return str(v or "")
    return ""


async def scan(
    url: str,
    max_variants: int = 3,
    user_agent: str = "pyodide-security/crlf-engine/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "crlf"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    p = urlparse(url)
    base_params = dict(parse_qsl(p.query, keep_blank_values=True))
    headers = {"User-Agent": user_agent}
    variants = _INJECT_VARIANTS[: max(1, min(int(max_variants), 5))]

    findings = []
    tests = []

    for vec in _VECTORS:
        for inj, inj_name in variants:
            if not policy.can_request():
                break
            # pick inject token
            token = inj
            raw = vec["vector"]
            if "{INJECT_DBL}" in raw:
                # force double-encode variant
                token = "%250d%250a"
                payload = raw.replace("{INJECT_DBL}", token)
            else:
                payload = raw.replace("{INJECT}", token)

            if vec["placement"] == "query":
                param = vec.get("param") or "q"
                q = dict(base_params)
                q[param] = payload
                test_url = urlunparse(p._replace(query=urlencode(q, doseq=True)))
            else:
                # path injection — append to path
                new_path = (p.path.rstrip("/") + payload).replace("//", "/")
                test_url = urlunparse(p._replace(path=new_path, query=urlencode(base_params, doseq=True)))

            resp = await http_request(test_url, headers=headers)
            hdrs = resp.get("headers") or {}
            expect_h = vec["expect_header"]
            expect_v = vec["expect_value"]
            got = _hget(hdrs, expect_h)
            hit = expect_v.lower() in got.lower() if got else False

            # also check raw body for reflected header text (some servers echo)
            body = resp.get("body") or ""
            body_hit = expect_v.lower() in body.lower() and "psec" in body.lower()

            entry = {
                "id": vec["id"],
                "variant": inj_name,
                "placement": vec["placement"],
                "severity": vec["severity"],
                "status": resp.get("status"),
                "header_hit": hit,
                "body_echo": body_hit,
                "observed_header": got[:200] if got else None,
                "error": resp.get("error"),
                "url_sample": test_url[:200],
            }
            tests.append(entry)
            if hit:
                findings.append(entry)

    findings.sort(key=lambda x: 0 if x["severity"] == "high" else 1)
    return {
        "ok": True,
        "url": url,
        "tested": len(tests),
        "vulnerable": bool(findings),
        "findings": findings,
        "tests": tests,
        "engine": "crlf",
        "version": "2.0",
        "equivalent": "PortSwigger CRLF / header injection",
        "policy": policy.status(),
    }
