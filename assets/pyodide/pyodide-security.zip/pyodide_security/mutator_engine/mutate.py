"""Payload mutator — case, encoding, comment insertion."""
from __future__ import annotations
from typing import Any
from urllib.parse import quote

def mutate(payload: str, max_mut: int=40)->dict[str,Any]:
    p=payload or ""
    out=[]
    def add(label, val):
        if len(out)<max_mut: out.append({"id":label,"value":val})
    add("orig", p)
    add("upper", p.upper())
    add("lower", p.lower())
    add("swapcase", p.swapcase())
    add("url", quote(p, safe=""))
    add("double_url", quote(quote(p, safe=""), safe=""))
    add("plus_space", p.replace(" ", "+"))
    # insert comments between keywords for sql-ish
    if " " in p:
        add("sql_comment", p.replace(" ", "/**/"))
        add("sql_comment2", p.replace(" ", "/*x*/"))
    # null
    add("null_suffix", p+"%00")
    add("crlf", p+"%0d%0a")
    add("tab", p.replace(" ", "%09"))
    # unicode slash
    add("uni_slash", p.replace("/", "／"))
    # repeated
    add("double", p+p)
    add("rev", p[::-1])
    return {"ok":True,"input":p,"count":len(out),"mutations":out,"engine":"mutator"}
