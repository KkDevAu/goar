
"""Payloads from swisskyrepo/PayloadsAllTheThings (nosql)."""
from .. import pat_data

def list_payloads():
    rows = pat_data.get("nosql")
    return {"payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/nosql"}
