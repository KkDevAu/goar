"""OAuth/OIDC misconfiguration checks — well-known + redirect traps."""
from __future__ import annotations
import json
from typing import Any
from urllib.parse import urljoin, urlparse, parse_qs
from .._http import http_request
from .. import policy

OIDC_PATHS=["/.well-known/openid-configuration","/.well-known/oauth-authorization-server"]

async def analyze(url: str, user_agent: str="pyodide-security/oauth/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"oauth"}
    if not url.startswith(("http://","https://")): url="https://"+url
    base=url if url.endswith("/") else url+"/"
    headers={"User-Agent":user_agent,"Accept":"application/json"}
    findings=[]; configs={}
    for path in OIDC_PATHS:
        if not policy.can_request(): break
        target=urljoin(base, path.lstrip("/"))
        resp=await http_request(target, headers=headers)
        if resp.get("status")==200 and resp.get("body"):
            try:
                data=json.loads(resp["body"])
            except Exception:
                data=None
            if isinstance(data, dict):
                configs[path]=data
                # checks
                if data.get("authorization_endpoint"):
                    findings.append({"id":"auth_endpoint","severity":"info","detail":data["authorization_endpoint"]})
                if "token_endpoint" in data:
                    findings.append({"id":"token_endpoint","severity":"info","detail":data["token_endpoint"]})
                algs=data.get("id_token_signing_alg_values_supported") or data.get("token_endpoint_auth_signing_alg_values_supported") or []
                if "none" in [str(a).lower() for a in algs]:
                    findings.append({"id":"alg_none","severity":"high","detail":"supports 'none' signing alg"})
                if "RS256" not in algs and algs:
                    findings.append({"id":"weak_algs","severity":"medium","detail":str(algs)[:200]})
                if data.get("response_types_supported") and "token" in data["response_types_supported"]:
                    findings.append({"id":"implicit_flow","severity":"medium","detail":"implicit flow enabled"})
    return {"ok":True,"url":url,"configs":{k:{"keys":list(v.keys())[:30]} for k,v in configs.items()},
            "findings":findings,"finding_count":len(findings),"engine":"oauth","equivalent":"OIDC discovery audit"}


async def analyze_auth_url(url: str, **kw):
    return await analyze(url, **kw)

async def fetch_oidc(url: str, **kw):
    return await analyze(url, **kw)
