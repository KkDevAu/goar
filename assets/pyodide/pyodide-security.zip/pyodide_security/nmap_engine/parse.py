"""Parse all nmap output formats: -oX XML, -oG greppable, -oN normal, -oM machine."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from typing import Any

from .services import lookup


def parse(output: str) -> dict[str, Any]:
    text = (output or "").strip()
    if not text:
        raise ValueError("output is required")
    if text.startswith("<?xml") or "<nmaprun" in text[:300]:
        return parse_xml(text)
    if text.startswith("Host:") or re.search(r"(?m)^Host:\s", text):
        return parse_greppable(text)
    if "# Nmap" in text[:50] or "Nmap scan report" in text:
        return parse_normal(text)
    # try greppable anyway
    if "Ports:" in text:
        return parse_greppable(text)
    return parse_normal(text)


def parse_xml(output: str) -> dict[str, Any]:
    try:
        root = ET.fromstring(output)
    except ET.ParseError as e:
        raise ValueError(f"invalid nmap XML: {e}") from e
    hosts = []
    for host in root.findall("host"):
        status_el = host.find("status")
        addrs = []
        ip = ""
        for addr in host.findall("address"):
            addrs.append({"addr": addr.get("addr"), "type": addr.get("addrtype"), "vendor": addr.get("vendor")})
            if addr.get("addrtype") == "ipv4":
                ip = addr.get("addr") or ip
            elif not ip:
                ip = addr.get("addr") or ""
        hostnames = [{"name": hn.get("name"), "type": hn.get("type")} for hn in host.findall("hostnames/hostname")]
        ports = []
        for p in host.findall("ports/port"):
            st = p.find("state")
            sv = p.find("service")
            scripts = []
            for sc in p.findall("script"):
                scripts.append({"id": sc.get("id"), "output": sc.get("output")})
            portid = int(p.get("portid") or 0)
            svc = {
                "port": portid,
                "proto": p.get("protocol") or "tcp",
                "state": st.get("state") if st is not None else "",
                "reason": st.get("reason") if st is not None else "",
                "service": (sv.get("name") if sv is not None else "") or lookup(portid)["service"],
                "product": sv.get("product") if sv is not None else "",
                "version": sv.get("version") if sv is not None else "",
                "extrainfo": sv.get("extrainfo") if sv is not None else "",
                "tunnel": sv.get("tunnel") if sv is not None else "",
                "method": sv.get("method") if sv is not None else "",
                "conf": sv.get("conf") if sv is not None else "",
                "cpe": [c.text for c in (sv.findall("cpe") if sv is not None else []) if c.text],
                "scripts": scripts,
            }
            ports.append(svc)
        os_matches = []
        for om in host.findall("os/osmatch"):
            os_matches.append({"name": om.get("name"), "accuracy": om.get("accuracy")})
        hosts.append(
            {
                "ip": ip,
                "addresses": addrs,
                "hostnames": hostnames,
                "status": status_el.get("state") if status_el is not None else "",
                "ports": ports,
                "os": os_matches,
            }
        )
    runstats = root.find("runstats/finished")
    return {
        "format": "xml",
        "scanner": root.get("scanner"),
        "args": root.get("args"),
        "start": root.get("start"),
        "version": root.get("version"),
        "xmloutputversion": root.get("xmloutputversion"),
        "hosts": hosts,
        "host_count": len(hosts),
        "finished": runstats.get("timestr") if runstats is not None else None,
    }


def parse_greppable(output: str) -> dict[str, Any]:
    hosts = []
    for line in (output or "").splitlines():
        line = line.strip()
        if not line.startswith("Host:"):
            continue
        # Host: ip (hostname) Ports: ... Status: Up
        status_m = re.search(r"Status:\s*(\S+)", line)
        status = (status_m.group(1).lower() if status_m else "up")
        m = re.match(r"Host:\s+(\S+)\s+\(([^)]*)\)(.*)", line)
        if not m:
            continue
        ip, name, rest = m.group(1), m.group(2), m.group(3)
        ports = []
        pm = re.search(r"Ports:\s*(.*?)(?:\t|Ignored|Status:|$)", rest)
        if pm:
            for part in pm.group(1).split(","):
                part = part.strip()
                if not part:
                    continue
                bits = part.split("/")
                # port/state/proto/owner/service/rpc/version
                if len(bits) >= 3:
                    port_s = bits[0]
                    ports.append(
                        {
                            "port": int(port_s) if port_s.isdigit() else port_s,
                            "state": bits[1],
                            "proto": bits[2],
                            "service": bits[4] if len(bits) > 4 and bits[4] else lookup(int(port_s))["service"] if port_s.isdigit() else "",
                            "version": bits[6] if len(bits) > 6 else "",
                        }
                    )
        hosts.append({"ip": ip, "hostname": name, "status": status, "ports": ports})
    return {"format": "greppable", "hosts": hosts, "host_count": len(hosts)}


def parse_normal(output: str) -> dict[str, Any]:
    hosts = []
    current: dict[str, Any] | None = None
    for line in (output or "").splitlines():
        m = re.match(r"Nmap scan report for (.+?)(?: \((\d+\.\d+\.\d+\.\d+)\))?$", line)
        if m:
            if current:
                hosts.append(current)
            name, ip = m.group(1), m.group(2)
            if re.match(r"^\d+\.\d+\.\d+\.\d+$", name) and not ip:
                ip, name = name, ""
            current = {
                "ip": ip or name,
                "hostname": name if ip else "",
                "ports": [],
                "status": "up",
                "os": [],
            }
            continue
        if current is None:
            continue
        if "Host is up" in line:
            latency = re.search(r"\(([\d.]+)s latency\)", line)
            current["latency"] = latency.group(1) if latency else None
            continue
        pm = re.match(r"(\d+)/(tcp|udp|sctp)\s+(\S+)\s+(\S+)(?:\s+(.*))?$", line)
        if pm:
            current["ports"].append(
                {
                    "port": int(pm.group(1)),
                    "proto": pm.group(2),
                    "state": pm.group(3),
                    "service": pm.group(4),
                    "version": (pm.group(5) or "").strip(),
                }
            )
            continue
        om = re.match(r"OS details:\s*(.+)", line)
        if om:
            current["os"].append({"name": om.group(1).strip()})
            continue
        sm = re.match(r"^\|_\s*([a-z0-9\-]+):\s*(.*)", line)
        if sm and current["ports"]:
            current["ports"][-1].setdefault("scripts", []).append(
                {"id": sm.group(1), "output": sm.group(2)}
            )
    if current:
        hosts.append(current)
    return {"format": "normal", "hosts": hosts, "host_count": len(hosts)}


def to_greppable(hosts: list[dict[str, Any]]) -> str:
    """Emit nmap -oG style lines from structured hosts."""
    lines = ["# Nmap greppable output generated by pyodide-security nmap_engine"]
    for h in hosts:
        ip = h.get("ip") or ""
        name = ""
        if h.get("hostname"):
            name = h["hostname"]
        elif h.get("hostnames"):
            hn = h["hostnames"]
            if isinstance(hn, list) and hn:
                name = hn[0].get("name") if isinstance(hn[0], dict) else str(hn[0])
        port_parts = []
        for p in h.get("ports") or []:
            if p.get("state") not in ("open", "open|filtered"):
                continue
            port_parts.append(
                f"{p.get('port')}/{p.get('state')}/{p.get('proto','tcp')}//{p.get('service','')}///"
            )
        ports_s = ", ".join(port_parts)
        lines.append(f"Host: {ip} ({name})\tPorts: {ports_s}\tStatus: {h.get('status') or 'up'}")
    return "\n".join(lines) + "\n"
