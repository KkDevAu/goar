"""HTTP(S) connect probing — maximum browser-reachable equivalent of -sV for web ports."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlparse

from .._http import http_request
from .services import guess_from_banner, lookup, top_ports as top_ports_fn


async def http_probe(
    host: str,
    ports: str = "",
    path: str = "/",
    top: int = 0,
    user_agent: str = "pyodide-security/nmap-probe",
) -> dict[str, Any]:
    host = host.strip()
    if host.startswith("http://") or host.startswith("https://"):
        u = urlparse(host)
        hostname = u.hostname or host
        if not ports and u.port:
            ports = str(u.port)
    else:
        hostname = host.split("/")[0]
        if ":" in hostname and not hostname.count(":") > 1:
            # host:port
            hostname, _, p = hostname.partition(":")
            if not ports:
                ports = p

    if top and not ports:
        ports = ",".join(str(p["port"]) for p in top_ports_fn(top)["ports"])
    if not ports:
        ports = "80,443,8080,8443,8000,8888,3000,5000,9443,2083,2087,9090,9200"

    port_list = []
    for p in ports.split(","):
        p = p.strip()
        if p.isdigit():
            port_list.append(int(p))
    port_list = port_list[:50]

    headers = {"User-Agent": user_agent}
    results = []
    for port in port_list:
        meta = lookup(port)
        schemes = ["https"] if meta["tls"] else ["http"]
        if port not in (80, 443) and not meta["tls"]:
            schemes = ["http", "https"]
        if port in (80, 8080, 8000, 8008, 8888, 3000, 5000, 81):
            schemes = ["http", "https"]
        if port in (443, 8443, 9443, 10443, 2083, 2087, 4443, 6443):
            schemes = ["https", "http"]

        entry: dict[str, Any] = {
            "port": port,
            "proto": "tcp",
            "service": meta["service"],
            "state": "filtered",
            "product": None,
            "version": None,
            "scheme": None,
            "status": None,
            "title": None,
            "url": None,
            "error": None,
            "elapsed_ms": None,
            "headers": {},
        }
        for scheme in schemes:
            if (scheme == "http" and port == 80) or (scheme == "https" and port == 443):
                url = f"{scheme}://{hostname}{path if path.startswith('/') else '/' + path}"
            else:
                url = f"{scheme}://{hostname}:{port}{path if path.startswith('/') else '/' + path}"
            resp = await http_request(url, headers=headers)
            if int(resp.get("status") or 0) > 0:
                body = resp.get("body") or ""
                hdrs = resp.get("headers") or {}
                banner = "\n".join(f"{k}: {v}" for k, v in hdrs.items()) + "\n" + body[:500]
                g = guess_from_banner(port, banner)
                title_m = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
                entry.update(
                    {
                        "state": "open",
                        "scheme": scheme,
                        "status": resp["status"],
                        "title": re.sub(r"\s+", " ", title_m.group(1)).strip()[:160] if title_m else None,
                        "url": url,
                        "elapsed_ms": resp.get("elapsed_ms"),
                        "headers": hdrs,
                        "product": g.get("product"),
                        "version": g.get("version"),
                        "service": g.get("service") or meta["service"],
                        "final_url": resp.get("final_url"),
                    }
                )
                break
            entry["error"] = resp.get("error")
        results.append(entry)

    open_ports = [r for r in results if r["state"] == "open"]
    # greppable export
    greppable = (
        f"Host: {hostname} ()\tPorts: "
        + ", ".join(f"{r['port']}/open/tcp//{r['service']}///" for r in open_ports)
        + "\tStatus: up"
    )
    return {
        "host": hostname,
        "ports_probed": port_list,
        "results": results,
        "open": open_ports,
        "open_count": len(open_ports),
        "greppable": greppable,
        "engine": "http-connect",
        "limitation": (
            "No raw TCP SYN/ACK/UDP/SCTP/IP-proto scans in the browser. "
            "Ports that do not speak HTTP(S) or block CORS appear filtered. "
            "Import native nmap -oX/-oG for full non-HTTP coverage."
        ),
    }
