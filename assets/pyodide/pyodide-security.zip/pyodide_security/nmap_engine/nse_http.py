"""
NSE-style HTTP script suite — everything that can run over browser HTTP.

Scripts: http-title, http-headers, http-methods, http-robots, http-sitemap,
http-security-headers, http-enum (common paths), http-favicon, http-traceroute
(via redirect chain), http-cookie-flags, http-cors, http-jsonp-detection,
http-generator, http-server-header, ssl-cert (limited — PEM from nothing;
TLS metadata via response only).
"""

from __future__ import annotations

import hashlib
import re
from typing import Any
from urllib.parse import urljoin, urlparse

from .._http import http_request
from ..headers_tool import analyze as analyze_headers

COMMON_PATHS = [
    "/",
    "/robots.txt",
    "/sitemap.xml",
    "/.well-known/security.txt",
    "/favicon.ico",
    "/admin/",
    "/administrator/",
    "/login",
    "/wp-login.php",
    "/wp-admin/",
    "/.git/HEAD",
    "/.env",
    "/server-status",
    "/server-info",
    "/api/",
    "/api/v1/",
    "/api/v2/",
    "/graphql",
    "/swagger/",
    "/swagger-ui/",
    "/openapi.json",
    "/v2/api-docs",
    "/actuator",
    "/actuator/health",
    "/health",
    "/status",
    "/metrics",
    "/console/",
    "/phpmyadmin/",
    "/pma/",
    "/manager/html",
    "/jmx-console/",
    "/.svn/entries",
    "/crossdomain.xml",
    "/clientaccesspolicy.xml",
    "/security.txt",
    "/humans.txt",
    "/package.json",
    "/composer.json",
    "/web.config",
    "/elmah.axd",
    "/trace.axd",
    "/debug/",
    "/test/",
    "/backup/",
    "/old/",
    "/tmp/",
    "/uploads/",
    "/static/",
    "/assets/",
]


async def run_scripts(
    url: str,
    scripts: str = "default",
    user_agent: str = "pyodide-security/nmap-nse-http",
) -> dict[str, Any]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    wanted = _expand_scripts(scripts)
    headers = {"User-Agent": user_agent}
    out: dict[str, Any] = {"url": url, "scripts": {}, "wanted": sorted(wanted)}

    # always fetch root once if any content script needs it
    need_root = wanted & {
        "http-title",
        "http-headers",
        "http-server-header",
        "http-generator",
        "http-cookie-flags",
        "http-cors",
        "http-security-headers",
        "http-favicon",
    }
    root = await http_request(url, headers=headers) if need_root else None

    if "http-title" in wanted and root:
        title = None
        m = re.search(r"<title[^>]*>(.*?)</title>", root.get("body") or "", re.I | re.S)
        if m:
            title = re.sub(r"\s+", " ", m.group(1)).strip()[:200]
        out["scripts"]["http-title"] = {
            "title": title,
            "status": root.get("status"),
            "error": root.get("error"),
        }

    if "http-headers" in wanted and root:
        out["scripts"]["http-headers"] = {
            "status": root.get("status"),
            "headers": root.get("headers") or {},
            "error": root.get("error"),
        }

    if "http-server-header" in wanted and root:
        h = root.get("headers") or {}
        out["scripts"]["http-server-header"] = {
            "server": h.get("server"),
            "x_powered_by": h.get("x-powered-by"),
            "via": h.get("via"),
        }

    if "http-generator" in wanted and root:
        gens = re.findall(
            r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)',
            root.get("body") or "",
            re.I,
        )
        gens += re.findall(
            r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']generator["\']',
            root.get("body") or "",
            re.I,
        )
        out["scripts"]["http-generator"] = {"generators": gens}

    if "http-cookie-flags" in wanted and root:
        # Set-Cookie may be collapsed; best-effort
        raw = (root.get("headers") or {}).get("set-cookie") or ""
        flags = {
            "raw": raw[:500],
            "httponly": "httponly" in raw.lower(),
            "secure": "secure" in raw.lower(),
            "samesite": bool(re.search(r"samesite", raw, re.I)),
        }
        out["scripts"]["http-cookie-flags"] = flags

    if "http-cors" in wanted:
        cors_req = await http_request(
            url,
            headers={
                **headers,
                "Origin": "https://evil.example",
                "Access-Control-Request-Method": "GET",
            },
        )
        ch = cors_req.get("headers") or {}
        out["scripts"]["http-cors"] = {
            "status": cors_req.get("status"),
            "acao": ch.get("access-control-allow-origin"),
            "acac": ch.get("access-control-allow-credentials"),
            "acam": ch.get("access-control-allow-methods"),
            "acah": ch.get("access-control-allow-headers"),
            "risk": "high"
            if ch.get("access-control-allow-origin") == "*" and ch.get("access-control-allow-credentials") == "true"
            else ("medium" if ch.get("access-control-allow-origin") == "*" else "info"),
        }

    if "http-security-headers" in wanted and root:
        # reuse headers_tool via synthetic raw block
        raw_lines = [f"HTTP/1.1 {root.get('status') or 0}"]
        for k, v in (root.get("headers") or {}).items():
            raw_lines.append(f"{k}: {v}")
        try:
            out["scripts"]["http-security-headers"] = analyze_headers("\n".join(raw_lines))
        except Exception as e:  # noqa: BLE001
            out["scripts"]["http-security-headers"] = {"error": str(e)}

    if "http-methods" in wanted:
        opt = await http_request(url, method="OPTIONS", headers=headers)
        oh = opt.get("headers") or {}
        out["scripts"]["http-methods"] = {
            "status": opt.get("status"),
            "allow": oh.get("allow"),
            "public": oh.get("public"),
            "access_control_allow_methods": oh.get("access-control-allow-methods"),
            "error": opt.get("error"),
        }

    if "http-robots" in wanted:
        origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
        rob = await http_request(origin + "/robots.txt", headers=headers)
        body = rob.get("body") or ""
        out["scripts"]["http-robots"] = {
            "status": rob.get("status"),
            "url": origin + "/robots.txt",
            "disallow": re.findall(r"(?im)^Disallow:\s*(.+)$", body)[:200],
            "allow": re.findall(r"(?im)^Allow:\s*(.+)$", body)[:100],
            "sitemaps": re.findall(r"(?im)^Sitemap:\s*(\S+)$", body),
            "error": rob.get("error"),
        }

    if "http-sitemap" in wanted:
        origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
        sm = await http_request(origin + "/sitemap.xml", headers=headers)
        locs = re.findall(r"<loc>\s*([^<]+)\s*</loc>", sm.get("body") or "", re.I)[:500]
        out["scripts"]["http-sitemap"] = {
            "status": sm.get("status"),
            "urls": locs,
            "count": len(locs),
            "error": sm.get("error"),
        }

    if "http-favicon" in wanted:
        origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
        fav = await http_request(origin + "/favicon.ico", headers=headers)
        body = fav.get("body") or ""
        # body may be binary mangled as text; still hash
        md5 = hashlib.md5(body.encode("utf-8", errors="surrogatepass")).hexdigest() if body else None
        out["scripts"]["http-favicon"] = {
            "status": fav.get("status"),
            "md5": md5,
            "bytes": len(body),
            "error": fav.get("error"),
        }

    if "http-enum" in wanted:
        origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
        found = []
        for path in COMMON_PATHS:
            u = urljoin(origin + "/", path.lstrip("/"))
            r = await http_request(u, headers=headers)
            st = int(r.get("status") or 0)
            if st and st < 400:
                found.append({"path": path, "url": u, "status": st, "length": len(r.get("body") or "")})
            elif st in (401, 403):
                found.append({"path": path, "url": u, "status": st, "length": len(r.get("body") or ""), "note": "auth/forbidden"})
        out["scripts"]["http-enum"] = {"found": found, "count": len(found), "probed": len(COMMON_PATHS)}

    if "http-jsonp-detection" in wanted and root:
        body = root.get("body") or ""
        hits = re.findall(r"([a-zA-Z_$][\w$]*)\s*\(\s*\{", body)[:20]
        out["scripts"]["http-jsonp-detection"] = {"possible_callbacks": hits}

    if "http-auth" in wanted:
        r = await http_request(url, headers=headers)
        www = (r.get("headers") or {}).get("www-authenticate")
        out["scripts"]["http-auth"] = {
            "status": r.get("status"),
            "www_authenticate": www,
            "requires_auth": r.get("status") == 401 or bool(www),
        }

    if "http-open-redirect" in wanted:
        # probe common redirect params on same URL
        findings = []
        for param in ("url", "next", "redirect", "return", "continue", "dest", "redir", "goto"):
            from urllib.parse import parse_qsl, urlencode, urlparse as up, urlunparse

            p = up(url)
            q = dict(parse_qsl(p.query, keep_blank_values=True))
            q[param] = "https://evil.example/"
            test_u = urlunparse(p._replace(query=urlencode(q)))
            r = await http_request(test_u, headers=headers)
            loc = (r.get("headers") or {}).get("location") or ""
            if "evil.example" in loc:
                findings.append({"param": param, "location": loc, "status": r.get("status")})
        out["scripts"]["http-open-redirect"] = {"findings": findings, "count": len(findings)}

    return out


def _expand_scripts(scripts: str) -> set[str]:
    s = (scripts or "default").strip().lower()
    all_scripts = {
        "http-title",
        "http-headers",
        "http-server-header",
        "http-generator",
        "http-cookie-flags",
        "http-cors",
        "http-security-headers",
        "http-methods",
        "http-robots",
        "http-sitemap",
        "http-favicon",
        "http-enum",
        "http-jsonp-detection",
        "http-auth",
        "http-open-redirect",
    }
    if s in ("default", "default,"):
        return {
            "http-title",
            "http-headers",
            "http-server-header",
            "http-methods",
            "http-robots",
            "http-security-headers",
            "http-cookie-flags",
        }
    if s in ("all", "*"):
        return all_scripts
    wanted = set()
    for part in s.split(","):
        part = part.strip()
        if not part:
            continue
        if part.startswith("http-"):
            wanted.add(part)
        else:
            wanted.add("http-" + part)
    return wanted & all_scripts or wanted


nse_http = run_scripts
