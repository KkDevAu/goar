"""DNS recon via DoH — A/AAAA/MX/NS/TXT/CNAME/SOA."""
from __future__ import annotations
import json
from typing import Any
from urllib.parse import quote
from .._http import http_request
from ..subenum_engine.sources import clean_domain
from ..subenum_engine.resolve import doh_resolve

async def resolve_all(name: str, types: str="A,AAAA,MX,NS,TXT,CNAME,SOA", provider: str="cloudflare")->dict[str,Any]:
    name=clean_domain(name)
    results={}
    for t in [x.strip().upper() for x in types.split(",") if x.strip()]:
        results[t]=await doh_resolve(name, t, provider=provider)
    return {"ok":True,"name":name,"records":results,"engine":"dns","equivalent":"dnsx/dig DoH"}

async def domain_info(domain: str, provider: str="cloudflare")->dict[str,Any]:
    domain=clean_domain(domain)
    a=await doh_resolve(domain,"A",provider)
    mx=await doh_resolve(domain,"MX",provider)
    ns=await doh_resolve(domain,"NS",provider)
    txt=await doh_resolve(domain,"TXT",provider)
    return {"ok":True,"domain":domain,"a":a,"mx":mx,"ns":ns,"txt":txt,"engine":"dns"}

async def reverse_lookup(ip: str, provider: str="cloudflare")->dict[str,Any]:
    parts=ip.strip().split(".")
    if len(parts)==4 and all(p.isdigit() for p in parts):
        ptr=".".join(reversed(parts))+".in-addr.arpa"
    else:
        return {"ok":False,"error":"IPv4 required for reverse in this build","engine":"dns"}
    res=await doh_resolve(ptr,"PTR",provider)
    return {"ok":True,"ip":ip,"ptr":res,"engine":"dns"}
