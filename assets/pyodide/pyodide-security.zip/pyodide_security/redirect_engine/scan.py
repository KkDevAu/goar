"""
Open redirect scanner — PortSwigger / PayloadsAllTheThings class.

Tests common redirect parameters with external destinations and
protocol-relative / encoding bypasses. Confirms via Location header
or meta refresh / JS redirect in body.
"""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request
from .. import policy

_PARAMS = [
    "next", "url", "redirect", "redirect_uri", "redirect_url", "return",
    "returnTo", "return_to", "continue", "dest", "destination", "goto",
    "target", "rurl", "redirect_uri", "relayState", "forward", "out",
    "view", "image_url", "file", "data", "ref", "site", "uri", "to",
]

_DESTINATIONS = [
    "https://evil.psec.example/psec-redirect",
    "http://evil.psec.example/psec-redirect",
    "//evil.psec.example/psec-redirect",
    "///evil.psec.example/",
    "https:evil.psec.example",
    "/\\evil.psec.example/",
    "https://evil.psec.example%2f.example.com",
]

_META_JS = re.compile(
    r'(?i)<meta[^>]+http-equiv=["\']?refresh["\']?[^>]+url=([^"\'>\s]+)'
    r'|window\.location\s*=\s*["\']([^"\']+)'
    r'|location\.href\s*=\s*["\']([^"\']+)'
)


def _extract_redirect_target(headers: dict, body: str) -> str | None:
    loc = ""
    for k, v in (headers or {}).items():
        if k.lower() == "location":
            loc = v or ""
            break
    if loc:
        return loc
    m = _META_JS.search(body or "")
    if m:
        return next(g for g in m.groups() if g)
    return None


def _is_external(target: str, root_host: str) -> bool:
    if not target:
        return False
    t = target.strip()
    if t.startswith("//") or t.startswith("///"):
        return "evil.psec.example" in t.lower()
    if t.lower().startswith("javascript:"):
        return True
    try:
        p = urlparse(t if "://" in t else "http:" + t)
        host = (p.hostname or "").lower()
        if not host:
            return "evil.psec.example" in t.lower()
        return host != root_host and not host.endswith("." + root_host)
    except Exception:
        return "evil.psec.example" in t.lower()


async def scan(
    url: str,
    parameters: str = "",
    max_params: int = 8,
    max_dests: int = 4,
    user_agent: str = "pyodide-security/redirect-engine/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "redirect"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    p = urlparse(url)
    root_host = (p.hostname or "").lower()
    existing = dict(parse_qsl(p.query, keep_blank_values=True))
    headers = {"User-Agent": user_agent}

    params = [x.strip() for x in parameters.split(",") if x.strip()] if parameters else []
    if not params:
        # prefer params already present, then common names
        params = [k for k in existing.keys() if k.lower() in {x.lower() for x in _PARAMS}]
        for cand in _PARAMS:
            if cand not in params:
                params.append(cand)
    params = params[: max(1, min(int(max_params), 15))]
    dests = _DESTINATIONS[: max(1, min(int(max_dests), 8))]

    findings = []
    tests = []

    for param in params:
        for dest in dests:
            if not policy.can_request():
                break
            q = dict(existing)
            q[param] = dest
            test_url = urlunparse(p._replace(query=urlencode(q, doseq=True)))
            resp = await http_request(test_url, headers=headers)
            status = int(resp.get("status") or 0)
            hdrs = resp.get("headers") or {}
            body = resp.get("body") or ""
            target = _extract_redirect_target(hdrs, body)
            external = _is_external(target or "", root_host)
            # also check if final_url went external
            final = resp.get("final_url") or ""
            final_external = _is_external(final, root_host) if final else False

            entry = {
                "param": param,
                "payload": dest,
                "status": status,
                "location": target,
                "final_url": final or None,
                "external_redirect": external or final_external,
                "confidence": 90 if (external or final_external) and status in (301, 302, 303, 307, 308, 200) else (
                    60 if external else 0
                ),
                "error": resp.get("error"),
            }
            tests.append(entry)
            if entry["external_redirect"] and entry["confidence"] >= 60:
                findings.append(entry)

    findings.sort(key=lambda x: -x["confidence"])
    return {
        "ok": True,
        "url": url,
        "tested": len(tests),
        "vulnerable": bool(findings),
        "findings": findings,
        "tests": tests,
        "engine": "redirect",
        "version": "2.0",
        "equivalent": "PortSwigger open redirect / PayloadsAllTheThings",
        "policy": policy.status(),
    }
