import json
from functools import lru_cache
from pathlib import Path

@lru_cache(maxsize=1)
def load():
    return json.loads((Path(__file__).parent / "payloads.json").read_text())

def get(category: str) -> list:
    return list(load().get(category) or [])
