"""HAR file parser — extract requests/URLs/headers."""
from __future__ import annotations
import json
from typing import Any

def parse(har: str | dict)->dict[str,Any]:
    if isinstance(har, str):
        try: data=json.loads(har)
        except Exception as e: return {"ok":False,"error":f"invalid json: {e}","engine":"har"}
    else:
        data=har
    log=data.get("log") if isinstance(data, dict) else None
    if not isinstance(log, dict):
        return {"ok":False,"error":"missing log object","engine":"har"}
    entries=log.get("entries") or []
    reqs=[]
    for e in entries:
        req=e.get("request") or {}
        resp=e.get("response") or {}
        reqs.append({
            "method":req.get("method"),"url":req.get("url"),
            "status":resp.get("status"),
            "mime":(resp.get("content") or {}).get("mimeType"),
            "time_ms":e.get("time"),
        })
    urls=list(dict.fromkeys(r["url"] for r in reqs if r.get("url")))
    return {"ok":True,"count":len(reqs),"requests":reqs,"urls":urls,"url_count":len(urls),
            "creator":(log.get("creator") or {}).get("name"),"engine":"har","equivalent":"HAR 1.2"}
