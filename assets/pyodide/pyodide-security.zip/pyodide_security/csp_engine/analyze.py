"""CSP analyzer — policy parse + common misconfigurations."""
from __future__ import annotations
from typing import Any
from .._http import http_request
from .. import policy

DANGEROUS=["'unsafe-inline'","'unsafe-eval'","data:","blob:","*"]

def parse_csp(header: str)->dict[str,list[str]]:
    out={}
    for part in (header or "").split(";"):
        part=part.strip()
        if not part: continue
        bits=part.split()
        if not bits: continue
        out[bits[0].lower()]=bits[1:]
    return out

def analyze_policy(csp: str)->dict[str,Any]:
    directives=parse_csp(csp)
    issues=[]
    if not directives:
        issues.append({"issue":"missing CSP","severity":"medium"})
    for d,vals in directives.items():
        joined=" ".join(vals).lower()
        if "'unsafe-inline'" in joined and d in ("script-src","default-src","style-src"):
            issues.append({"issue":f"{d} allows 'unsafe-inline'","severity":"high","directive":d})
        if "'unsafe-eval'" in joined:
            issues.append({"issue":f"{d} allows 'unsafe-eval'","severity":"high","directive":d})
        if "*" in vals or any(v=="*" for v in vals):
            issues.append({"issue":f"{d} allows *","severity":"medium","directive":d})
        if "data:" in joined and d.startswith("script"):
            issues.append({"issue":f"{d} allows data:","severity":"medium","directive":d})
    if "object-src" not in directives and "default-src" not in directives:
        issues.append({"issue":"missing object-src/default-src","severity":"low"})
    if "frame-ancestors" not in directives:
        issues.append({"issue":"missing frame-ancestors","severity":"low"})
    return {"directives":directives,"issues":issues,"issue_count":len(issues),"directive_count":len(directives)}

async def analyze(url: str, user_agent: str="pyodide-security/csp/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"csp"}
    if not url.startswith(("http://","https://")): url="https://"+url
    resp=await http_request(url, headers={"User-Agent":user_agent})
    hdrs={str(k).lower():str(v) for k,v in (resp.get("headers") or {}).items()}
    csp=hdrs.get("content-security-policy","")
    csp_ro=hdrs.get("content-security-policy-report-only","")
    result=analyze_policy(csp or csp_ro)
    result.update({"ok":True,"url":url,"status":resp.get("status"),
                   "csp":csp or None,"csp_report_only":csp_ro or None,
                   "engine":"csp","equivalent":"CSP evaluator"})
    return result


async def scan_url(url: str, **kw):
    return await analyze(url, **kw)
