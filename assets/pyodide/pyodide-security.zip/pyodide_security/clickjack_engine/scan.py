"""Clickjacking detection — X-Frame-Options / CSP frame-ancestors."""
from __future__ import annotations
from typing import Any
from .._http import http_request
from .. import policy

async def scan(url: str, user_agent: str="pyodide-security/clickjack/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"clickjack"}
    if not url.startswith(("http://","https://")): url="https://"+url
    resp=await http_request(url, headers={"User-Agent":user_agent})
    hdrs={str(k).lower():str(v) for k,v in (resp.get("headers") or {}).items()}
    xfo=hdrs.get("x-frame-options","")
    csp=hdrs.get("content-security-policy","") or hdrs.get("content-security-policy-report-only","")
    frame_ancestors=""
    for part in csp.split(";"):
        p=part.strip().lower()
        if p.startswith("frame-ancestors"):
            frame_ancestors=part.strip()
    vulnerable=True
    reasons=[]
    if xfo.lower() in ("deny","sameorigin"):
        vulnerable=False; reasons.append(f"X-Frame-Options={xfo}")
    if "frame-ancestors" in csp.lower():
        if "'none'" in frame_ancestors.lower() or "'self'" in frame_ancestors.lower():
            vulnerable=False
        reasons.append(frame_ancestors or "frame-ancestors present")
    if not xfo and "frame-ancestors" not in csp.lower():
        reasons.append("missing X-Frame-Options and CSP frame-ancestors")
    return {"ok":True,"url":url,"status":resp.get("status"),"vulnerable":vulnerable,
            "x_frame_options":xfo or None,"csp_frame_ancestors":frame_ancestors or None,
            "reasons":reasons,"engine":"clickjack","equivalent":"X-Frame-Options/CSP check"}
