"""ASN lookup — bgpview / ip-api style HTTP."""
from __future__ import annotations
import json
from typing import Any
from urllib.parse import quote
from .._http import http_request
from .. import policy

async def lookup(ip: str="", asn: str="", host: str="", query: str="", user_agent: str="pyodide-security/asn/2.0")->dict[str,Any]:
    headers={"User-Agent":user_agent,"Accept":"application/json"}
    q = (query or host or "").strip()
    if not ip and q and q.replace(".", "").isdigit():
        ip = q
    if not asn and q.upper().startswith("AS"):
        asn = q
    if not ip and not asn and host:
        ip = host

    if asn:
        asn=asn.upper().replace("AS","")
        url=f"https://api.bgpview.io/asn/{quote(asn)}"
        err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
        if err: return {"ok":False,"error":err,"engine":"asn"}
        resp=await http_request(url, headers=headers)
        try: data=json.loads(resp.get("body") or "{}")
        except Exception: data={}
        return {"ok":True,"asn":asn,"data":data.get("data") or data,"status":resp.get("status"),"engine":"asn","equivalent":"bgpview"}
    if ip:
        url=f"https://api.bgpview.io/ip/{quote(ip)}"
        err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
        if err: return {"ok":False,"error":err,"engine":"asn"}
        resp=await http_request(url, headers=headers)
        try: data=json.loads(resp.get("body") or "{}")
        except Exception: data={}
        return {"ok":True,"ip":ip,"data":data.get("data") or data,"status":resp.get("status"),"engine":"asn","equivalent":"bgpview"}
    if q:
        url=f"https://ip-api.com/json/{quote(q)}?fields=status,query,as,asname,isp,org,country"
        resp=await http_request(url, headers=headers)
        try: data=json.loads(resp.get("body") or "{}")
        except Exception: data={}
        return {"ok":True,"query":q,"data":data,"status":resp.get("status"),"engine":"asn","equivalent":"ip-api"}
    return {"ok":False,"error":"ip or asn required","engine":"asn"}


async def lookup_ip(ip: str="", **kw):
    return await lookup(ip=ip, **kw)
