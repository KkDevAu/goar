from .lookup import lookup, lookup_ip
__all__=["lookup","lookup_ip"]
