from .scan import scan, list_payloads
try:
    from .payloads_pat import list_payloads as list_payloads_pat
except Exception:
    def list_payloads_pat():
        return list_payloads()

__all__ = ["scan", "list_payloads", "list_payloads_pat"]
