"""
XXE engine — PayloadsAllTheThings XXE Injection conversion.

36 classic + PAT-derived XML external entity payloads.
"""

from __future__ import annotations

import gzip
import json
from pathlib import Path
from typing import Any

from .._http import http_request
from .. import policy

_PATH = Path(__file__).with_name("data") / "payloads.json.gz"
_PAYLOADS: list[str] | None = None


def _payloads() -> list[str]:
    global _PAYLOADS
    if _PAYLOADS is None:
        with gzip.open(_PATH, "rt", encoding="utf-8") as f:
            _PAYLOADS = json.load(f)
    return _PAYLOADS


def list_payloads(limit: int = 0) -> dict[str, Any]:
    rows = _payloads()
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {
        "ok": True,
        "count": len(rows),
        "returned": len(out),
        "payloads": out,
        "source": "PayloadsAllTheThings/XXE Injection",
        "engine": "xxe",
        "equivalent": "PayloadsAllTheThings XXE",
    }


async def scan(
    url: str,
    max_payloads: int = 8,
    content_type: str = "application/xml",
    user_agent: str = "pyodide-security/xxe/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "xxe"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    payloads = _payloads()
    if max_payloads and max_payloads > 0:
        payloads = payloads[: int(max_payloads)]

    headers = {"User-Agent": user_agent, "Content-Type": content_type, "Accept": "*/*"}
    base = await http_request(url, method="POST", headers={**headers, "Content-Type": "text/plain"}, body="<ping/>")
    base_body = (base.get("body") or "").lower()
    findings = []
    tested = 0
    sigs = ("root:", "daemon:", "[extensions]", "for 16-bit", "base64", "DOCTYPE", "ENTITY", "file://", "/etc/passwd", "win.ini")
    for pl in payloads:
        if not policy.can_request():
            break
        tested += 1
        resp = await http_request(url, method="POST", headers=headers, body=pl)
        body = resp.get("body") or ""
        bl = body.lower()
        hits = [s for s in sigs if s.lower() in bl and s.lower() not in base_body]
        if hits or (resp.get("status") != base.get("status") and resp.get("status") not in (0, None)):
            findings.append({
                "payload_preview": pl[:120],
                "status": resp.get("status"),
                "signals": hits,
                "length": len(body),
            })
    return {
        "ok": True,
        "url": url,
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "payload_db": len(_payloads()),
        "engine": "xxe",
        "source": "PayloadsAllTheThings/XXE Injection",
    }
