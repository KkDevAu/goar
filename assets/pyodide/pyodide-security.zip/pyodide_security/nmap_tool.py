
"""Back-compat shim → nmap_engine."""
from .nmap_engine import list_services, top_ports, lookup_port
from .nmap_engine.services import list_services as all_services

# aliases expected by registry
lookup = lookup_port

try:
    from .nmap_engine.parse import parse
except Exception:
    def parse(*a, **k):
        return {"ok": False, "error": "nmap parse unavailable"}

try:
    from .nmap_engine.probe import http_probe
except Exception:
    http_probe=None
try:
    from .nmap_engine.nse_http import nse_http
except Exception:
    nse_http=None

__all__=["list_services","top_ports","lookup_port","lookup","all_services","parse","http_probe","nse_http"]
