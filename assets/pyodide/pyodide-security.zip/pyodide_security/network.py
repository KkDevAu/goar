"""
Unified network bootstrap for all pyodide_security engines.

Transport priority:
  1. libcurl.js + Wisp (wss://cors.manus.space/wisp/) [+ Epoxy if present]
  2. Manus HTTP CORS proxy (https://cors.manus.space/api/proxy/:url)
  3. Direct pyfetch (same-origin / CORS-open only)

Call `await network.ensure()` once at session start so every http_request
automatically gets a reliable path.
"""

from __future__ import annotations

from typing import Any

from . import libcurl_bridge
from . import proxy_tool
from . import _http

_WISP = "wss://cors.manus.space/wisp/"
_CORS = "https://cors.manus.space/api/proxy"

_last_ensure: dict[str, Any] | None = None


def status() -> dict[str, Any]:
    return {
        "libcurl": libcurl_bridge.status(),
        "proxy": _http.proxy_status() if hasattr(_http, "proxy_status") else proxy_tool.status(),
        "wisp_default": _WISP,
        "cors_default": _CORS,
        "last_ensure": _last_ensure,
        "recommended_order": [
            "libcurl+wisp(+epoxy)",
            "manus-http-cors",
            "direct-pyfetch",
        ],
    }


async def ensure(
    wisp_url: str = "",
    origin: str = "",
    force: bool = False,
) -> dict[str, Any]:
    """
    Bring up the full network stack:

    1. libcurl.set_websocket(Wisp) when WASM is loaded in the host page
    2. Manus CORS API key via proxy.ensure / generate
    3. Wire configure_proxy so _http.http_request can fall back cleanly

    Safe to call multiple times.
    """
    global _last_ensure

    wisp = wisp_url or _WISP
    result: dict[str, Any] = {
        "ok": False,
        "libcurl": None,
        "proxy": None,
        "active_transports": [],
    }

    # --- 1) libcurl + Wisp (+ Epoxy detection) ---
    try:
        libcurl_bridge.configure(
            preferred=True,
            wisp_url=wisp,
            epoxy_enabled=True,
            transport_mode="auto",
        )
        lc = await libcurl_bridge.ensure(wisp_url=wisp, force_websocket=True)
        result["libcurl"] = lc
        if lc.get("ok"):
            result["active_transports"].append(lc.get("transport") or "libcurl+wisp")
    except Exception as e:  # noqa: BLE001
        result["libcurl"] = {"ok": False, "error": str(e)}

    # --- 2) Manus CORS API key ---
    try:
        px = await proxy_tool.ensure(origin=origin, force=force)
        result["proxy"] = px
        if px.get("ok"):
            result["active_transports"].append("manus-http-cors")
            # ensure _http proxy mirrors key
            try:
                key = ""
                st = px.get("proxy") or {}
                key = st.get("api_key") or st.get("key") or ""
                if not key and hasattr(proxy_tool, "get_key"):
                    key = proxy_tool.get_key() or ""
                # proxy_tool.ensure already configures; double-check
                if key:
                    _http.configure_proxy(api_key=key, enabled=True, base_url=_CORS)
            except Exception:
                pass
    except Exception as e:  # noqa: BLE001
        result["proxy"] = {"ok": False, "error": str(e)}

    result["ok"] = bool(result["active_transports"])
    result["status"] = status()
    result["hint"] = (
        None
        if result["ok"]
        else (
            "No transport ready. Host page must either:\n"
            "  A) Load libcurl.js + WASM and set_websocket('wss://cors.manus.space/wisp/'), or\n"
            "  B) Expose POST /api/manus-key for CORS proxy key generation."
        )
    )
    _last_ensure = result
    return result


async def test(target: str = "https://example.com/") -> dict[str, Any]:
    """Probe connectivity through the unified http_request path."""
    resp = await _http.http_request(target, method="GET", headers={"User-Agent": "pyodide-security/network-test"})
    return {
        "ok": bool(resp.get("status")),
        "target": target,
        "status": resp.get("status"),
        "transport": resp.get("transport") or (
            "libcurl+wisp" if resp.get("via_libcurl") else ("manus-cors" if resp.get("via_proxy") else "direct")
        ),
        "via_libcurl": resp.get("via_libcurl"),
        "via_proxy": resp.get("via_proxy"),
        "via_wisp": resp.get("via_wisp"),
        "elapsed_ms": resp.get("elapsed_ms"),
        "error": resp.get("error"),
        "stack": status(),
    }
