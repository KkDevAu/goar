"""
Backup / sensitive file discovery — SecLists Common-DB-Backups + common paths.
"""

from __future__ import annotations

import gzip
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .._http import http_request
from .. import policy

_DATA = Path(__file__).with_name("data")
_FILES: list[str] | None = None


def _files() -> list[str]:
    global _FILES
    if _FILES is None:
        rows = []
        for name in ("backup-files.txt.gz", "common.txt.gz"):
            p = _DATA / name
            if p.exists():
                with gzip.open(p, "rt", encoding="utf-8") as f:
                    rows.extend(ln.strip() for ln in f.read().splitlines() if ln.strip())
        # classic extras
        rows.extend([
            ".git/HEAD", ".git/config", ".env", ".env.local", ".env.backup",
            "backup.sql", "dump.sql", "db.sql", "database.sql",
            "wp-config.php.bak", "config.php.bak", "web.config.bak",
            ".DS_Store", "thumbs.db", "backup.zip", "backup.tar.gz",
            "site.zip", "www.zip", "html.zip",
        ])
        _FILES = list(dict.fromkeys(rows))
    return _FILES


def list_files(limit: int = 0) -> dict[str, Any]:
    rows = _files()
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {
        "ok": True,
        "count": len(rows),
        "returned": len(out),
        "files": out,
        "source": "SecLists Common-DB-Backups + common.txt",
        "engine": "backup",
    }


async def scan(
    url: str,
    max_paths: int = 50,
    user_agent: str = "pyodide-security/backup/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "backup"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if not url.endswith("/"):
        url += "/"

    paths = _files()[: max(1, int(max_paths))]
    headers = {"User-Agent": user_agent}
    found = []
    tested = 0
    for path in paths:
        if not policy.can_request():
            break
        tested += 1
        target = urljoin(url, path.lstrip("/"))
        resp = await http_request(target, headers=headers)
        st = resp.get("status") or 0
        if st in (200, 403):
            body = resp.get("body") or ""
            found.append({
                "path": path,
                "url": target,
                "status": st,
                "length": len(body),
            })
    return {
        "ok": True,
        "url": url,
        "tested": tested,
        "found": found,
        "found_count": len(found),
        "path_db": len(_files()),
        "engine": "backup",
        "source": "SecLists",
    }
