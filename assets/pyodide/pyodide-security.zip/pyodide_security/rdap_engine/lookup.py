"""RDAP domain/IP lookup — rdap.org bootstrap."""
from __future__ import annotations
import json
from typing import Any
from urllib.parse import quote
from .._http import http_request
from .. import policy
from ..subenum_engine.sources import clean_domain

async def domain_rdap(domain: str, user_agent: str="pyodide-security/rdap/2.0")->dict[str,Any]:
    domain=clean_domain(domain)
    url=f"https://rdap.org/domain/{quote(domain)}"
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"rdap"}
    resp=await http_request(url, headers={"User-Agent":user_agent,"Accept":"application/rdap+json, application/json"})
    data=None
    try: data=json.loads(resp.get("body") or "")
    except Exception: pass
    summary={}
    if isinstance(data, dict):
        summary={"ldhName":data.get("ldhName"),"status":data.get("status"),
                 "entities":[e.get("roles") for e in (data.get("entities") or [])][:10],
                 "events":data.get("events"),"nameservers":[n.get("ldhName") for n in (data.get("nameservers") or [])]}
    return {"ok":True,"domain":domain,"status":resp.get("status"),"summary":summary,"engine":"rdap","equivalent":"RDAP"}

async def ip_rdap(ip: str, user_agent: str="pyodide-security/rdap/2.0")->dict[str,Any]:
    url=f"https://rdap.org/ip/{quote(ip)}"
    resp=await http_request(url, headers={"User-Agent":user_agent,"Accept":"application/rdap+json, application/json"})
    data=None
    try: data=json.loads(resp.get("body") or "")
    except Exception: pass
    return {"ok":True,"ip":ip,"status":resp.get("status"),"data":data if isinstance(data,dict) else None,"engine":"rdap"}
