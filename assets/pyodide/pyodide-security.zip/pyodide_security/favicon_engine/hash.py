"""Favicon hash — Shodan-style mmh3 of base64 favicon (pure Python)."""
from __future__ import annotations
import base64, hashlib, struct
from typing import Any
from urllib.parse import urljoin
from .._http import http_request
from .. import policy

def _mmh3_32(data: bytes, seed: int=0)->int:
    """MurmurHash3 32-bit (Shodan favicon hash compatible)."""
    c1,c2=0xcc9e2d51,0x1b873593
    length=len(data); h=seed; i=0
    while i+4<=length:
        k=struct.unpack_from("<I", data, i)[0]
        k=(k*c1)&0xFFFFFFFF; k=((k<<15)|(k>>17))&0xFFFFFFFF; k=(k*c2)&0xFFFFFFFF
        h^=k; h=((h<<13)|(h>>19))&0xFFFFFFFF; h=(h*5+0xe6546b64)&0xFFFFFFFF
        i+=4
    k=0
    leftover=data[i:]
    if len(leftover)>=3: k^=leftover[2]<<16
    if len(leftover)>=2: k^=leftover[1]<<8
    if len(leftover)>=1:
        k^=leftover[0]; k=(k*c1)&0xFFFFFFFF; k=((k<<15)|(k>>17))&0xFFFFFFFF; k=(k*c2)&0xFFFFFFFF; h^=k
    h^=length; h^=(h>>16); h=(h*0x85ebca6b)&0xFFFFFFFF; h^=(h>>13); h=(h*0xc2b2ae35)&0xFFFFFFFF; h^=(h>>16)
    # signed 32-bit like Java/Shodan
    if h>=0x80000000: h-=0x100000000
    return h

def hash_bytes(data: bytes)->dict[str,Any]:
    b64=base64.encodebytes(data)  # with newlines like Shodan
    return {"mmh3":_mmh3_32(b64),"sha256":hashlib.sha256(data).hexdigest(),"md5":hashlib.md5(data).hexdigest(),"length":len(data)}

async def hash(url: str, user_agent: str="pyodide-security/favicon/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"favicon"}
    if not url.startswith(("http://","https://")): url="https://"+url
    # try /favicon.ico and HTML link
    candidates=[urljoin(url,"/favicon.ico")]
    headers={"User-Agent":user_agent}
    page=await http_request(url, headers=headers)
    body=page.get("body") or ""
    import re
    for m in re.finditer(r'<link[^>]+rel=["\'][^"\']*icon[^"\']*["\'][^>]+href=["\']([^"\']+)["\']', body, re.I):
        candidates.insert(0, urljoin(url, m.group(1)))
    for m in re.finditer(r'<link[^>]+href=["\']([^"\']+)["\'][^>]+rel=["\'][^"\']*icon[^"\']*["\']', body, re.I):
        candidates.insert(0, urljoin(url, m.group(1)))
    last_err=None
    for c in candidates[:5]:
        if not policy.can_request(): break
        resp=await http_request(c, headers=headers)
        raw=resp.get("body") or ""
        # body is text - for binary favicons we only have text decode; still hash utf-8 bytes
        data=raw.encode("utf-8","replace") if isinstance(raw,str) else raw
        if resp.get("status")==200 and len(data)>10:
            h=hash_bytes(data)
            h.update({"ok":True,"url":c,"status":200,"engine":"favicon","equivalent":"shodan favicon mmh3"})
            return h
        last_err=resp.get("error") or f"status {resp.get('status')}"
    return {"ok":False,"error":last_err or "favicon not found","engine":"favicon"}


async def hash_url(url: str, user_agent: str="pyodide-security/favicon/2.0"):
    return await hash(url, user_agent=user_agent)
