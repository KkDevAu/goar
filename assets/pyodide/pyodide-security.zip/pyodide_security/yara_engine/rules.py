"""YARA-like pattern scanner — built-in secret/webshell signatures."""
from __future__ import annotations
import re
from typing import Any

RULES=[
    {"id":"aws_akid","name":"AWS Access Key","regex":r"AKIA[0-9A-Z]{16}"},
    {"id":"aws_secret","name":"AWS Secret heuristic","regex":r"(?i)aws(.{0,20})?(secret|access).{0,20}['\"][0-9a-zA-Z/+]{40}['\"]"},
    {"id":"github_pat","name":"GitHub PAT","regex":r"ghp_[A-Za-z0-9]{36}"},
    {"id":"slack_token","name":"Slack token","regex":r"xox[baprs]-[0-9a-zA-Z-]{10,}"},
    {"id":"private_key","name":"Private key header","regex":r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----"},
    {"id":"jwt","name":"JWT","regex":r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"},
    {"id":"webshell_eval","name":"PHP eval webshell","regex":r"(?i)(eval|assert)\s*\(\s*(base64_decode|gzinflate|str_rot13)"},
    {"id":"webshell_cmd","name":"PHP command exec","regex":r"(?i)(system|passthru|shell_exec|exec)\s*\(\s*\$_(GET|POST|REQUEST)"},
    {"id":"xss_script","name":"Script tag","regex":r"(?i)<script[^>]*>"},
    {"id":"sqli_union","name":"UNION SELECT","regex":r"(?i)union(\s+all)?\s+select"},
]

def list_rules()->dict[str,Any]:
    return {"ok":True,"count":len(RULES),"rules":RULES,"engine":"yara","equivalent":"YARA-style builtin"}

def scan(text: str="", max_hits: int=50)->dict[str,Any]:
    hits=[]
    for r in RULES:
        if len(hits)>=max_hits: break
        try: rx=re.compile(r["regex"])
        except re.error: continue
        for m in rx.finditer(text or ""):
            hits.append({"id":r["id"],"name":r["name"],"match":m.group(0)[:160],"offset":m.start()})
            if len(hits)>=max_hits: break
    return {"ok":True,"hit_count":len(hits),"hits":hits,"rule_db":len(RULES),"engine":"yara"}
