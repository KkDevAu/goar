"""Shodan InternetDB lookup — internetdb.shodan.io."""
from __future__ import annotations
import json
from typing import Any
from urllib.parse import quote
from .._http import http_request
from .. import policy

async def lookup(ip: str, user_agent: str="pyodide-security/internetdb/2.0")->dict[str,Any]:
    ip=(ip or "").strip()
    if not ip: return {"ok":False,"error":"ip required","engine":"internetdb"}
    url=f"https://internetdb.shodan.io/{quote(ip)}"
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"internetdb"}
    resp=await http_request(url, headers={"User-Agent":user_agent,"Accept":"application/json"})
    try: data=json.loads(resp.get("body") or "{}")
    except Exception: data={"raw":(resp.get("body") or "")[:500]}
    return {"ok":True,"ip":ip,"ports":data.get("ports"),"cpes":data.get("cpes"),"hostnames":data.get("hostnames"),
            "tags":data.get("tags"),"vulns":data.get("vulns"),"data":data,"status":resp.get("status"),
            "engine":"internetdb","equivalent":"Shodan InternetDB"}


async def lookup_host(ip: str="", host: str="", **kw):
    return await lookup(ip or host, **kw)
