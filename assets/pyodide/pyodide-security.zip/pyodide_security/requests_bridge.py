"""
Manus-aware requests bridge for Pyodide.

After pyodide-http.patch_all(), this installs a Session that routes every
request through the configured Manus CORS proxy (configure_proxy / auto-mint).
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote


def patch_pyodide_http() -> dict[str, Any]:
    """Install pyodide-http patches if the package is available."""
    try:
        import pyodide_http  # type: ignore

        pyodide_http.patch_all()
        return {"ok": True, "patched": True, "version": getattr(pyodide_http, "__version__", "?")}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "patched": False, "error": f"{type(e).__name__}: {e}"}


def _proxy_url(target: str, method: str = "GET") -> tuple[str, dict[str, str]]:
    from ._http import proxy_status

    st = proxy_status()
    if not st.get("configured") or not st.get("enabled"):
        raise RuntimeError("Manus proxy not configured — call proxy.configure first")
    # pull raw key via internal state
    from . import _http as h

    key = (h._proxy.get("api_key") or "").strip()
    base = (h._proxy.get("base_url") or "https://cors.manus.space/api/proxy").rstrip("?")
    q = f"url={quote(target, safe='')}&apikey={quote(key, safe='')}"
    if method.upper() not in ("GET", "HEAD"):
        q += f"&method={quote(method.upper(), safe='')}"
    headers = {
        "x-api-key": key,
        "x-target-url": target,
    }
    return f"{base}?{q}", headers


def proxied_request(
    method: str,
    url: str,
    headers: dict[str, str] | None = None,
    data: Any = None,
    json_body: Any = None,
    timeout: float = 30,
) -> dict[str, Any]:
    """
    Issue an HTTP request via Manus using requests (pyodide-http patched).
    Falls back to pyodide_security._http.http_request if requests missing.
    """
    method = (method or "GET").upper()
    try:
        import requests  # type: ignore

        patch_pyodide_http()
        proxy_url, pheaders = _proxy_url(url, method)
        hdrs = dict(pheaders)
        for k, v in (headers or {}).items():
            if k.lower() in ("authorization", "content-type"):
                hdrs[k] = v
        kwargs: dict[str, Any] = {"headers": hdrs, "timeout": timeout}
        if json_body is not None:
            kwargs["json"] = json_body
        elif data is not None:
            kwargs["data"] = data
        # Always GET/POST to the proxy hop; method override is in query
        hop_method = method if method in ("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE") else "POST"
        if hop_method == "HEAD":
            hop_method = "GET"
        resp = requests.request(hop_method, proxy_url, **kwargs)
        return {
            "ok": 200 <= resp.status_code < 400,
            "status": resp.status_code,
            "headers": dict(resp.headers),
            "body": resp.text,
            "url": url,
            "via_proxy": True,
            "engine": "requests+pyodide-http+manus",
        }
    except Exception as e:  # noqa: BLE001
        return {
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
            "url": url,
            "engine": "requests-bridge",
        }


async def proxied_request_async(
    method: str,
    url: str,
    headers: dict[str, str] | None = None,
    body: str | None = None,
) -> dict[str, Any]:
    """Async path using built-in pyfetch Manus router (always available)."""
    from ._http import http_request

    return await http_request(url, method=method, headers=headers, body=body)


def status() -> dict[str, Any]:
    from ._http import proxy_status

    ph = patch_pyodide_http()
    try:
        import requests  # type: ignore

        req = True
        req_ver = getattr(requests, "__version__", "?")
    except Exception:
        req = False
        req_ver = None
    return {
        "pyodide_http": ph,
        "requests_available": req,
        "requests_version": req_ver,
        "proxy": proxy_status(),
        "engine": "requests-bridge",
    }


def get(url: str, method: str = "GET") -> dict:
    """Registry-friendly GET/POST via Manus+requests."""
    return proxied_request(method or "GET", url)


def post(url: str, body: str = "", content_type: str = "application/json") -> dict:
    headers = {"Content-Type": content_type} if content_type else {}
    return proxied_request("POST", url, headers=headers, data=body or None)
