"""
SIMD crypto stack loader — KkDevAu/psec-simd-wheels (Pyodide 0.27.5-simd1).

Wheels (WebAssembly SIMD128):
  cryptography 42.0.5, cffi 1.17.1, pycparser, six, openssl 1.1.1w

Load order:
  1. Local EMFS path (host mirrored packages)
  2. Release CDN/GitHub download URLs via micropip
  3. Graceful fallback to pure-Python crypto already in the kit

Host integration example:
  # after loadPyodide, before importing psec tools that need real RSA/AES
  await pyodide.loadPackage(["micropip"])
  await pyodide.runPythonAsync('''
from simd_crypto import ensure
print(await ensure())
''')
"""

from __future__ import annotations

from typing import Any

RELEASE_TAG = "0.27.5-simd1"
RELEASE_BASE = (
    f"https://github.com/KkDevAu/psec-simd-wheels/releases/download/{RELEASE_TAG}"
)

# Install order matters: pure-python deps first, then cffi, then cryptography
_WHEEL_ORDER = [
    "six-1.16.0-py2.py3-none-any.whl",
    "pycparser-2.22-py3-none-any.whl",
    "cffi-1.17.1-cp312-cp312-pyodide_2024_0_wasm32.whl",
    "cryptography-42.0.5-cp312-cp312-pyodide_2024_0_wasm32.whl",
]

_SHA256 = {
    "six-1.16.0-py2.py3-none-any.whl": "28d57f2d92e662656a86f62ac65e658209dd23bcd222aa6fde3250a522712bcc",
    "pycparser-2.22-py3-none-any.whl": "c3929b568b03e67448a3dca7906cfa53f998f102e9cfd89085e43dcfd62ae9b4",
    "cffi-1.17.1-cp312-cp312-pyodide_2024_0_wasm32.whl": "f0964947cb3c12b220e66df181f401916048bec475aa18858d9ab054266d0921",
    "cryptography-42.0.5-cp312-cp312-pyodide_2024_0_wasm32.whl": "6b1d58c4ff7d27187282318fffde46aa6e869771dd65a61baee01bdda6c4610d",
}

_state: dict[str, Any] = {
    "loaded": False,
    "source": None,
    "error": None,
    "cryptography_version": None,
}


def status() -> dict[str, Any]:
    crypto_ok = False
    ver = None
    try:
        import cryptography

        crypto_ok = True
        ver = getattr(cryptography, "__version__", "?")
    except Exception as e:  # noqa: BLE001
        _state["error"] = f"{type(e).__name__}: {e}"
    return {
        "loaded": bool(_state["loaded"] or crypto_ok),
        "cryptography_available": crypto_ok,
        "cryptography_version": ver or _state.get("cryptography_version"),
        "source": _state.get("source"),
        "release": RELEASE_TAG,
        "release_base": RELEASE_BASE,
        "wheels": list(_WHEEL_ORDER),
        "error": _state.get("error"),
        "simd": "wasm128",
        "note": (
            "Real cryptography module available — JWT RS/ES verify, X.509, Fernet enabled"
            if crypto_ok
            else "cryptography not loaded — kit uses pure-Python fallbacks"
        ),
    }


def is_ready() -> bool:
    try:
        import cryptography  # noqa: F401

        return True
    except Exception:
        return False


async def ensure(
    local_dir: str = "",
    use_github: bool = True,
) -> dict[str, Any]:
    """
    Install SIMD cryptography stack into the current Pyodide runtime.

    local_dir: optional EMFS path containing the .whl files
               e.g. /wasm/simd/0.27.5-simd1/packages
    use_github: if local missing, micropip.install from GitHub release URLs
    """
    if is_ready():
        _state["loaded"] = True
        _state["source"] = _state.get("source") or "preinstalled"
        return status()

    try:
        import micropip  # type: ignore
    except Exception as e:  # noqa: BLE001
        _state["error"] = f"micropip unavailable: {e}"
        return {**status(), "ok": False, "error": _state["error"]}

    installed: list[str] = []
    errors: list[str] = []

    # 1) Local EMFS
    if local_dir:
        base = local_dir.rstrip("/")
        for name in _WHEEL_ORDER:
            path = f"{base}/{name}"
            try:
                # micropip can install from emfs path as file URL style
                await micropip.install(f"emfs:{path}")
                installed.append(f"emfs:{name}")
            except Exception:
                try:
                    await micropip.install(path)
                    installed.append(path)
                except Exception as e:  # noqa: BLE001
                    errors.append(f"local {name}: {e}")

    # 2) GitHub release URLs
    if use_github and not is_ready():
        for name in _WHEEL_ORDER:
            url = f"{RELEASE_BASE}/{name}"
            try:
                await micropip.install(url)
                installed.append(url)
            except Exception as e:  # noqa: BLE001
                errors.append(f"url {name}: {e}")

    ok = is_ready()
    _state["loaded"] = ok
    _state["source"] = "github+local" if installed else None
    if ok:
        try:
            import cryptography

            _state["cryptography_version"] = cryptography.__version__
        except Exception:
            pass
        _state["error"] = None
    else:
        _state["error"] = "; ".join(errors[-4:]) if errors else "install failed"

    return {
        "ok": ok,
        "installed": installed,
        "errors": errors,
        **status(),
    }


def wheel_urls() -> dict[str, Any]:
    return {
        "release": RELEASE_TAG,
        "base": RELEASE_BASE,
        "wheels": {name: f"{RELEASE_BASE}/{name}" for name in _WHEEL_ORDER},
        "sha256": dict(_SHA256),
        "manifest": f"{RELEASE_BASE}/MANIFEST.json",
        "bundle_zip": f"{RELEASE_BASE}/simd-{RELEASE_TAG}.zip",
    }
