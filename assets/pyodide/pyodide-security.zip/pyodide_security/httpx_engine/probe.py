"""
HTTPX-class probe — status, title, webserver, content-type, length, CDN, tech hints, hashes.
"""
from __future__ import annotations

import hashlib
import re
from typing import Any
from urllib.parse import urlparse

from .._http import http_request
from .. import policy

CDN_HEADERS = {
    "cf-ray": "cloudflare",
    "x-served-by": "fastly",
    "x-amz-cf-id": "cloudfront",
    "x-azure-ref": "azure",
    "x-vercel-id": "vercel",
    "x-sucuri-id": "sucuri",
    "x-cdn": "cdn",
}

TECH_HINTS = [
    (r"wp-content|wordpress", "wordpress"),
    (r"drupal", "drupal"),
    (r"joomla", "joomla"),
    (r"laravel", "laravel"),
    (r"react", "react"),
    (r"next\.js|__next", "nextjs"),
    (r"nginx", "nginx"),
    (r"apache", "apache"),
]


def _title(body: str) -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", body or "", re.I | re.S)
    return re.sub(r"\s+", " ", m.group(1)).strip()[:200] if m else ""


def _hdr(headers: dict, *names: str) -> str:
    lower = {str(k).lower(): str(v) for k, v in headers.items()}
    for n in names:
        if n.lower() in lower:
            return lower[n.lower()]
    return ""


async def probe(
    url: str = "",
    urls: str = "",
    user_agent: str = "pyodide-security/httpx/3.0",
) -> dict[str, Any]:
    targets = []
    if url:
        targets.append(url)
    if urls:
        targets.extend(u.strip() for u in urls.replace(",", "\n").splitlines() if u.strip())
    targets = list(dict.fromkeys(targets))
    if not targets:
        return {"ok": False, "error": "url or urls required", "engine": "httpx"}

    results = []
    for t in targets:
        if not t.startswith(("http://", "https://")):
            t = "https://" + t
        err = policy.check_url_for_active(t) if hasattr(policy, "check_url_for_active") else None
        if err:
            results.append({"url": t, "error": err})
            continue
        if not policy.can_request():
            break
        resp = await http_request(t, headers={"User-Agent": user_agent})
        body = resp.get("body") or ""
        headers = resp.get("headers") or {}
        lower = {str(k).lower(): str(v) for k, v in headers.items()}
        cdn = None
        for hk, name in CDN_HEADERS.items():
            if hk in lower:
                cdn = name
                break
        tech = []
        blob = body[:5000] + " " + " ".join(lower.values())
        for rx, name in TECH_HINTS:
            if re.search(rx, blob, re.I):
                tech.append(name)
        body_hash = hashlib.sha256(body.encode("utf-8", "replace")).hexdigest()[:16]
        results.append({
            "url": t,
            "final_url": resp.get("final_url") or t,
            "status_code": resp.get("status"),
            "title": _title(body),
            "webserver": _hdr(headers, "server"),
            "content_type": _hdr(headers, "content-type"),
            "content_length": len(body),
            "cdn": cdn,
            "tech": tech,
            "hash": body_hash,
            "failed": not bool(resp.get("status")),
            "error": resp.get("error"),
            "transport": resp.get("transport"),
            "via_libcurl": resp.get("via_libcurl"),
            "via_proxy": resp.get("via_proxy"),
            "elapsed_ms": resp.get("elapsed_ms"),
        })
    return {
        "ok": True,
        "count": len(results),
        "results": results,
        "engine": "httpx",
        "equivalent": "projectdiscovery/httpx",
    }
