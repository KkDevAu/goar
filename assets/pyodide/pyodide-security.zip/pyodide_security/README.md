# pyodide_security v7.5

## Network stack (required for reliable scanning)

Every engine goes through `http_request`, which uses this priority:

1. **libcurl.js + Wisp** (`wss://cors.manus.space/wisp/`) — full headers, no browser CORS
2. **Epoxy TLS** (when host provides Bare-Mux / Epoxy transport)
3. **Manus HTTP CORS** (`https://cors.manus.space/api/proxy/:targetUrl`) — API key
4. **Direct pyfetch** — same-origin / CORS-open only

### Host page bootstrap

```html
<script src="/libcurl.js"></script>
<script type="module">
  // Optional: Bare-Mux + Epoxy for TLS sockets
  // import { BareMuxConnection } from "@mercuryworkshop/bare-mux";
  // import EpoxyTransport from "@mercuryworkshop/epoxy-transport";

  await libcurl.load_wasm("/libcurl.wasm");
  libcurl.set_websocket("wss://cors.manus.space/wisp/");
  // Optional Epoxy:
  // const connection = new BareMuxConnection(...);
  // await connection.setRemoteTransport(new EpoxyTransport(...));
</script>
```

### Python session start

```python
# One call wires libcurl/Wisp/Epoxy detection + Manus CORS key
await run_tool_async("network.ensure")

# Or step-by-step:
await run_tool_async("libcurl.ensure")   # Wisp websocket
await run_tool_async("proxy.ensure")     # Manus API key

run_tool("network.status")               # inspect transports
await run_tool_async("network.test", target="https://example.com/")
```

After `network.ensure`, **all** tools (`sqlmap`, `nikto`, `nuclei`, `xss`, …) automatically use the best available transport.

## 1:1 upstream corpora

| Engine | Upstream | Corpus |
|--------|----------|--------|
| waf | wafw00f | 173 plugins |
| param | Arjun | 25 889 words |
| cors | CORScanner | 10 tests |
| xss | XSStrike | real payloads |
| smuggle | smuggler | 136 mutations |
| jwt | jwt_tool | attack set |
| sqlmap | sqlmap | 363 tests / 174 errors |
| nikto | nikto | 7240 checks |
| nuclei | nuclei-templates | 2825 templates |
| dirb | dirsearch | 9681 paths |
| tech | Wappalyzer | 3931 fingerprints |
| inject family | PayloadsAllTheThings | SSRF/SSTI/XXE/… |

## Changelog

- **7.5.0** — Unified `network.ensure` (libcurl + Wisp + Epoxy detect + Manus CORS); soft auto-bootstrap in `http_request`
- **7.4.0** — Wappalyzer 3931, takeover CITOY
- **7.3.0** — nikto / nuclei / dirsearch / PAT
- **7.2.0** — sqlmap XML corpus
