"""
HTTP transport for Pyodide with corsproxy (Manus) CORS forwarding.

Official stack: https://cors.manus.space
  HTTP:  ALL /api/proxy/:targetUrl   (path form recommended)
         also ?url= & ?apikey=       (legacy query form)
  Wisp:  wss://cors.manus.space/wisp/  (Bare-Mux / Epoxy / libcurl.js clients)

Browser-allowed request headers on the proxy hop:
  Content-Type, Authorization, x-api-key, x-target-url

Optional query flags (passed through when set on _proxy extras or per-call):
  render=true, extract=1, selector=..., ttl=seconds, method=...
"""


from __future__ import annotations

import json
import time
from typing import Any
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlparse, urlunparse

from . import policy as _policy

DEFAULT_PROXY_BASE = "https://cors.manus.space/api/proxy"

# CORS allow-list on cors.manus.space (from Access-Control-Allow-Headers)
_PROXY_ALLOWED_HEADERS = frozenset(
    {
        "content-type",
        "authorization",
        "x-api-key",
        "x-target-url",
    }
)

_proxy: dict[str, Any] = {
    "enabled": False,
    "api_key": "",
    "base_url": DEFAULT_PROXY_BASE,
    # "both" = x-api-key header + apikey query (most reliable)
    "auth_mode": "both",
}


def configure_proxy(
    api_key: str = "",
    enabled: bool | None = None,
    base_url: str = "",
    auth_mode: str = "",
    url_style: str = "",
    extras: dict | None = None,
    wisp_url: str = "",
) -> dict[str, Any]:
    if api_key is not None and api_key != "":
        _proxy["api_key"] = str(api_key).strip()
    if base_url:
        # normalize: strip trailing slash and any accidental query
        _proxy["base_url"] = base_url.split("?")[0].rstrip("/")
    if auth_mode in ("header", "query", "both"):
        _proxy["auth_mode"] = auth_mode
    if url_style in ("path", "query"):
        _proxy["url_style"] = url_style
    if extras is not None:
        _proxy["extras"] = dict(extras)
    if wisp_url:
        _proxy["wisp_url"] = wisp_url
    if enabled is None:
        _proxy["enabled"] = bool(_proxy["api_key"])
    else:
        _proxy["enabled"] = bool(enabled)
    return proxy_status()


def disable_proxy() -> dict[str, Any]:
    _proxy["enabled"] = False
    return proxy_status()


def proxy_status() -> dict[str, Any]:
    key = _proxy.get("api_key") or ""
    masked = ""
    if key:
        masked = (key[:2] + "…" + key[-2:]) if len(key) <= 8 else (key[:4] + "…" + key[-4:])
    return {
        "enabled": bool(_proxy["enabled"] and key),
        "configured": bool(key),
        "api_key_masked": masked or None,
        "base_url": _proxy["base_url"],
        "auth_mode": _proxy["auth_mode"],
        "url_style": _proxy.get("url_style") or "path",
        "extras": dict(_proxy.get("extras") or {}),
        "wisp_url": _proxy.get("wisp_url") or "wss://cors.manus.space/wisp/",
        "backend": "corsproxy-manus",
        "note": (
            "Live tools route through corsproxy HTTP CORS when enabled. "
            "Wisp tunnel is available at wisp_url for Bare-Mux/libcurl.js clients (not pure Python)."
            if _proxy["enabled"] and key
            else "Proxy key not configured — call proxy.ensure() or host auto-mint via /api/manus-key."
        ),
    }



def is_proxy_ready() -> bool:
    """True when proxy is enabled and an API key is configured."""
    return bool(_proxy.get("enabled") and _proxy.get("api_key"))


def get_proxy_state() -> dict[str, Any]:
    """Internal snapshot for ensure / diagnostics."""
    return dict(_proxy)

def _header_get(headers: dict[str, str], name: str) -> str | None:
    ln = name.lower()
    for k, v in headers.items():
        if k.lower() == ln:
            return v
    return None



def _build_proxy_request(
    target_url: str,
    method: str,
    headers: dict[str, str],
    body: str | bytes | None,
    extras: dict[str, str] | None = None,
) -> tuple[str, str, dict[str, str], str | None]:
    """
    Build the browser-side request to corsproxy.

    Prefers path form (docs recommended):
      {base}/{urlencoded_target}?apikey=...&method=...
    Falls back to legacy ?url= form if base already contains query or path style disabled.
    """
    base = (_proxy.get("base_url") or DEFAULT_PROXY_BASE).rstrip("/")
    key = _proxy.get("api_key") or ""
    mode = _proxy.get("auth_mode") or "both"
    style = _proxy.get("url_style") or "path"  # "path" | "query"

    method_u = (method or "GET").upper()
    extras = dict(extras or {})
    # merge any global extras from config
    for k, v in (_proxy.get("extras") or {}).items():
        extras.setdefault(k, v)

    # --- query params (auth + method + extras) ---
    q: dict[str, str] = {}
    if mode in ("query", "both") and key:
        q["apikey"] = key
    if method_u not in ("GET", "HEAD"):
        q["method"] = method_u
    # documented optional flags
    for flag in ("render", "extract", "selector", "ttl", "input", "output"):
        if flag in extras and extras[flag] not in (None, ""):
            q[flag] = str(extras[flag])

    # --- headers on the proxy hop (CORS allow-list only) ---
    proxy_headers: dict[str, str] = {}
    if mode in ("header", "both") and key:
        proxy_headers["x-api-key"] = key
        proxy_headers["x-target-url"] = target_url

    auth = _header_get(headers, "Authorization")
    if auth:
        proxy_headers["Authorization"] = auth

    ctype = _header_get(headers, "Content-Type")

    # Drop anything not on allow-list
    proxy_headers = {
        k: v for k, v in proxy_headers.items()
        if k.lower() in _PROXY_ALLOWED_HEADERS
    }

    # --- URL assembly ---
    def _qstr(pairs: dict[str, str]) -> str:
        return "&".join(f"{k}={quote(str(v), safe='')}" for k, v in pairs.items())

    if style == "path":
        # Recommended: /api/proxy/https%3A%2F%2Fexample.com%2Fpath
        # base is expected to be https://cors.manus.space/api/proxy
        encoded_target = quote(target_url, safe="")
        proxy_url = f"{base}/{encoded_target}"
        if q:
            proxy_url += "?" + _qstr(q)
    else:
        # Legacy query form
        q = {"url": target_url, **q}
        sep = "&" if "?" in base else "?"
        proxy_url = base + sep + _qstr(q)

    fetch_method = method_u
    if fetch_method == "HEAD":
        fetch_method = "GET"

    proxy_body = None
    if body is not None and fetch_method not in ("GET", "HEAD"):
        proxy_body = body if isinstance(body, str) else body.decode("utf-8", errors="replace")
        proxy_headers["Content-Type"] = ctype or "application/octet-stream"

    return proxy_url, fetch_method, proxy_headers, proxy_body



async def http_request(
    url: str,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: str | bytes | None = None,
    timeout_ms: int = 8000,
    use_proxy: bool | None = None,
) -> dict[str, Any]:
    t0 = time.perf_counter()
    headers = {str(k): str(v) for k, v in (headers or {}).items()}
    method = (method or "GET").upper()
    via_proxy = False

    # --- Policy enforcement (budget + blocked hosts) ---
    try:
        host = urlparse(url if "://" in url else "https://" + url).hostname or ""
    except Exception:
        host = ""
    if _policy.is_host_blocked(host):
        return _fail(url, f"host '{host}' blocked by policy", t0)
    if not _policy.can_request():
        return _fail(url, f"request budget exceeded ({_policy.status()['requests_used']}/{_policy.status()['max_requests']})", t0)
    if not _policy.consume(1):
        return _fail(url, "request budget exceeded", t0)

    # GOAR host fetch (direct → libcurl/Wisp) — skip Manus unless forced
    if use_proxy is not True:
        try:
            from js import window  # type: ignore
            from pyodide.ffi import to_js  # type: ignore
            from js import Object  # type: ignore

            fn = getattr(window, "__goar_fetch", None)
            if fn is not None:
                js_headers = to_js(headers or {}, dict_converter=Object.fromEntries)
                raw_body = ""
                if body is not None:
                    raw_body = body if isinstance(body, str) else body.decode("utf-8", errors="replace")
                hop = await fn(url, method, js_headers, raw_body, int(timeout_ms))
                status = int(getattr(hop, "status", 0) or 0)
                text = str(getattr(hop, "body", "") or "")
                err = getattr(hop, "error", None)
                hdrs = {}
                try:
                    h = getattr(hop, "headers", None)
                    if h is not None and hasattr(h, "to_py"):
                        hdrs = {str(k): str(v) for k, v in h.to_py().items()}
                except Exception:
                    hdrs = {}
                ms = round((time.perf_counter() - t0) * 1000, 2)
                if status or text or err:
                    return {
                        "ok": 200 <= status < 400,
                        "status": status,
                        "headers": hdrs,
                        "body": text,
                        "url": url,
                        "final_url": url,
                        "error": None if status else (str(err) if err else "empty goar fetch"),
                        "elapsed_ms": ms,
                        "via_proxy": False,
                        "via_goar": True,
                        "transport": "goar-clientFetch",
                    }
        except Exception:
            pass

    proxy_on = bool(_proxy.get("enabled") and _proxy.get("api_key"))
    # Soft bootstrap: if neither libcurl nor proxy is ready, try network.ensure once
    global _auto_ensure_attempted
    try:
        _auto_ensure_attempted
    except NameError:
        _auto_ensure_attempted = False
    if not proxy_on and use_proxy is not False and not _auto_ensure_attempted:
        _auto_ensure_attempted = True
        try:
            from . import network as _net
            # fire-and-forget style: await ensure so first request benefits
            await _net.ensure()
            proxy_on = bool(_proxy.get("enabled") and _proxy.get("api_key"))
        except Exception:
            pass

    if use_proxy is True:
        if not _proxy.get("api_key"):
            return _fail(url, "proxy forced but no api_key configured — call await proxy.ensure() or proxy.generate() / configure_proxy()", t0)
        proxy_on = True
    elif use_proxy is False:
        proxy_on = False

    if "cors.manus.space" in url:
        proxy_on = False

    # Prefer libcurl.js + Wisp when host has loaded it and transport is ready
    try:
        from . import libcurl_bridge as _lcb
        if _lcb.is_ready() and _lcb.status().get("preferred", True):
            result = await _lcb.fetch(
                url,
                method=method,
                headers=headers,
                body=body,
                timeout_ms=timeout_ms,
            )
            # If libcurl path worked (or returned a structured error with via_libcurl), use it
            if result.get("via_libcurl") and (result.get("status") or result.get("error")):
                result.setdefault("transport", "libcurl+wisp")
                return result
    except Exception:
        pass  # fall through to Manus HTTP CORS / pyfetch

    try:
        from pyodide.http import pyfetch  # type: ignore
    except ImportError:
        return _fail(url, "pyfetch unavailable — not running under Pyodide", t0)

    try:
        if proxy_on:
            via_proxy = True
            fetch_url, fetch_method, fetch_headers, fetch_body = _build_proxy_request(
                url, method, headers, body, extras=None
            )
        else:
            fetch_url = url
            fetch_method = method
            fetch_headers = headers
            fetch_body = None
            if body is not None and method not in ("GET", "HEAD"):
                fetch_body = body if isinstance(body, str) else body.decode("utf-8", errors="replace")

        opts: dict[str, Any] = {"method": fetch_method, "headers": fetch_headers}
        if fetch_body is not None and fetch_method not in ("GET", "HEAD"):
            opts["body"] = fetch_body

        import asyncio
        async def _do_fetch():
            r = await pyfetch(fetch_url, **opts)
            body = await r.text()
            return r, body
        try:
            resp, text = await asyncio.wait_for(_do_fetch(), timeout=max(1.0, timeout_ms / 1000.0))
        except asyncio.TimeoutError:
            err = _fail(url, f"timeout after {timeout_ms}ms", t0)
            err["via_proxy"] = via_proxy
            return err
        hdrs = _normalize_headers(resp)
        status = int(resp.status)
        text, status, hdrs = _maybe_unwrap_proxy(text, status, hdrs, via_proxy)

        ms = round((time.perf_counter() - t0) * 1000, 2)
        final = getattr(resp, "url", None) or fetch_url

        if via_proxy and status in (401, 403):
            return {
                "ok": False,
                "status": status,
                "headers": hdrs,
                "body": text,
                "url": url,
                "final_url": str(final),
                "redirected": False,
                "error": f"proxy auth failed ({status}) — check Manus API key",
                "elapsed_ms": ms,
                "via_proxy": True,
            }
        if via_proxy and status == 502:
            return {
                "ok": False,
                "status": 502,
                "headers": hdrs,
                "body": text,
                "url": url,
                "final_url": str(final),
                "redirected": False,
                "error": "proxy upstream failed (502) — target unreachable via Manus proxy",
                "elapsed_ms": ms,
                "via_proxy": True,
            }

        return {
            "ok": 200 <= status < 400,
            "status": status,
            "headers": hdrs,
            "body": text,
            "url": url,
            "final_url": str(final),
            "redirected": str(final) != fetch_url and not via_proxy,
            "error": None,
            "elapsed_ms": ms,
            "via_proxy": via_proxy,
        }
    except Exception as e:  # noqa: BLE001
        msg = f"{type(e).__name__}: {e}"
        # Browser CORS often surfaces as Failed to fetch when proxy returns 403 without ACAO
        if via_proxy and ("Failed to fetch" in msg or "NetworkError" in msg or "AbortError" in msg):
            msg += (
                " (proxy hop blocked — often invalid API key: Manus 403 responses may omit CORS headers; "
                "verify key with curl, or use a valid key)"
            )
        err = _fail(url, msg, t0)
        err["via_proxy"] = via_proxy
        return err


def _maybe_unwrap_proxy(
    text: str,
    status: int,
    headers: dict[str, str],
    via_proxy: bool,
) -> tuple[str, int, dict[str, str]]:
    if not via_proxy or not text:
        return text, status, headers
    try:
        data = json.loads(text)
    except Exception:
        return text, status, headers
    if not isinstance(data, dict):
        return text, status, headers
    if "body" in data and ("status" in data or "statusCode" in data or "status_code" in data):
        st = data.get("status") or data.get("statusCode") or data.get("status_code") or status
        try:
            st = int(st)
        except Exception:
            st = status
        body = data.get("body")
        if body is None:
            body = data.get("data") or data.get("content") or ""
        if not isinstance(body, str):
            body = json.dumps(body)
        uh = data.get("headers") or {}
        if isinstance(uh, dict):
            headers = {str(k).lower(): str(v) for k, v in uh.items()}
        return body, st, headers
    return text, status, headers


def _fail(url: str, error: str, t0: float) -> dict[str, Any]:
    return {
        "ok": False,
        "status": 0,
        "headers": {},
        "body": "",
        "url": url,
        "final_url": url,
        "redirected": False,
        "error": error,
        "elapsed_ms": round((time.perf_counter() - t0) * 1000, 2),
        "via_proxy": False,
    }


def _normalize_headers(resp: Any) -> dict[str, str]:
    hdrs: dict[str, str] = {}
    try:
        raw = resp.headers
        if hasattr(raw, "items"):
            for k, v in raw.items():
                hdrs[str(k).lower()] = str(v)
        elif isinstance(raw, dict):
            hdrs = {str(k).lower(): str(v) for k, v in raw.items()}
    except Exception:
        pass
    return hdrs


async def proxy_test(target: str = "https://example.com/") -> dict[str, Any]:
    st = proxy_status()
    if not st["configured"]:
        return {"ok": False, "error": "no api_key configured", "status": st}
    if not st["enabled"]:
        configure_proxy(enabled=True)
    resp = await http_request(
        target,
        method="GET",
        headers={},
        use_proxy=True,
    )
    return {
        "ok": bool(resp.get("status") and resp.get("status") not in (0, 401, 403) and not resp.get("error")),
        "target": target,
        "status": resp.get("status"),
        "via_proxy": resp.get("via_proxy"),
        "elapsed_ms": resp.get("elapsed_ms"),
        "error": resp.get("error"),
        "body_preview": (resp.get("body") or "")[:200],
        "proxy": proxy_status(),
    }


def join_url(base: str, path: str) -> str:
    return urljoin(base if base.endswith("/") else base + "/", path.lstrip("/"))


def same_scope(url: str, root: str, include_subs: bool = False) -> bool:
    try:
        a, b = urlparse(url), urlparse(root)
        if a.scheme not in ("http", "https"):
            return False
        ah, bh = (a.hostname or "").lower(), (b.hostname or "").lower()
        if include_subs:
            return ah == bh or ah.endswith("." + bh)
        return ah == bh
    except Exception:
        return False


def set_query_param(url: str, name: str, value: str) -> str:
    p = urlparse(url)
    q = list(parse_qsl(p.query, keep_blank_values=True))
    found = False
    out = []
    for k, v in q:
        if k == name and not found:
            out.append((k, value))
            found = True
        else:
            out.append((k, v))
    if not found:
        out.append((name, value))
    return urlunparse(p._replace(query=urlencode(out)))


def get_query_params(url: str) -> list[tuple[str, str]]:
    return parse_qsl(urlparse(url).query, keep_blank_values=True)


def parse_cookie_header(cookie: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for part in (cookie or "").split(";"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        k, _, v = part.partition("=")
        out[k.strip()] = v.strip()
    return out


def dump_cookie_header(cookies: dict[str, str]) -> str:
    return "; ".join(f"{k}={v}" for k, v in cookies.items())


def parse_json_body(body: str) -> Any:
    try:
        return json.loads(body)
    except Exception:
        return None
