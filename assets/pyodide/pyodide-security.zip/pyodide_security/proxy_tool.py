"""
Manus CORS proxy configuration + on-the-fly key generation + ensure bootstrap.

All live tools go through `_http.http_request`. When the proxy is enabled and a
key is present, every request is routed:

  https://cors.manus.space/api/proxy?url=<target>&apikey=<key>

Key generation requires a same-origin host endpoint:
  POST {origin}/api/manus-key  →  { "key": "...", "id": "...", ... }

Wisp is NOT implemented in pure Pyodide (needs a WebSocket binary bridge on the
host). If the host exposes a Wisp gateway, configure base_url / a custom
transport — the extension point is configure(base_url=...).
"""

from __future__ import annotations

from typing import Any

from ._http import (
    configure_proxy,
    disable_proxy,
    http_request,
    proxy_status,
    proxy_test,
    is_proxy_ready,
)

__all__ = [
    "configure",
    "status",
    "disable",
    "test",
    "generate",
    "ensure",
    "is_ready",
]


def configure(
    api_key: str = "",
    enabled: bool = True,
    base_url: str = "https://cors.manus.space/api/proxy",
    auth_mode: str = "both",
    url_style: str = "path",
    extras: dict | None = None,
    wisp_url: str = "wss://cors.manus.space/wisp/",
) -> dict:
    """
    Configure corsproxy backend.

    url_style: "path" (recommended /api/proxy/:targetUrl) or "query" (?url=)
    extras: optional global flags e.g. {"render": "true", "ttl": "60"}
    wisp_url: published for Bare-Mux / libcurl.js clients (not used by pure Python)
    """
    return configure_proxy(
        api_key=api_key,
        enabled=enabled,
        base_url=base_url or "https://cors.manus.space/api/proxy",
        auth_mode=auth_mode or "both",
        url_style=url_style or "path",
        extras=extras,
        wisp_url=wisp_url or "wss://cors.manus.space/wisp/",
    )


def status() -> dict:
    st = proxy_status()
    st["ready"] = is_proxy_ready()
    st["backend"] = "manus-cors"
    st["wisp"] = True  # endpoint exists on corsproxy
    st["wisp_url"] = st.get("wisp_url") or "wss://cors.manus.space/wisp/"
    st["wisp_note"] = (
        "Wisp tunnel is live at wisp_url for Bare-Mux, Epoxy TLS, libcurl.js, and Ultraviolet clients. "
        "Pure Python/Pyodide tools use the HTTP CORS path (/api/proxy/:targetUrl), not the Wisp binary protocol."
    )
    return st


def disable() -> dict:
    return disable_proxy()


def is_ready() -> bool:
    return is_proxy_ready()


async def test(target: str = "https://example.com/") -> dict:
    return await proxy_test(target=target)


async def generate(
    origin: str = "",
    auto_configure: bool = True,
) -> dict[str, Any]:
    """
    Mint a fresh Manus API key via the host app's same-origin /api/manus-key.

    The browser cannot call Manus key-generation cross-origin; the host must
    expose POST /api/manus-key that proxies the Manus tRPC/generate call.
    """
    base = (origin or "").rstrip("/")
    if not base:
        try:
            from js import location  # type: ignore

            base = str(location.origin)
        except Exception:
            base = ""

    if not base:
        return {
            "ok": False,
            "error": "origin required (pass origin= or run under browser Pyodide with location.origin)",
            "hint": "Host app must implement POST /api/manus-key that returns {key: '...'}",
        }

    resp = await http_request(
        f"{base}/api/manus-key",
        method="POST",
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        body="{}",
        use_proxy=False,
    )
    status_code = resp.get("status") or 0
    if status_code >= 400 or not status_code:
        return {
            "ok": False,
            "error": resp.get("error") or f"generate HTTP {status_code}",
            "body": (resp.get("body") or "")[:400],
            "hint": "Ensure host serves POST /api/manus-key and returns JSON {key: '...'}",
        }

    import json

    try:
        data = json.loads(resp.get("body") or "{}")
    except json.JSONDecodeError:
        return {
            "ok": False,
            "error": "non-JSON from /api/manus-key",
            "body": (resp.get("body") or "")[:200],
        }

    key = data.get("key") or data.get("apiKey") or data.get("api_key")
    if not key:
        return {
            "ok": False,
            "error": data.get("error") or "no key in response",
            "raw": data,
        }

    configured = None
    if auto_configure:
        configured = configure_proxy(api_key=str(key), enabled=True, auth_mode="both")

    return {
        "ok": True,
        "id": data.get("id"),
        "key": key,
        "label": data.get("label"),
        "createdAt": data.get("createdAt") or data.get("created_at"),
        "configured": configured,
        "proxy": proxy_status(),
        "backend": "manus-cors",
    }


# Prevent thundering-herd re-mint
_ensure_lock = False
_ensure_result: dict[str, Any] | None = None


async def ensure(
    origin: str = "",
    force: bool = False,
) -> dict[str, Any]:
    """
    Make sure a working proxy key is configured.

    - If already ready → return status immediately
    - Otherwise attempt generate() once and configure
    - Subsequent callers share the result (no repeated mint storms)

    Call this at the start of any workflow that needs reliable external network.
    All engines that use http_request automatically benefit once ensure() succeeds.
    """
    global _ensure_lock, _ensure_result

    if is_proxy_ready() and not force:
        return {
            "ok": True,
            "already_ready": True,
            "proxy": proxy_status(),
            "backend": "manus-cors",
        }

    if _ensure_lock and _ensure_result is not None and not force:
        return _ensure_result

    _ensure_lock = True
    try:
        gen = await generate(origin=origin, auto_configure=True)
        if not gen.get("ok"):
            _ensure_result = {
                "ok": False,
                "error": gen.get("error") or "key generation failed",
                "detail": gen,
                "backend": "manus-cors",
                "hint": (
                    "Host must expose POST /api/manus-key returning {key: '...'}. "
                    "Without a key, live tools can only hit same-origin or CORS-open targets."
                ),
            }
            return _ensure_result

        # Optional connectivity check
        try:
            t = await proxy_test(target="https://example.com/")
            gen["connectivity"] = {
                "ok": bool(t.get("ok")),
                "status": t.get("status"),
                "error": t.get("error"),
            }
        except Exception as e:  # noqa: BLE001
            gen["connectivity"] = {"ok": False, "error": str(e)}

        _ensure_result = {
            "ok": True,
            "already_ready": False,
            "generated": True,
            "proxy": proxy_status(),
            "backend": "manus-cors",
            "connectivity": gen.get("connectivity"),
            "key_id": gen.get("id"),
        }
        return _ensure_result
    finally:
        _ensure_lock = False
