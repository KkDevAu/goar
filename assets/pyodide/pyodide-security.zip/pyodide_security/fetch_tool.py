"""Live fetch helpers — pull remote content then run offline analyzers."""

from __future__ import annotations

from typing import Any

from ._http import http_request
from .headers_tool import analyze as analyze_headers
from .secrets_tool import scan as secrets_scan
from .tech_engine.fingerprint import fingerprint_response
from .yara_engine.rules import scan as yara_scan


async def fetch_analyze(
    url: str,
    method: str = "GET",
    headers: str = "",
    body: str = "",
) -> dict[str, Any]:
    if not url.startswith("http"):
        url = "https://" + url
    hdrs = {"User-Agent": "pyodide-security/fetch"}
    for line in (headers or "").splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            hdrs[k.strip()] = v.strip()
    resp = await http_request(url, method=method.upper(), headers=hdrs, body=body or None)
    rh = resp.get("headers") or {}
    text = resp.get("body") or ""
    return {
        "url": url,
        "status": resp.get("status"),
        "headers": rh,
        "body_length": len(text),
        "body_preview": text[:500],
        "via_proxy": resp.get("via_proxy"),
        "elapsed_ms": resp.get("elapsed_ms"),
        "error": resp.get("error"),
        "security_headers": analyze_headers("\n".join(f"{k}: {v}" for k, v in rh.items())),
        "tech": fingerprint_response(int(resp.get("status") or 0), rh, text),
        "secrets": secrets_scan(text),
        "yara": yara_scan(text),
        "engine": "fetch+analyze",
    }
