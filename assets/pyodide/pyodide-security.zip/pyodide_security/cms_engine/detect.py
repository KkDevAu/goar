"""
CMS detection — 1:1 signature conversion from CMSeeK (cmseekdb).

Sources:
  CMSeeK/cmseekdb/cmss.py     — 192 CMS catalog
  CMSeeK/cmseekdb/header.py   — header detection keys
  CMSeeK/cmseekdb/generator.py
  CMSeeK/cmseekdb/sc.py       — HTML source keys
"""

from __future__ import annotations

import gzip
import json
from pathlib import Path
from typing import Any

from .._http import http_request
from .. import policy

_DB: dict[str, Any] | None = None
_PATH = Path(__file__).with_name("cmseek_db.json.gz")


def _db() -> dict[str, Any]:
    global _DB
    if _DB is None:
        with gzip.open(_PATH, "rt", encoding="utf-8") as f:
            _DB = json.load(f)
    return _DB


def list_cms(limit: int = 0) -> dict[str, Any]:
    cms = _db()["cms"]
    rows = cms[: int(limit)] if limit and limit > 0 else cms
    return {
        "ok": True,
        "count": len(cms),
        "returned": len(rows),
        "cms": rows,
        "source": _db()["source"],
        "engine": "cms",
        "equivalent": "CMSeeK",
    }


def list_rules(where: str = "", limit: int = 0) -> dict[str, Any]:
    rules = _db()["rules"]
    if where:
        rules = [r for r in rules if r.get("where") == where]
    rows = rules[: int(limit)] if limit and limit > 0 else rules
    return {
        "ok": True,
        "count": len(rules),
        "returned": len(rows),
        "rules": rows,
        "engine": "cms",
    }


def _match(body: str, headers: dict[str, str]) -> list[dict[str, Any]]:
    hdr_blob = "\n".join(f"{k}: {v}" for k, v in headers.items())
    hdr_l = hdr_blob.lower()
    body_l = (body or "").lower()
    # generator meta
    gen = ""
    import re
    m = re.search(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)', body or "", re.I)
    if not m:
        m = re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']generator["\']', body or "", re.I)
    if m:
        gen = m.group(1).lower()

    hits: dict[str, dict[str, Any]] = {}
    for r in _db()["rules"]:
        needle = (r.get("needle") or "").lower()
        if not needle:
            continue
        where = r.get("where") or "source"
        matched = False
        if where == "header" and needle in hdr_l:
            matched = True
        elif where == "generator" and needle in gen:
            matched = True
        elif where == "source" and needle in body_l:
            matched = True
        if matched:
            cid = r.get("cms_id") or ""
            if cid not in hits:
                hits[cid] = {
                    "cms_id": cid,
                    "cms": r.get("cms") or cid,
                    "matches": [],
                    "confidence": 0,
                }
            hits[cid]["matches"].append({"needle": r.get("needle"), "where": where})
            hits[cid]["confidence"] = min(100, hits[cid]["confidence"] + (40 if where == "header" else 25))
    ranked = sorted(hits.values(), key=lambda x: -x["confidence"])
    return ranked


async def detect(url: str, user_agent: str = "pyodide-security/cmseek/1.0") -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "cms"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    resp = await http_request(url, headers={"User-Agent": user_agent})
    body = resp.get("body") or ""
    headers = {str(k).lower(): str(v) for k, v in (resp.get("headers") or {}).items()}
    ranked = _match(body, headers)
    return {
        "ok": True,
        "url": url,
        "status": resp.get("status"),
        "detected": bool(ranked),
        "cms": ranked,
        "primary": ranked[0] if ranked else None,
        "rule_db": len(_db()["rules"]),
        "cms_db": len(_db()["cms"]),
        "engine": "cms",
        "source": _db()["source"],
        "equivalent": "CMSeeK",
        "transport": resp.get("transport"),
    }


def detect_offline(headers: str | dict = "", body: str = "") -> dict[str, Any]:
    hdrs: dict[str, str] = {}
    if isinstance(headers, dict):
        hdrs = {str(k).lower(): str(v) for k, v in headers.items()}
    elif isinstance(headers, str):
        for line in headers.splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                hdrs[k.strip().lower()] = v.strip()
    ranked = _match(body or "", hdrs)
    return {
        "ok": True,
        "detected": bool(ranked),
        "cms": ranked,
        "primary": ranked[0] if ranked else None,
        "rule_db": len(_db()["rules"]),
        "engine": "cms",
        "mode": "offline",
    }
