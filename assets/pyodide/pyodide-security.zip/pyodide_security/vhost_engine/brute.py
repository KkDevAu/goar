"""
Virtual host brute — SecLists namelist conversion.
"""

from __future__ import annotations

import gzip
from pathlib import Path
from typing import Any

from .._http import http_request
from .. import policy

_PATH = Path(__file__).with_name("data") / "vhosts.txt.gz"
_WORDS: list[str] | None = None


def _words() -> list[str]:
    global _WORDS
    if _WORDS is None:
        with gzip.open(_PATH, "rt", encoding="utf-8") as f:
            _WORDS = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
    return _WORDS


def list_wordlist(limit: int = 0) -> dict[str, Any]:
    rows = _words()
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {
        "ok": True,
        "count": len(rows),
        "returned": len(out),
        "words": out,
        "source": "SecLists/Discovery/DNS/namelist.txt (top 8k)",
        "engine": "vhost",
    }


async def brute(
    url: str,
    max_hosts: int = 40,
    user_agent: str = "pyodide-security/vhost/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "vhost"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    from urllib.parse import urlparse
    p = urlparse(url)
    base_host = p.hostname or ""
    words = _words()[: max(1, int(max_hosts))]
    # baseline
    base = await http_request(url, headers={"User-Agent": user_agent, "Host": base_host})
    base_len = len(base.get("body") or "")
    base_st = base.get("status")

    found = []
    tested = 0
    for w in words:
        if not policy.can_request():
            break
        tested += 1
        # host header injection style
        host = f"{w}.{base_host}" if base_host else w
        resp = await http_request(url, headers={"User-Agent": user_agent, "Host": host})
        st = resp.get("status") or 0
        bl = len(resp.get("body") or "")
        if st != base_st or abs(bl - base_len) > max(50, int(base_len * 0.15)):
            found.append({"host": host, "status": st, "length": bl, "delta": bl - base_len})
    return {
        "ok": True,
        "url": url,
        "base_host": base_host,
        "tested": tested,
        "found": found,
        "found_count": len(found),
        "wordlist_size": len(_words()),
        "engine": "vhost",
        "source": "SecLists namelist",
    }
