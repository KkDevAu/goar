"""Security header audit — OWASP secure headers baseline."""
from __future__ import annotations
from typing import Any
from .._http import http_request
from .. import policy

REQUIRED=[
    ("strict-transport-security","HSTS","high"),
    ("content-security-policy","CSP","medium"),
    ("x-content-type-options","X-Content-Type-Options","medium"),
    ("x-frame-options","X-Frame-Options","medium"),
    ("referrer-policy","Referrer-Policy","low"),
    ("permissions-policy","Permissions-Policy","low"),
    ("cross-origin-opener-policy","COOP","low"),
    ("cross-origin-resource-policy","CORP","low"),
]

async def fuzz(url: str, user_agent: str="pyodide-security/headers/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"headerfuzz"}
    if not url.startswith(("http://","https://")): url="https://"+url
    resp=await http_request(url, headers={"User-Agent":user_agent})
    hdrs={str(k).lower():str(v) for k,v in (resp.get("headers") or {}).items()}
    present=[]; missing=[]; issues=[]
    for key,label,sev in REQUIRED:
        if key in hdrs:
            present.append({"header":label,"value":hdrs[key][:120]})
        else:
            missing.append({"header":label,"severity":sev})
            issues.append({"issue":f"missing {label}","severity":sev})
    # dangerous
    if "server" in hdrs:
        issues.append({"issue":f"Server header discloses: {hdrs['server'][:80]}","severity":"info"})
    if "x-powered-by" in hdrs:
        issues.append({"issue":f"X-Powered-By: {hdrs['x-powered-by'][:80]}","severity":"info"})
    return {"ok":True,"url":url,"status":resp.get("status"),"present":present,"missing":missing,
            "issues":issues,"issue_count":len(issues),"engine":"headerfuzz","equivalent":"OWASP secure headers"}
