"""HTML form extractor — action, method, inputs."""
from __future__ import annotations
import re
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin
from .._http import http_request
from .. import policy

class _FormParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.forms=[]; self._cur=None
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag=="form":
            self._cur={"action":a.get("action",""),"method":(a.get("method") or "GET").upper(),"inputs":[]}
        elif tag in ("input","textarea","select") and self._cur is not None:
            self._cur["inputs"].append({"tag":tag,"type":a.get("type","text"),"name":a.get("name"),"id":a.get("id"),"value":a.get("value")})
    def handle_endtag(self, tag):
        if tag=="form" and self._cur is not None:
            self.forms.append(self._cur); self._cur=None

def extract_html(html: str, base_url: str="")->list[dict[str,Any]]:
    p=_FormParser()
    try: p.feed(html or "")
    except Exception: pass
    out=[]
    for f in p.forms:
        action=f["action"]
        if base_url: action=urljoin(base_url, action)
        out.append({**f,"action":action})
    return out

async def extract(url: str, user_agent: str="pyodide-security/form/2.0")->dict[str,Any]:
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"form"}
    if not url.startswith(("http://","https://")): url="https://"+url
    resp=await http_request(url, headers={"User-Agent":user_agent})
    forms=extract_html(resp.get("body") or "", url)
    return {"ok":True,"url":url,"status":resp.get("status"),"forms":forms,"count":len(forms),"engine":"form"}


async def scan_url(url: str, **kw):
    return await extract(url, **kw)
