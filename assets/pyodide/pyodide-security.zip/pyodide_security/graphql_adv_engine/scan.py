"""Advanced GraphQL — field suggestions, circular query, batching abuse."""
from __future__ import annotations
import json
from typing import Any
from ..graphql_engine.scan import scan as base_scan, _gql_request, INTROSPECTION_QUERY
from .. import policy

SUGGEST=["user","users","admin","viewer","node","nodes","search","me","account","accounts","password","token","secret"]

async def scan(url: str, method: str="POST", user_agent: str="pyodide-security/graphql-adv/2.0")->dict[str,Any]:
    base=await base_scan(url, method=method, user_agent=user_agent)
    headers={"User-Agent":user_agent,"Accept":"application/json","Content-Type":"application/json"}
    extra=[]
    # suggestion probes
    for field in SUGGEST:
        if not policy.can_request(): break
        q="{"+field+"{__typename}}"
        resp=await _gql_request(url, q, headers, method=method)
        try: data=json.loads(resp.get("body") or "")
        except Exception: data=None
        if isinstance(data,dict) and data.get("data") and data["data"].get(field) is not None:
            extra.append({"field":field,"status":resp.get("status"),"hit":True})
    base["field_suggestions"]=extra
    base["engine"]="graphql_adv"
    base["equivalent"]="GraphQLmap advanced"
    return base


async def attack(url: str, **kw):
    return await scan(url, **kw)
