"""
GraphQL attack suite — graphql-cop / InQL / BatchQL class.

Attacks:
  - Introspection (full / filtered)
  - Field suggestions abuse
  - Batch queries
  - Alias overload
  - GET-based GraphQL
  - Directive overloading
  - Circular fragment probes
  - Common sensitive field enumeration
"""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlencode

from .._http import http_request
from .. import policy

_INTROSPECTION = """
query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types {
      ...FullType
    }
    directives {
      name
      description
      locations
      args { ...InputValue }
    }
  }
}
fragment FullType on __Type {
  kind
  name
  description
  fields(includeDeprecated: true) {
    name
    description
    args { ...InputValue }
    type { ...TypeRef }
    isDeprecated
    deprecationReason
  }
  inputFields { ...InputValue }
  interfaces { ...TypeRef }
  enumValues(includeDeprecated: true) {
    name
    description
    isDeprecated
    deprecationReason
  }
  possibleTypes { ...TypeRef }
}
fragment InputValue on __InputValue {
  name
  description
  type { ...TypeRef }
  defaultValue
}
fragment TypeRef on __Type {
  kind
  name
  ofType {
    kind
    name
    ofType {
      kind
      name
      ofType {
        kind
        name
        ofType {
          kind
          name
          ofType {
            kind
            name
            ofType {
              kind
              name
              ofType { kind name }
            }
          }
        }
      }
    }
  }
}
"""

_SIMPLE_INTRO = '{ __schema { queryType { name } mutationType { name } types { name kind } } }'

_SENSITIVE_FIELDS = [
    "users", "user", "allUsers", "getUser", "password", "passwd", "secret",
    "token", "apiKey", "api_key", "private", "admin", "config", "settings",
    "email", "ssn", "creditCard", "credit_card", "internal",
]


def _gql_request_body(query: str, variables: dict | None = None, op_name: str | None = None) -> str:
    payload: dict[str, Any] = {"query": query}
    if variables:
        payload["variables"] = variables
    if op_name:
        payload["operationName"] = op_name
    return json.dumps(payload)


async def _post(
    url: str,
    query: str,
    headers: dict[str, str],
    variables: dict | None = None,
) -> dict[str, Any]:
    body = _gql_request_body(query, variables)
    hdrs = {**headers, "Content-Type": "application/json"}
    return await http_request(url, method="POST", headers=hdrs, body=body)


async def _get(url: str, query: str, headers: dict[str, str]) -> dict[str, Any]:
    sep = "&" if "?" in url else "?"
    target = url + sep + urlencode({"query": query})
    return await http_request(target, headers=headers)


async def attack(
    url: str,
    tests: str = "introspect,batch,alias,get,suggest,sensitive",
    max_aliases: int = 50,
    user_agent: str = "pyodide-security/graphql-adv/2.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "graphql_adv"}

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    headers = {"User-Agent": user_agent}
    want = {t.strip().lower() for t in tests.split(",") if t.strip()}
    findings: list[dict[str, Any]] = []
    results: dict[str, Any] = {}

    # --- introspection ---
    if "introspect" in want and policy.can_request():
        resp = await _post(url, _SIMPLE_INTRO, headers)
        body = resp.get("body") or ""
        status = int(resp.get("status") or 0)
        enabled = False
        schema_summary = None
        try:
            data = json.loads(body)
            if data.get("data", {}).get("__schema"):
                enabled = True
                schema = data["data"]["__schema"]
                types = schema.get("types") or []
                schema_summary = {
                    "queryType": (schema.get("queryType") or {}).get("name"),
                    "mutationType": (schema.get("mutationType") or {}).get("name"),
                    "type_count": len(types),
                    "type_names": [t.get("name") for t in types if t.get("name") and not str(t.get("name", "")).startswith("__")][:40],
                }
                findings.append({
                    "id": "introspection-enabled",
                    "severity": "high",
                    "message": f"Introspection enabled — {schema_summary['type_count']} types visible",
                })
        except Exception:
            if "__schema" in body or "queryType" in body:
                enabled = True
                findings.append({
                    "id": "introspection-enabled",
                    "severity": "high",
                    "message": "Introspection appears enabled (non-JSON parse)",
                })
        results["introspection"] = {
            "enabled": enabled,
            "status": status,
            "schema": schema_summary,
            "error": resp.get("error"),
        }

        # full introspection if simple worked
        if enabled and policy.can_request():
            full = await _post(url, _INTROSPECTION, headers)
            results["introspection"]["full_status"] = full.get("status")
            results["introspection"]["full_body_len"] = len(full.get("body") or "")

    # --- field suggestion ---
    if "suggest" in want and policy.can_request():
        resp = await _post(url, "{ psec_nonexistent_field_xyz }", headers)
        body = (resp.get("body") or "").lower()
        suggests = "did you mean" in body or "suggestion" in body
        if suggests:
            findings.append({
                "id": "field-suggestions",
                "severity": "medium",
                "message": "Server returns field suggestions — aids enumeration",
            })
        results["suggestions"] = {"enabled": suggests, "status": resp.get("status"), "preview": (resp.get("body") or "")[:300]}

    # --- batch queries ---
    if "batch" in want and policy.can_request():
        batch = [
            {"query": "{ __typename }"},
            {"query": "{ __typename }"},
            {"query": "{ __typename }"},
        ]
        resp = await http_request(
            url,
            method="POST",
            headers={**headers, "Content-Type": "application/json"},
            body=json.dumps(batch),
        )
        body = resp.get("body") or ""
        batch_ok = False
        try:
            data = json.loads(body)
            if isinstance(data, list) and len(data) >= 2:
                batch_ok = True
                findings.append({
                    "id": "batch-enabled",
                    "severity": "medium",
                    "message": f"Batch queries accepted ({len(data)} responses)",
                })
        except Exception:
            pass
        results["batch"] = {"enabled": batch_ok, "status": resp.get("status"), "preview": body[:300]}

    # --- alias overload ---
    if "alias" in want and policy.can_request():
        n = max(5, min(int(max_aliases), 200))
        aliases = " ".join(f"a{i}: __typename" for i in range(n))
        query = "{ " + aliases + " }"
        resp = await _post(url, query, headers)
        body = resp.get("body") or ""
        alias_ok = False
        try:
            data = json.loads(body)
            if data.get("data") and len(data["data"]) >= min(5, n):
                alias_ok = True
                findings.append({
                    "id": "alias-amplification",
                    "severity": "medium",
                    "message": f"Accepted {len(data['data'])} aliases — potential DoS amplification",
                })
        except Exception:
            if body.count("__typename") >= 3 or body.count("Query") >= 3:
                alias_ok = True
        results["alias"] = {"enabled": alias_ok, "requested": n, "status": resp.get("status"), "body_len": len(body)}

    # --- GET method ---
    if "get" in want and policy.can_request():
        resp = await _get(url, "{ __typename }", headers)
        body = resp.get("body") or ""
        get_ok = False
        try:
            data = json.loads(body)
            if data.get("data") or data.get("errors"):
                get_ok = True
                findings.append({
                    "id": "get-method",
                    "severity": "low",
                    "message": "GraphQL over GET works — CSRF risk if mutations allowed",
                })
        except Exception:
            if "__typename" in body or "errors" in body:
                get_ok = True
        results["get"] = {"enabled": get_ok, "status": resp.get("status"), "preview": body[:300]}

    # --- sensitive field names (cheap enum when introspection blocked) ---
    if "sensitive" in want:
        hits = []
        for field in _SENSITIVE_FIELDS:
            if not policy.can_request():
                break
            resp = await _post(url, "{ " + field + " { __typename } }", headers)
            body = (resp.get("body") or "").lower()
            # field exists if not "cannot query field" / "unknown field"
            unknown = any(x in body for x in ("cannot query field", "unknown field", "does not exist", "undefined field"))
            if not unknown and int(resp.get("status") or 0) in (200, 400):
                # 400 with different message may still mean field exists but needs args
                if "must have a selection" in body or "requires" in body or "data" in body:
                    hits.append(field)
                    findings.append({
                        "id": f"field-{field}",
                        "severity": "medium",
                        "message": f"Sensitive field name appears present: {field}",
                    })
        results["sensitive_fields"] = hits

    sev_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    findings.sort(key=lambda x: sev_rank.get(x.get("severity", "info"), 9))

    return {
        "ok": True,
        "url": url,
        "findings": findings,
        "results": results,
        "finding_count": len(findings),
        "engine": "graphql_adv",
        "version": "2.0",
        "equivalent": "graphql-cop / InQL / BatchQL",
        "policy": policy.status(),
    }
