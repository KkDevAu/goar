"""
WAF detection — 1:1 conversion of EnableSecurity/wafw00f.

Loads real plugin modules from plugins/*.py and calls is_waf(self) with
matchHeader / matchCookie / matchContent / matchStatus / matchReason
implemented exactly as wafw00f/main.py.
"""
from __future__ import annotations

import importlib.util
import re
from pathlib import Path
from typing import Any

from .._http import http_request
from .. import policy

_PLUGIN_DIR = Path(__file__).resolve().parent / "plugins"

# Attack strings from wafw00f.main.WAFW00F
_XSS = r'<script>alert("XSS");</script>'
_SQLI = r'UNION SELECT ALL FROM information_schema AND " or SLEEP(5) or "'
_LFI = r'../../etc/passwd'
_RCE = r'/bin/cat /etc/passwd; ping 127.0.0.1; curl google.com'
_XXE = r'<!ENTITY xxe SYSTEM "file:///etc/shadow">]><pwn>&hack;</pwn>'


class _RespObj:
    """Minimal requests.Response-like object for plugin matchers."""

    def __init__(self, status: int, headers: dict, body: str, reason: str = ""):
        self.status_code = int(status or 0)
        # preserve original header names but also allow case-insensitive get
        self.headers = _CIHeaders(headers or {})
        self.text = body or ""
        self.reason = reason or ""
        self.content = (body or "").encode("utf-8", errors="replace")


class _CIHeaders(dict):
    def get(self, key, default=None):
        if key in self:
            return super().get(key, default)
        lk = str(key).lower()
        for k, v in self.items():
            if str(k).lower() == lk:
                return v
        return default


def _load_plugins() -> dict[str, Any]:
    """Port of wafw00f.manager.load_plugins"""
    plugin_dict = {}
    if not _PLUGIN_DIR.is_dir():
        return plugin_dict
    for path in sorted(_PLUGIN_DIR.glob("*.py")):
        if path.name == "__init__.py":
            continue
        name = path.stem
        spec = importlib.util.spec_from_file_location(f"waf_plugins.{name}", path)
        if not spec or not spec.loader:
            continue
        mod = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(mod)
        except Exception:
            continue
        if hasattr(mod, "NAME") and hasattr(mod, "is_waf"):
            plugin_dict[name] = mod
    return plugin_dict


class WAFW00F:
    """Port of wafw00f.main.WAFW00F matcher + identwaf surface."""

    def __init__(self):
        self.rq: _RespObj | None = None
        self.attackres: _RespObj | None = None
        plugins = _load_plugins()
        self.wafdetections: dict[str, Any] = {}
        for mod in plugins.values():
            self.wafdetections[mod.NAME] = mod.is_waf
        # priority list if available
        try:
            from .wafprio import wafdetectionsprio
            checklist = list(wafdetectionsprio)
            checklist += list(set(self.wafdetections.keys()) - set(checklist))
        except Exception:
            checklist = list(self.wafdetections.keys())
        self.checklist = checklist
        self.plugin_count = len(self.wafdetections)

    def matchHeader(self, headermatch, attack=False):
        r = self.attackres if attack else self.rq
        if r is None:
            return False
        header, match = headermatch
        headerval = r.headers.get(header)
        if headerval:
            if header.lower() == "set-cookie":
                headervals = headerval.split(", ")
            else:
                headervals = [headerval]
            for hv in headervals:
                if re.search(match, hv, re.I):
                    return True
        return False

    def matchStatus(self, statuscode, attack=True):
        r = self.attackres if attack else self.rq
        if r is None:
            return False
        return r.status_code == statuscode

    def matchCookie(self, match, attack=False):
        return self.matchHeader(("Set-Cookie", match), attack=attack)

    def matchReason(self, reasoncode, attack=True):
        r = self.attackres if attack else self.rq
        if r is None:
            return False
        return str(r.reason) == reasoncode

    def matchContent(self, regex, attack=True):
        r = self.attackres if attack else self.rq
        if r is None:
            return False
        return bool(re.search(regex, r.text, re.I))

    async def _fetch(self, url: str, headers: dict | None = None, path_q: str = "") -> _RespObj:
        target = url
        if path_q:
            sep = "&" if "?" in url else "?"
            # path_q may be full query or path
            if path_q.startswith("?"):
                target = url.rstrip("/") + path_q
            elif path_q.startswith("/"):
                target = url.rstrip("/") + path_q
            else:
                target = url + sep + path_q
        resp = await http_request(target, headers=headers or {})
        return _RespObj(
            status=int(resp.get("status") or 0),
            headers=resp.get("headers") or {},
            body=resp.get("body") or "",
        )


async def detect(
    url: str,
    findall: bool = True,
    active: bool = True,
    user_agent: str = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:130.0) Gecko/20100101 Firefox/130.0",
) -> dict[str, Any]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    eng = WAFW00F()
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "User-Agent": user_agent,
        "Accept-Language": "en-US,en;q=0.5",
    }

    eng.rq = await eng._fetch(url, headers=headers)

    # central attack response (wafw00f performs centralAttack first for attackres)
    if active and policy.check_url_for_active(url) is None and policy.can_request():
        # centralAttack combines several vectors in query
        q = f"a={_XSS}&b={_SQLI}&c={_LFI}"
        eng.attackres = await eng._fetch(url, headers=headers, path_q=q)
    else:
        eng.attackres = eng.rq

    detected: list[dict[str, Any]] = []
    for wafvendor in eng.checklist:
        fn = eng.wafdetections.get(wafvendor)
        if not fn:
            continue
        try:
            if fn(eng):
                detected.append({"name": wafvendor, "matched": True})
                if not findall:
                    break
        except Exception as e:
            continue

    # generic behavioral signals
    generic = []
    if eng.rq and eng.attackres and eng.rq.status_code != eng.attackres.status_code:
        generic.append(
            f"Status differs normal vs attack: {eng.rq.status_code} → {eng.attackres.status_code}"
        )

    return {
        "ok": True,
        "url": url,
        "detected": bool(detected),
        "wafs": detected,
        "primary": detected[0] if detected else None,
        "match_count": len(detected),
        "generic_waf_signals": generic,
        "generic_detected": bool(generic),
        "baseline_status": eng.rq.status_code if eng.rq else 0,
        "server": (eng.rq.headers.get("Server") if eng.rq else None),
        "plugin_count": eng.plugin_count,
        "engine": "waf",
        "version": "4.0-wafw00f-1to1",
        "equivalent": "EnableSecurity/wafw00f",
        "source": "https://github.com/EnableSecurity/wafw00f",
        "note": "Executes real plugin is_waf() functions with 1:1 matchHeader/Content/Cookie/Status",
        "policy": policy.status(),
    }


def list_signatures() -> dict[str, Any]:
    eng = WAFW00F()
    return {
        "total": eng.plugin_count,
        "wafs": list(eng.wafdetections.keys()),
        "source": "EnableSecurity/wafw00f plugins/*.py (bundled)",
        "equivalent": "wafw00f",
    }
