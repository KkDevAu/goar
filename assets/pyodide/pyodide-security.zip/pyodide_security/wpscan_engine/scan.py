"""
WordPress scanner — WPScan-class with SecLists plugin/theme DBs.
"""
from __future__ import annotations

import gzip
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .._http import http_request
from .. import policy

_ROOT = Path(__file__).resolve().parent
_PATHS = _ROOT / "interesting_paths.txt"


def _load_gz_lines(name: str) -> list[str]:
    p = _ROOT / name
    if not p.exists():
        return []
    with gzip.open(p, "rt", encoding="utf-8") as f:
        return [ln.strip() for ln in f.read().splitlines() if ln.strip()]


def list_paths(limit: int = 0) -> dict[str, Any]:
    rows = [ln.strip() for ln in _PATHS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {"ok": True, "count": len(rows), "returned": len(out), "paths": out,
            "source": "WPScan interesting + SecLists", "engine": "wpscan"}


def list_plugins(limit: int = 0) -> dict[str, Any]:
    rows = _load_gz_lines("plugins.txt.gz")
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {"ok": True, "count": len(rows), "returned": len(out), "plugins": out,
            "source": "SecLists wp-plugins.fuzz.txt", "engine": "wpscan"}


def list_themes(limit: int = 0) -> dict[str, Any]:
    rows = _load_gz_lines("themes.txt.gz")
    out = rows[: int(limit)] if limit and limit > 0 else rows
    return {"ok": True, "count": len(rows), "returned": len(out), "themes": out,
            "source": "SecLists wp-themes.fuzz.txt", "engine": "wpscan"}


async def scan(
    url: str,
    max_paths: int = 12,
    max_plugins: int = 8,
    max_themes: int = 4,
    user_agent: str = "pyodide-security/wpscan/3.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "wpscan"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if not url.endswith("/"):
        url += "/"

    headers = {"User-Agent": user_agent}
    findings = []
    tested = 0
    is_wp = False

    base = await http_request(url, headers=headers)
    body = base.get("body") or ""
    if any(x in body.lower() for x in ("wp-content", "wp-includes", "wordpress")):
        is_wp = True
        findings.append({"type": "fingerprint", "evidence": "wp markers in body", "severity": "info"})

    paths = [ln.strip() for ln in _PATHS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    if max_paths and max_paths > 0:
        paths = paths[: int(max_paths)]

    for path in paths:
        if not policy.can_request():
            break
        tested += 1
        target = urljoin(url, path.lstrip("/"))
        resp = await http_request(target, headers=headers)
        st = resp.get("status") or 0
        if st in (200, 301, 302, 401, 403):
            entry = {"path": path, "url": target, "status": st, "length": len(resp.get("body") or "")}
            b = (resp.get("body") or "").lower()
            if "xmlrpc" in path and st == 200:
                entry["tag"] = "xmlrpc"; is_wp = True
            if "wp-json" in path and st == 200:
                entry["tag"] = "rest"; is_wp = True
            if path.endswith("readme.txt") and "stable tag" in b:
                entry["tag"] = "plugin-readme"; is_wp = True
            findings.append(entry)

    # plugin enumeration via readme.txt
    plugins = _load_gz_lines("plugins.txt.gz")[: max(0, int(max_plugins))]
    plugins_found = []
    for slug in plugins:
        if not policy.can_request():
            break
        tested += 1
        readme = urljoin(url, f"wp-content/plugins/{slug}/readme.txt")
        resp = await http_request(readme, headers=headers)
        if resp.get("status") == 200 and "stable tag" in (resp.get("body") or "").lower():
            is_wp = True
            # version
            ver = None
            for line in (resp.get("body") or "").splitlines():
                if line.lower().startswith("stable tag:"):
                    ver = line.split(":", 1)[1].strip()
                    break
            plugins_found.append({"slug": slug, "version": ver, "url": readme})
            findings.append({"type": "plugin", "slug": slug, "version": ver, "status": 200})

    themes = _load_gz_lines("themes.txt.gz")[: max(0, int(max_themes))]
    themes_found = []
    for slug in themes:
        if not policy.can_request():
            break
        tested += 1
        css = urljoin(url, f"wp-content/themes/{slug}/style.css")
        resp = await http_request(css, headers=headers)
        if resp.get("status") == 200 and "theme name" in (resp.get("body") or "").lower():
            is_wp = True
            name = None
            for line in (resp.get("body") or "").splitlines():
                if line.lower().startswith("theme name:"):
                    name = line.split(":", 1)[1].strip()
                    break
            themes_found.append({"slug": slug, "name": name, "url": css})
            findings.append({"type": "theme", "slug": slug, "name": name, "status": 200})

    return {
        "ok": True,
        "url": url,
        "is_wordpress": is_wp,
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "plugins_found": plugins_found,
        "themes_found": themes_found,
        "plugin_db": len(_load_gz_lines("plugins.txt.gz")),
        "theme_db": len(_load_gz_lines("themes.txt.gz")),
        "engine": "wpscan",
        "equivalent": "WPScan",
        "source": "WPScan paths + SecLists plugins/themes",
    }
