"""
Nikto web server scanner — converted from sullo/nikto.

Source: https://github.com/sullo/nikto
Ports:
  - program/databases/db_tests (7240 tests)
  - program/databases/db_variables (URI macros @CGIDIRS etc.)
Match types: BODY:regex, CODE:status, and combinations with &&
"""
from __future__ import annotations

import gzip
import json
import random
import re
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

from .._http import http_request
from .. import policy

_DATA = Path(__file__).resolve().parent / "data" / "nikto.json.gz"


@lru_cache(maxsize=1)
def _load() -> dict:
    return json.loads(gzip.decompress(_DATA.read_bytes()))


def _expand_uri(uri: str, variables: dict) -> list[str]:
    """Expand @VAR macros into concrete URIs."""
    if "@" not in uri:
        return [uri]
    results = [uri]
    # iteratively expand known vars
    for var, values in variables.items():
        next_results = []
        for u in results:
            if var in u:
                for v in values[:8]:  # cap expansion
                    next_results.append(u.replace(var, v))
            else:
                next_results.append(u)
        results = next_results
        if len(results) > 20:
            results = results[:20]
            break
    return results


def _match_response(match_rule: str, status: int, body: str) -> bool:
    """Evaluate nikto match field: BODY:..., CODE:..., && combinations."""
    if not match_rule:
        return status == 200
    parts = match_rule.split("&&")
    for part in parts:
        part = part.strip()
        if part.startswith("BODY:"):
            pat = part[5:]
            try:
                if not re.search(pat, body or "", re.I | re.S):
                    return False
            except re.error:
                if pat.lower() not in (body or "").lower():
                    return False
        elif part.startswith("CODE:"):
            try:
                want = int(part[5:].strip())
            except ValueError:
                return False
            if status != want:
                return False
        else:
            # bare pattern
            try:
                if not re.search(part, body or "", re.I):
                    return False
            except re.error:
                if part.lower() not in (body or "").lower():
                    return False
    return True


def list_tests(limit: int = 20, tuning: str = "") -> dict[str, Any]:
    data = _load()
    tests = data["tests"]
    if tuning:
        tests = [t for t in tests if tuning in str(t.get("tuning", ""))]
    return {
        "total": len(data["tests"]),
        "variables": len(data["variables"]),
        "sample": tests[: max(1, min(int(limit), 50))],
        "source": "sullo/nikto program/databases/db_tests",
    }


async def scan(
    url: str,
    max_tests: int = 80,
    tuning: str = "",
    user_agent: str = "Mozilla/5.0 (Nikto/pyodide-security)",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url)
    if err:
        return {"ok": False, "error": err, "engine": "nikto"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    base = url.rstrip("/") + "/"
    headers = {"User-Agent": user_agent}
    data = _load()
    variables = data["variables"]
    tests = data["tests"]
    if tuning:
        tests = [t for t in tests if tuning in str(t.get("tuning", ""))]
    # shuffle sample for coverage diversity when max_tests < total
    if int(max_tests) < len(tests):
        # prioritize tests with CVEs first
        cve_tests = [t for t in tests if t.get("cve")]
        other = [t for t in tests if not t.get("cve")]
        random.shuffle(other)
        tests = (cve_tests + other)[: max(1, min(int(max_tests), 500))]
    else:
        tests = tests[: max(1, min(int(max_tests), 500))]

    findings = []
    tested = 0
    for t in tests:
        if not policy.can_request():
            break
        uris = _expand_uri(t["uri"], variables)
        for uri in uris[:3]:
            if not policy.can_request():
                break
            target = urljoin(base, uri.lstrip("/"))
            method = (t.get("method") or "GET").upper()
            resp = await http_request(target, method=method, headers=headers)
            tested += 1
            status = int(resp.get("status") or 0)
            body = resp.get("body") or ""
            if _match_response(t.get("match") or "", status, body):
                findings.append({
                    "id": t["id"],
                    "cve": t.get("cve") or "",
                    "uri": uri,
                    "url": target,
                    "status": status,
                    "description": t.get("description") or "",
                    "match": t.get("match") or "",
                })
                break  # one hit per test id

    return {
        "ok": True,
        "url": url,
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "db_tests": len(data["tests"]),
        "engine": "nikto",
        "version": "3.0-nikto",
        "equivalent": "sullo/nikto",
        "source": "https://github.com/sullo/nikto",
        "policy": policy.status(),
    }
