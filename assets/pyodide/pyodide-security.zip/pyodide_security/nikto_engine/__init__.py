from .scan import list_tests, scan
list_checks = list_tests
__all__ = ["scan", "list_tests", "list_checks"]
