"""
GraphQL engine — GraphQLmap-class conversion (swisskyrepo/GraphQLmap).

Implements:
  - Introspection (schema dump)
  - Field/type enumeration
  - Common injection / batch / depth probes
  - Authorization bypass field guesses
"""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlparse

from .._http import http_request
from .. import policy

# Full introspection query (GraphQL >14 style from GraphQLmap dump_schema)
INTROSPECTION_QUERY = """
query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types {
      ...FullType
    }
    directives {
      name
      description
      locations
      args { ...InputValue }
    }
  }
}
fragment FullType on __Type {
  kind
  name
  description
  fields(includeDeprecated: true) {
    name
    description
    args { ...InputValue }
    type { ...TypeRef }
    isDeprecated
    deprecationReason
  }
  inputFields { ...InputValue }
  interfaces { ...TypeRef }
  enumValues(includeDeprecated: true) {
    name
    description
    isDeprecated
    deprecationReason
  }
  possibleTypes { ...TypeRef }
}
fragment InputValue on __InputValue {
  name
  description
  type { ...TypeRef }
  defaultValue
}
fragment TypeRef on __Type {
  kind
  name
  ofType {
    kind
    name
    ofType {
      kind
      name
      ofType {
        kind
        name
        ofType {
          kind
          name
          ofType {
            kind
            name
            ofType {
              kind
              name
              ofType { kind name }
            }
          }
        }
      }
    }
  }
}
""".strip()

SIMPLE_TYPES = "{__schema{types{name}}}"
SIMPLE_QUERY_TYPE = "{__schema{queryType{name}}}"

# GraphQLmap-style / community injection & abuse probes
PROBES = [
    {"id": "introspection", "query": INTROSPECTION_QUERY, "tag": "introspection"},
    {"id": "types", "query": SIMPLE_TYPES, "tag": "introspection"},
    {"id": "queryType", "query": SIMPLE_QUERY_TYPE, "tag": "introspection"},
    {"id": "directive-skip", "query": '{__type(name:"Query"){name}}', "tag": "meta"},
    {"id": "batch-dup", "query": "[{__typename},{__typename}]", "tag": "batch", "raw": True},
    {"id": "suggest-users", "query": "{users{id email password}}", "tag": "enum"},
    {"id": "suggest-user", "query": "{user(id:1){id email password token}}", "tag": "enum"},
    {"id": "suggest-me", "query": "{me{id email role admin}}", "tag": "enum"},
    {"id": "suggest-allUsers", "query": "{allUsers{id email}}", "tag": "enum"},
    {"id": "suggest-nodes", "query": "{nodes(ids:[\"1\"]){id}}", "tag": "enum"},
    {"id": "depth-bomb", "query": "{__schema{types{fields{type{fields{type{name}}}}}}}", "tag": "dos"},
]


def list_probes() -> dict[str, Any]:
    return {
        "ok": True,
        "count": len(PROBES),
        "probes": [{"id": p["id"], "tag": p["tag"]} for p in PROBES],
        "source": "swisskyrepo/GraphQLmap + introspection standard",
        "engine": "graphql",
        "equivalent": "GraphQLmap",
    }


async def _gql_request(url: str, query: str, headers: dict, method: str = "POST", raw: bool = False) -> dict[str, Any]:
    h = dict(headers)
    if method.upper() == "POST":
        h.setdefault("Content-Type", "application/json")
        if raw:
            body = query  # already JSON array string
        else:
            body = json.dumps({"query": query})
        return await http_request(url, method="POST", headers=h, body=body)
    # GET
    from urllib.parse import urlencode, urlparse, urlunparse
    p = urlparse(url)
    q = urlencode({"query": query})
    u = urlunparse((p.scheme, p.netloc, p.path, p.params, q, p.fragment))
    return await http_request(u, headers=h)


async def scan(
    url: str,
    method: str = "POST",
    max_probes: int = 0,
    user_agent: str = "pyodide-security/graphqlmap/1.0",
) -> dict[str, Any]:
    err = policy.check_url_for_active(url) if hasattr(policy, "check_url_for_active") else None
    if err:
        return {"ok": False, "error": err, "engine": "graphql"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    headers = {"User-Agent": user_agent, "Accept": "application/json"}
    probes = PROBES
    if max_probes and max_probes > 0:
        probes = probes[: int(max_probes)]

    findings = []
    schema_types: list[str] = []
    tested = 0
    for pr in probes:
        if not policy.can_request():
            break
        tested += 1
        resp = await _gql_request(url, pr["query"], headers, method=method, raw=bool(pr.get("raw")))
        body = resp.get("body") or ""
        status = resp.get("status") or 0
        data = None
        try:
            data = json.loads(body)
        except Exception:
            data = None

        entry = {
            "id": pr["id"],
            "tag": pr["tag"],
            "status": status,
            "ok_http": 200 <= status < 300,
        }
        if data is not None:
            entry["has_data"] = "data" in data and data.get("data") is not None
            entry["has_errors"] = bool(data.get("errors"))
            if pr["id"] in ("introspection", "types") and data.get("data"):
                schema = data["data"].get("__schema") or {}
                types = schema.get("types") or []
                names = [t.get("name") for t in types if isinstance(t, dict) and t.get("name")]
                schema_types = names
                entry["type_count"] = len(names)
                entry["introspection_open"] = True
                findings.append({**entry, "severity": "high", "title": "GraphQL introspection enabled"})
            elif entry.get("has_data") and pr["tag"] == "enum":
                findings.append({**entry, "severity": "medium", "title": f"GraphQL field probe hit: {pr['id']}"})
            elif entry.get("has_errors"):
                entry["error_sample"] = str(data.get("errors"))[:200]
        if pr["tag"] == "batch" and status == 200:
            findings.append({**entry, "severity": "info", "title": "GraphQL batch query accepted"})

    return {
        "ok": True,
        "url": url,
        "method": method,
        "tested": tested,
        "findings": findings,
        "finding_count": len(findings),
        "introspection_open": any(f.get("introspection_open") for f in findings),
        "schema_types_sample": schema_types[:40],
        "schema_type_count": len(schema_types),
        "engine": "graphql",
        "equivalent": "GraphQLmap",
    }


async def introspect(url: str, method: str = "POST", user_agent: str = "pyodide-security/graphqlmap/1.0") -> dict[str, Any]:
    return await scan(url, method=method, max_probes=2, user_agent=user_agent)


async def query(url: str, query: str = "{__typename}", method: str = "POST", user_agent: str = "pyodide-security/graphqlmap/1.0") -> dict:
    """Send a raw GraphQL query (GraphQLmap-style)."""
    headers = {"User-Agent": user_agent, "Accept": "application/json"}
    resp = await _gql_request(url, query, headers, method=method)
    body = resp.get("body") or ""
    data = None
    try:
        import json as _json
        data = _json.loads(body)
    except Exception:
        pass
    return {
        "ok": True,
        "url": url,
        "status": resp.get("status"),
        "body": body[:5000],
        "json": data,
        "engine": "graphql",
    }
