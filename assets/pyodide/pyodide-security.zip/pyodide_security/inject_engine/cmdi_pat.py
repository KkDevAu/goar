
from .. import pat_data
def list_payloads():
    rows = pat_data.get("cmdi")
    return {"payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/Command Injection"}
def list_lfi():
    rows = pat_data.get("lfi")
    return {"payloads": rows, "count": len(rows), "source": "PayloadsAllTheThings/File Inclusion"}
