"""Wayback Machine CDX API — tomnomnom/waybackurls class."""
from __future__ import annotations
import json
from typing import Any
from urllib.parse import quote
from .._http import http_request
from .. import policy
from ..subenum_engine.sources import clean_domain

async def collect(domain: str, limit: int=100, match_type: str="domain",
                  user_agent: str="pyodide-security/wayback/2.0")->dict[str,Any]:
    domain=clean_domain(domain)
    # CDX API
    url=(f"https://web.archive.org/cdx/search/cdx?url={quote(domain)}/*&output=json"
         f"&fl=original,statuscode,mimetype,timestamp&collapse=urlkey&limit={int(limit)}")
    err=policy.check_url_for_active(url) if hasattr(policy,"check_url_for_active") else None
    if err: return {"ok":False,"error":err,"engine":"wayback"}
    resp=await http_request(url, headers={"User-Agent":user_agent}, timeout_ms=7000)
    if not int(resp.get("status") or 0):
        return {
            "ok": False,
            "domain": domain,
            "error": resp.get("error") or "wayback CDX unreachable",
            "engine": "wayback",
            "equivalent": "waybackurls",
        }
    urls=[]; rows=[]
    try:
        data=json.loads(resp.get("body") or "[]")
        if isinstance(data, list) and data:
            headers=data[0]
            for row in data[1:]:
                rec=dict(zip(headers, row)) if isinstance(row, list) else {}
                u=rec.get("original") or (row[0] if row else "")
                if u:
                    urls.append(u)
                    rows.append(rec if rec else {"original":u})
    except Exception as e:
        # plain text fallback
        for line in (resp.get("body") or "").splitlines():
            if line.startswith("http"):
                urls.append(line.strip().split()[0])
    # unique preserve order
    seen=set(); uniq=[]
    for u in urls:
        if u not in seen:
            seen.add(u); uniq.append(u)
    return {"ok":True,"domain":domain,"urls":uniq,"count":len(uniq),"rows_sample":rows[:20],
            "status":resp.get("status"),"engine":"wayback","equivalent":"waybackurls/CDX"}
